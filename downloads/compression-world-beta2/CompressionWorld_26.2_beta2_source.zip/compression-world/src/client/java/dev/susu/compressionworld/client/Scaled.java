package dev.susu.compressionworld.client;public interface Scaled{void cw$scale(float f);}
