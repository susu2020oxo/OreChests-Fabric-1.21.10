package dev.susu.compressionworld.mixin;
import dev.susu.compressionworld.client.Scaled;
import dev.susu.compressionworld.CW;import net.minecraft.client.renderer.item.*;import net.minecraft.world.item.*;import net.minecraft.world.entity.ItemOwner;import net.minecraft.world.level.Level;import net.minecraft.core.component.DataComponents;import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ItemModelResolver.class)public abstract class ResolveMixin{
 @Inject(method="updateForTopItem",at=@At("RETURN"))private void scale(ItemStackRenderState out,ItemStack item,ItemDisplayContext ctx,Level w,ItemOwner owner,int seed,CallbackInfo c){((Scaled)out).cw$scale(item.has(DataComponents.FOOD)&&ctx!=ItemDisplayContext.GUI?1+.3f*CW.lv(item):1);}}
