package dev.susu.compressionworld;
import net.minecraft.world.item.*;import net.minecraft.world.item.context.UseOnContext;import net.minecraft.world.InteractionResult;import net.minecraft.world.entity.*;import net.minecraft.world.entity.player.Player;import net.minecraft.world.damagesource.DamageSource;import net.minecraft.server.level.ServerLevel;import net.minecraft.core.*;import net.minecraft.core.component.DataComponents;import net.minecraft.core.registries.BuiltInRegistries;import net.minecraft.network.chat.Component;import net.minecraft.world.level.block.Block;
public final class Body extends Item{
 public Body(Properties p){super(p);}
 public static ItemStack body(EntityType<?> t){var s=new ItemStack(CW.CORPSE);s.set(CW.BODY,BuiltInRegistries.ENTITY_TYPE.getKey(t));s.set(DataComponents.ITEM_NAME,Component.translatable("item.compressionworld.named_body",t.getDescription()));return s;}
 public static void death(LivingEntity e,DamageSource src){if(e instanceof Mob&&e.level() instanceof ServerLevel w&&src.getEntity() instanceof Player)Block.popResource(w,e.blockPosition(),body(e.getType()));}
 public InteractionResult useOn(UseOnContext c){if(c.getLevel().isClientSide())return InteractionResult.SUCCESS;var s=c.getItemInHand();var id=s.get(CW.BODY);if(id==null)return InteractionResult.FAIL;var t=BuiltInRegistries.ENTITY_TYPE.getValue(id);if(t==null)return InteractionResult.FAIL;var w=(ServerLevel)c.getLevel();var pos=c.getClickedPos().relative(c.getClickedFace());var p=c.getPlayer();if(p!=null&&(!w.mayInteract(p,pos)||!p.mayUseItemAt(pos,c.getClickedFace(),s)))return InteractionResult.FAIL;
  var probe=t.create(w,EntitySpawnReason.SPAWN_ITEM_USE);if(probe==null)return InteractionResult.FAIL;probe.setPos(pos.getX()+.5,pos.getY(),pos.getZ()+.5);if(w.getBlockCollisions(probe,probe.getBoundingBox()).iterator().hasNext())return InteractionResult.FAIL;
  int n=summon(w,t,pos,CW.summons(CW.lv(s)));if(n==0){if(p!=null)p.sendOverlayMessage(Component.literal("周围空间不足，请到开阔处召唤。"));return InteractionResult.FAIL;}s.consume(1,p);return InteractionResult.SUCCESS;}
 public static int summon(ServerLevel w,EntityType<?> t,BlockPos pos,int n){
  var probe=t.create(w,EntitySpawnReason.SPAWN_ITEM_USE);if(probe==null)return 0;
  var spots=new java.util.ArrayList<BlockPos>();int side=(int)Math.ceil(Math.sqrt(n));int spacing=Math.max(2,(int)Math.ceil(probe.getBbWidth())+1);
  for(int i=0;i<n;i++){var candidate=pos.offset((i%side-side/2)*spacing,0,(i/side-side/2)*spacing);boolean found=false;
   for(int dy=0;dy<=4;dy++){var at=candidate.above(dy);if(!w.hasChunkAt(at)||!w.getWorldBorder().isWithinBounds(at)||w.isOutsideBuildHeight(at))continue;probe.setPos(at.getX()+.5,at.getY(),at.getZ()+.5);if(!w.getBlockCollisions(probe,probe.getBoundingBox()).iterator().hasNext()){spots.add(at);found=true;break;}}
   if(!found)return 0;
  }
  int done=0;for(var at:spots)if(t.spawn(w,at,EntitySpawnReason.SPAWN_ITEM_USE)!=null)done++;return done;
 }
}
