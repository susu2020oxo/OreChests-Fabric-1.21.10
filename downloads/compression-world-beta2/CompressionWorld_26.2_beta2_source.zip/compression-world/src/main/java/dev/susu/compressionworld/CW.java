package dev.susu.compressionworld;
import com.mojang.serialization.*;
import java.util.*;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.event.player.*;
import net.fabricmc.fabric.api.entity.event.v1.*;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.core.*;
import net.minecraft.core.component.*;
import net.minecraft.core.registries.*;
import net.minecraft.network.codec.*;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.*;
import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.*;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.PushReaction;
public final class CW implements ModInitializer {
 public static Identifier id(String s){return Identifier.fromNamespaceAndPath("compressionworld",s);}
 public static final DataComponentType<Integer> LEVEL=Registry.register(BuiltInRegistries.DATA_COMPONENT_TYPE,id("level"),DataComponentType.<Integer>builder().persistent(Codec.intRange(0,5)).networkSynchronized(ByteBufCodecs.VAR_INT).build());
 public static final DataComponentType<Boolean> ALWAYS=Registry.register(BuiltInRegistries.DATA_COMPONENT_TYPE,id("original_always_eat"),DataComponentType.<Boolean>builder().persistent(Codec.BOOL).networkSynchronized(ByteBufCodecs.BOOL).build());
 public static final DataComponentType<Identifier> BODY=Registry.register(BuiltInRegistries.DATA_COMPONENT_TYPE,id("body_type"),DataComponentType.<Identifier>builder().persistent(Identifier.CODEC).networkSynchronized(Identifier.STREAM_CODEC).build());
 public static final Item PRESS=Registry.register(BuiltInRegistries.ITEM,id("compressor"),new Press(new Item.Properties().setId(ResourceKey.create(Registries.ITEM,id("compressor"))).stacksTo(1)));
 public static final Item CORPSE=Registry.register(BuiltInRegistries.ITEM,id("mob_body"),new Body(new Item.Properties().setId(ResourceKey.create(Registries.ITEM,id("mob_body")))));
 public static final RecipeSerializer<CompressRecipe> RECIPE=Registry.register(BuiltInRegistries.RECIPE_SERIALIZER,id("compress"),new RecipeSerializer<>(MapCodec.unit(CompressRecipe::new),StreamCodec.unit(new CompressRecipe())));
 public static final GiantBlock GIANT=Registry.register(BuiltInRegistries.BLOCK,id("giant_cell"),new GiantBlock(BlockBehaviour.Properties.of().setId(ResourceKey.create(Registries.BLOCK,id("giant_cell"))).strength(3,12).noOcclusion().noLootTable().pushReaction(PushReaction.BLOCK)));
 public static final BlockEntityType<GiantEntity> BE=Registry.register(BuiltInRegistries.BLOCK_ENTITY_TYPE,id("giant"),FabricBlockEntityTypeBuilder.create(GiantEntity::new,GIANT).build());
 public static int lv(ItemStack s){return s.getOrDefault(LEVEL,0);} public static int power(int l){return 1<<l;} public static int material(int l){return 1<<(2*l);} public static int size(int l){return Math.min(5,l+1);} public static int summons(int l){return l==0?1:8<<(l-1);} public static int arrows(int l){int n=1;while(l-->0)n*=10;return n;}
 public static ItemStack convert(ItemStack input,int next){
  if(next<0||next>5)throw new IllegalArgumentException("level");
  ItemStack out=input.copyWithCount(1); int old=lv(input); double ratio=(double)power(next)/power(old);
  var mods=input.get(DataComponents.ATTRIBUTE_MODIFIERS);
  if(mods!=null){var list=new ArrayList<ItemAttributeModifiers.Entry>();boolean weapon=false;
   for(var e:mods.modifiers()){var m=e.modifier();if(m.id().equals(id("base_damage")))continue;
    boolean attack=e.attribute().equals(Attributes.ATTACK_DAMAGE);weapon|=attack&&e.slot()==EquipmentSlotGroup.MAINHAND;
    boolean scale=attack||e.attribute().equals(Attributes.ARMOR)||e.attribute().equals(Attributes.ARMOR_TOUGHNESS);
    double value=m.amount();if(scale&&m.operation()==AttributeModifier.Operation.ADD_VALUE)value*=ratio;
    list.add(new ItemAttributeModifiers.Entry(e.attribute(),new AttributeModifier(m.id(),value,m.operation()),e.slot(),e.display()));}
   if(weapon&&next>0)list.add(new ItemAttributeModifiers.Entry(Attributes.ATTACK_DAMAGE,new AttributeModifier(id("base_damage"),power(next)-1,AttributeModifier.Operation.ADD_VALUE),EquipmentSlotGroup.MAINHAND));
   out.set(DataComponents.ATTRIBUTE_MODIFIERS,new ItemAttributeModifiers(list));}
  var food=input.get(DataComponents.FOOD);if(food!=null){if(old==0&&next>0)out.set(ALWAYS,food.canAlwaysEat());out.set(DataComponents.FOOD,new FoodProperties((int)Math.round(food.nutrition()*ratio),(float)(food.saturation()*ratio),next>0||out.getOrDefault(ALWAYS,food.canAlwaysEat())));if(next==0)out.remove(ALWAYS);}
  if(next==0)out.remove(LEVEL);else out.set(LEVEL,next);return out;
 }
 public void onInitialize(){
  ((dev.susu.compressionworld.mixin.ArmorLimitAccess)(Object)Attributes.ARMOR.value()).cw$max(1024);
  ((dev.susu.compressionworld.mixin.ArmorLimitAccess)(Object)Attributes.ARMOR_TOUGHNESS.value()).cw$max(1024);
  net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback.EVENT.register((d,a,e)->d.register(net.minecraft.commands.Commands.literal("compressionworld").then(net.minecraft.commands.Commands.literal("stop").executes(c->{var p=c.getSource().getPlayerOrException();Effects.VOLLEYS.removeIf(v->v.shooter==p);for(var arrow:Effects.ACTIVE)if(arrow.getOwner()==p)arrow.discard();p.sendOverlayMessage(Component.literal("你的箭雨已停止"));return 1;}))));

  UseBlockCallback.EVENT.register(Giants::use);
  PlayerBlockBreakEvents.AFTER.register(Effects::mine);
  ServerLivingEntityEvents.AFTER_DAMAGE.register(Effects::sweep);
  ServerLivingEntityEvents.AFTER_DEATH.register(Body::death);
  ServerPlayerEvents.COPY_FROM.register(Effects::copyHealth);
  ServerTickEvents.END_SERVER_TICK.register(s->{Effects.tick(s);CompressedTnt.tick();});
  ServerLifecycleEvents.SERVER_STOPPED.register(s->{Effects.clear();CompressedTnt.JOBS.clear();});
  CreativeModeTabEvents.modifyOutputEvent(ResourceKey.create(Registries.CREATIVE_MODE_TAB,Identifier.withDefaultNamespace("tools_and_utilities"))).register(e->{e.accept(CORPSE);});
  ServerLifecycleEvents.SERVER_STARTED.register(s->{if(Boolean.getBoolean("compressionworld.selftest"))Validation.run(s);});
 }
}
