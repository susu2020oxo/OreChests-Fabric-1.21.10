package dev.susu.compressionworld;

import java.util.*;
import net.minecraft.core.*;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.phys.*;
import net.minecraft.sounds.*;

/** Vanilla-strength ray energy, spread over ticks; never loads or generates remote chunks. */
public final class CompressedTnt {
 public static final int SCAN_BUDGET=8192,DESTROY_BUDGET=512;
 public static final Deque<Blast> JOBS=new ArrayDeque<>();
 private static final List<Vec3> DIRECTIONS=new ArrayList<>();
 static {for(int x=0;x<16;x++)for(int y=0;y<16;y++)for(int z=0;z<16;z++)if(x==0||x==15||y==0||y==15||z==0||z==15)DIRECTIONS.add(new Vec3(x/15.*2-1,y/15.*2-1,z/15.*2-1).normalize().scale(.3));}
 public static int multiplier(int level){int n=1;for(int i=0;i<level;i++)n*=3;return n;}
 public static float strength(int level){return 4f*multiplier(level);}
 public static boolean prime(ServerLevel world,GiantEntity root,Entity owner,int fuse){if(!root.source.is(Blocks.TNT)||root.fuse>=0)return false;root.fuse=fuse;root.igniter=owner==null?null:owner.getUUID();root.setChanged();world.playSound(null,root.getBlockPos(),SoundEvents.TNT_PRIMED,SoundSource.BLOCKS,1,1);return true;}
 public static void tickFuse(ServerLevel world,GiantEntity root){if(root.fuse<0)return;root.setChanged();if(root.display!=null&&world.getEntity(root.display) instanceof Display d)d.setGlowingTag((root.fuse/5)%2==0);
  if(--root.fuse<=0){int level=CW.lv(root.item),size=CW.size(level);var p=root.getBlockPos();Vec3 center=new Vec3(p.getX()+size/2.,p.getY()+size/2.,p.getZ()+size/2.);Entity owner=root.igniter==null?null:world.getEntity(root.igniter);Giants.remove(world,root);detonate(world,center,level,owner);}}
 public static void detonate(ServerLevel world,Vec3 center,int level,Entity owner){
  float power=strength(level);double diameter=2*power;
  world.playSound(null,center.x,center.y,center.z,SoundEvents.GENERIC_EXPLODE,SoundSource.BLOCKS,4,1);
  world.sendParticles(ParticleTypes.EXPLOSION_EMITTER,center.x,center.y,center.z,1,0,0,0,0);
  for(Entity e:world.getEntities((Entity)null,new AABB(center,center).inflate(diameter),e->e.isAlive()&&!(e instanceof Display))){double normalized=e.distanceToSqr(center)/(diameter*diameter);if(normalized>1)continue;
   if(!loadedPath(world,center,e.position()))continue;double exposure=ServerExplosion.getSeenPercent(center,e);double impact=(1-Math.sqrt(normalized))*exposure;if(impact<=0)continue;
   float damage=(float)((impact*impact+impact)/2*7*diameter+1);e.hurtServer(world,world.damageSources().explosion(null,owner),damage);
   Vec3 push=e.position().subtract(center).normalize().scale(impact);e.push(push.x,push.y,push.z);e.hurtMarked=true;
  }
  JOBS.addLast(new Blast(world,center,power,owner));
 }
 private static boolean loadedPath(ServerLevel w,Vec3 a,Vec3 b){double length=a.distanceTo(b);int steps=Math.max(1,(int)Math.ceil(length/16));for(int i=0;i<=steps;i++){BlockPos at=BlockPos.containing(a.lerp(b,(double)i/steps));for(int x=-1;x<=1;x++)for(int z=-1;z<=1;z++)if(!w.hasChunkAt(at.offset(x*16,0,z*16)))return false;}return true;}
 public static void tick(){if(JOBS.isEmpty())return;Blast b=JOBS.removeFirst();b.step(SCAN_BUDGET,DESTROY_BUDGET);if(!b.done())JOBS.addLast(b);}
 public static final class Blast {
  public final ServerLevel world;final Vec3 origin;final float power;final Entity owner;
  final Map<Long,BitSet> targets=new LinkedHashMap<>();int ray=-1;double x,y,z;float energy;Vec3 direction;Iterator<Map.Entry<Long,BitSet>> chunks;Map.Entry<Long,BitSet> current;int bit=-1;public int destroyed;
  Blast(ServerLevel w,Vec3 p,float strength,Entity owner){world=w;origin=p;power=strength;this.owner=owner;}
  boolean scanned(){return ray>=DIRECTIONS.size();}
  public boolean done(){return scanned()&&chunks!=null&&current==null&&!chunks.hasNext();}
  public void step(int scans,int destroys){
   while(scans-->0&&!scanned()){
    if(ray<0||energy<=0){ray++;if(scanned()){chunks=targets.entrySet().iterator();break;}direction=DIRECTIONS.get(ray);x=origin.x;y=origin.y;z=origin.z;energy=power*(.7f+world.getRandom().nextFloat()*.6f);}
    BlockPos pos=BlockPos.containing(x,y,z);if(world.isOutsideBuildHeight(pos)||!world.hasChunkAt(pos)||!world.getWorldBorder().isWithinBounds(pos)){energy=0;continue;}
    var state=world.getBlockState(pos);var fluid=world.getFluidState(pos);
    if(state.getDestroySpeed(world,pos)<0){energy=0;continue;}
    float resistance=state.getBlock().getExplosionResistance();if(state.is(CW.GIANT)&&world.getBlockEntity(GiantBlock.root(pos,state)) instanceof GiantEntity giant)resistance=giant.source.getBlock().getExplosionResistance();if(!state.isAir()||!fluid.isEmpty())energy-=(Math.max(resistance,fluid.getExplosionResistance())+.3f)*.3f;
    if(energy>0&&!state.isAir()){long chunk=ChunkPos.pack(pos.getX()>>4,pos.getZ()>>4);int index=((pos.getY()-world.getMinY())<<8)|((pos.getZ()&15)<<4)|(pos.getX()&15);targets.computeIfAbsent(chunk,k->new BitSet()).set(index);}
    x+=direction.x;y+=direction.y;z+=direction.z;energy-=.225f;
   }
   if(!scanned())return;
   while(destroys-->0){if(current==null){if(!chunks.hasNext())return;current=chunks.next();bit=-1;}
    bit=current.getValue().nextSetBit(bit+1);if(bit<0){current=null;destroys++;continue;}
    long key=current.getKey();BlockPos p=new BlockPos(ChunkPos.getX(key)*16+(bit&15),world.getMinY()+(bit>>8),ChunkPos.getZ(key)*16+((bit>>4)&15));
    if(!world.hasChunkAt(p))continue;var state=world.getBlockState(p);if(state.isAir()||state.getDestroySpeed(world,p)<0)continue;
    if(state.is(CW.GIANT)){var at=GiantBlock.root(p,state);if(world.getBlockEntity(at) instanceof GiantEntity g){if(g.source.is(Blocks.TNT)){prime(world,g,owner,10+world.getRandom().nextInt(20));continue;}int size=CW.size(CW.lv(g.item)),cells=size*size*size;if(cells>destroys+1){bit--;return;}Giants.remove(world,g);destroyed+=cells;destroys-=cells-1;continue;}}
    if(state.is(Blocks.TNT)){var t=new net.minecraft.world.entity.item.PrimedTnt(world,p.getX()+.5,p.getY(),p.getZ()+.5,owner instanceof LivingEntity l?l:null);t.setFuse(10+world.getRandom().nextInt(20));world.addFreshEntity(t);}
    // Large blasts intentionally omit terrain item drops to avoid millions of item entities.
    world.setBlock(p,Blocks.AIR.defaultBlockState(),3);destroyed++;
   }
  }
 }
}
