package dev.susu.compressionworld;

import net.minecraft.world.*;
import net.minecraft.world.inventory.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.item.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;

/** Uses the vanilla 6-row chest screen, with 16 lanes per page and guarded navigation slots. */
public final class FurnaceMenu extends AbstractContainerMenu {
 public final GiantFurnace furnace;public int page;
 private final View view=new View();
 public FurnaceMenu(int id,Inventory inventory,GiantFurnace furnace){super(MenuType.GENERIC_9x6,id);this.furnace=furnace;
  for(int i=0;i<54;i++){final int slot=i;addSlot(new Slot(view,i,8+(i%9)*18,18+(i/9)*18){
   public boolean mayPlace(ItemStack s){int index=mapped(slot);return index>=0&&switch(index%3){case 0->furnace.canInput(s);case 1->furnace.fuelTicks(s)>0;default->false;};}
   public boolean mayPickup(Player p){return mapped(slot)>=0;}
   public void onTake(Player p,ItemStack s){if(mapped(slot)>=0&&mapped(slot)%3==2)furnace.award((ServerLevel)p.level());super.onTake(p,s);}
  });}
  for(int row=0;row<3;row++)for(int col=0;col<9;col++)addSlot(new Slot(inventory,col+row*9+9,8+col*18,140+row*18));
  for(int col=0;col<9;col++)addSlot(new Slot(inventory,col,8+col*18,198));
 }
 public int mapped(int slot){if(slot<0||slot>=54||slot%9==8)return -1;int lane=page*16+(slot/27)*8+slot%9;return lane<furnace.lanes()?lane*3+(slot%27)/9:-1;}
 public boolean stillValid(Player p){return !furnace.root.isRemoved()&&furnace.root.getLevel()==p.level()&&p.distanceToSqr(furnace.root.getBlockPos().getX()+.5,furnace.root.getBlockPos().getY()+.5,furnace.root.getBlockPos().getZ()+.5)<256;}
 public void clicked(int slot,int button,ContainerInput action,Player p){if(slot>=0&&slot<54&&mapped(slot)<0){if(action==ContainerInput.PICKUP){if(slot==8)page=Math.max(0,page-1);if(slot==17)page=Math.min((furnace.lanes()-1)/16,page+1);broadcastFullState();}return;}super.clicked(slot,button,action,p);}
 public ItemStack quickMoveStack(Player p,int slot){if(slot<0||slot>=slots.size())return ItemStack.EMPTY;var from=slots.get(slot);if(!from.hasItem()||!from.mayPickup(p))return ItemStack.EMPTY;var item=from.getItem();var copy=item.copy();
  if(slot<54){if(!moveItemStackTo(item,54,slots.size(),true))return ItemStack.EMPTY;}
  else {boolean moved=false;for(int i=0;i<54&&!item.isEmpty();i++)if(slots.get(i).mayPlace(item))moved|=moveItemStackTo(item,i,i+1,false);if(!moved)return ItemStack.EMPTY;}
  if(item.isEmpty())from.setByPlayer(ItemStack.EMPTY);else from.setChanged();from.onTake(p,copy.copyWithCount(copy.getCount()-item.getCount()));return copy;
 }
 private ItemStack label(Item item,String title){var s=new ItemStack(item);s.set(DataComponents.ITEM_NAME,Component.literal(title));return s;}
 private final class View extends SimpleContainer{
  View(){super(54);}
  public ItemStack getItem(int slot){int i=mapped(slot);if(i>=0)return furnace.items.get(i);
   return switch(slot){case 8->label(Items.ARROW,"上一页");case 17->label(Items.ARROW,"下一页");case 26->label(Items.PAPER,"第 "+(page+1)+" 页 / "+((furnace.lanes()+15)/16)+" 页 · "+furnace.lanes()+" 组同时烧炼");case 35->label(Items.RAW_IRON,"每组三行：上方原料");case 44->label(Items.COAL,"中间燃料，每组独立消耗");case 53->label(Items.IRON_INGOT,"下方产物，点击或Shift取出");default->label(Items.IRON_BARS,"此等级未解锁");};}
  public void setItem(int slot,ItemStack s){int i=mapped(slot);if(i>=0){furnace.items.set(i,s);setChanged();}}
  public ItemStack removeItem(int slot,int amount){int i=mapped(slot);if(i<0)return ItemStack.EMPTY;var out=furnace.items.get(i).split(amount);setChanged();return out;}
  public ItemStack removeItemNoUpdate(int slot){int i=mapped(slot);if(i<0)return ItemStack.EMPTY;var out=furnace.items.get(i);furnace.items.set(i,ItemStack.EMPTY);return out;}
  public void setChanged(){furnace.root.setChanged();}
  public boolean stillValid(Player p){return FurnaceMenu.this.stillValid(p);}
 }
}
