package dev.susu.compressionworld;
import com.mojang.serialization.MapCodec;import net.minecraft.core.*;import net.minecraft.world.entity.player.Player;import net.minecraft.world.item.ItemStack;import net.minecraft.world.level.*;import net.minecraft.server.level.ServerLevel;import net.minecraft.world.level.block.*;import net.minecraft.world.level.block.entity.*;import net.minecraft.world.level.block.state.*;import net.minecraft.world.level.block.state.properties.*;import net.minecraft.world.phys.shapes.*;
public final class GiantBlock extends BaseEntityBlock{
 public static final MapCodec<GiantBlock> CODEC=simpleCodec(GiantBlock::new);
 public static final IntegerProperty X=IntegerProperty.create("x",0,4),Y=IntegerProperty.create("y",0,4),Z=IntegerProperty.create("z",0,4);public static final BooleanProperty SOLID=BooleanProperty.create("solid");
 public GiantBlock(Properties p){super(p);registerDefaultState(stateDefinition.any().setValue(X,0).setValue(Y,0).setValue(Z,0).setValue(SOLID,true));}
 protected MapCodec<? extends BaseEntityBlock> codec(){return CODEC;}protected void createBlockStateDefinition(StateDefinition.Builder<Block,BlockState>b){b.add(X,Y,Z,SOLID);}
 public static BlockPos root(BlockPos p,BlockState s){return p.offset(-s.getValue(X),-s.getValue(Y),-s.getValue(Z));}
 protected RenderShape getRenderShape(BlockState s){return RenderShape.INVISIBLE;}
 protected VoxelShape getShape(BlockState s,BlockGetter w,BlockPos p,CollisionContext c){return Shapes.block();}
 protected VoxelShape getCollisionShape(BlockState s,BlockGetter w,BlockPos p,CollisionContext c){return s.getValue(SOLID)?Shapes.block():Shapes.empty();}
 protected float getDestroyProgress(BlockState s,Player player,BlockGetter w,BlockPos p){if(w.getBlockEntity(root(p,s)) instanceof GiantEntity e&&!e.item.isEmpty())return e.fuse>=0?0:e.source.getDestroyProgress(player,w,p)/CW.power(CW.lv(e.item));return super.getDestroyProgress(s,player,w,p);}
 public BlockState playerWillDestroy(Level w,BlockPos p,BlockState s,Player player){if(w instanceof ServerLevel server)Giants.destroy(server,p,s,player,player.getMainHandItem());return s;}
 protected void onExplosionHit(BlockState s,ServerLevel w,BlockPos p,Explosion ex,java.util.function.BiConsumer<ItemStack,BlockPos> drops){if(w.getBlockEntity(root(p,s)) instanceof GiantEntity e&&e.source.is(Blocks.TNT))CompressedTnt.prime(w,e,null,10+w.getRandom().nextInt(20));else Giants.destroy(w,p,s,null,ItemStack.EMPTY);}
 protected void neighborChanged(BlockState s,Level w,BlockPos p,Block neighbor,net.minecraft.world.level.redstone.Orientation orientation,boolean moving){if(w instanceof ServerLevel sw&&w.getBlockEntity(root(p,s)) instanceof GiantEntity e&&e.source.is(Blocks.TNT)){boolean ignite=w.hasNeighborSignal(p);for(var d:Direction.values())ignite|=w.getBlockState(p.relative(d)).is(net.minecraft.tags.BlockTags.FIRE);if(ignite)CompressedTnt.prime(sw,e,null,80);}}
 protected void onProjectileHit(Level w,BlockState s,net.minecraft.world.phys.BlockHitResult hit,net.minecraft.world.entity.projectile.Projectile arrow){if(w instanceof ServerLevel sw&&arrow.isOnFire()&&w.getBlockEntity(root(hit.getBlockPos(),s)) instanceof GiantEntity e)CompressedTnt.prime(sw,e,arrow.getOwner(),80);}
 protected void affectNeighborsAfterRemoval(BlockState s,ServerLevel w,BlockPos p,boolean moving){Giants.cleanup(w,root(p,s));super.affectNeighborsAfterRemoval(s,w,p,moving);}
 public BlockEntity newBlockEntity(BlockPos p,BlockState s){return new GiantEntity(p,s);}
 public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level w,BlockState s,BlockEntityType<T> t){return w.isClientSide()?null:createTickerHelper(t,CW.BE,GiantEntity::tick);}
}
