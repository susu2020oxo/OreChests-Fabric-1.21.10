package dev.susu.compressionworld;

import java.util.*;
import net.minecraft.core.*;
import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.storage.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.phys.Vec3;

/** Independent vanilla-duration smelting lanes, including fuel remainders and persistent progress. */
public final class GiantFurnace {
 public final GiantEntity root;
 public final NonNullList<ItemStack> items=NonNullList.withSize(96,ItemStack.EMPTY);
 public final int[] burn=new int[32],progress=new int[32],duration=new int[32];
 private final ItemStack[] previous=new ItemStack[32];
 public double experience;
 public GiantFurnace(GiantEntity root){this.root=root;Arrays.fill(previous,ItemStack.EMPTY);}
 public boolean enabled(){return root.source.is(Blocks.FURNACE)||root.source.is(Blocks.BLAST_FURNACE)||root.source.is(Blocks.SMOKER);}
 public int lanes(){return Math.min(32,CW.power(CW.lv(root.item)));}
 public int fuelTicks(ItemStack s){if(s.isEmpty()||root.getLevel()==null)return 0;return root.getLevel().fuelValues().burnDuration(CW.convert(s,0))*CW.material(CW.lv(s))/(root.source.is(Blocks.SMOKER)||root.source.is(Blocks.BLAST_FURNACE)?2:1);}
 private static <T extends AbstractCookingRecipe>T find(ServerLevel w,RecipeType<T> type,ItemStack s){return w.getServer().getRecipeManager().getRecipeFor(type,new SingleRecipeInput(s),w).map(RecipeHolder::value).orElse(null);}
 public AbstractCookingRecipe recipe(ItemStack input){if(input.isEmpty()||!(root.getLevel() instanceof ServerLevel w))return null;var s=CW.convert(input,0);return root.source.is(Blocks.SMOKER)?find(w,RecipeType.SMOKING,s):root.source.is(Blocks.BLAST_FURNACE)?find(w,RecipeType.BLASTING,s):find(w,RecipeType.SMELTING,s);}
 private ItemStack smeltResult(AbstractCookingRecipe recipe,ItemStack input){var raw=recipe.assemble(new SingleRecipeInput(CW.convert(input,0)));return CW.convert(raw,CW.lv(input)).copyWithCount(raw.getCount());}
 public boolean canInput(ItemStack s){return recipe(s)!=null;}
 public void tick(ServerLevel w){if(!enabled())return;boolean dirty=false,lit=false;
  for(int i=0;i<lanes();i++){
   ItemStack input=items.get(i*3),fuel=items.get(i*3+1),output=items.get(i*3+2);
   if(!ItemStack.isSameItemSameComponents(input,previous[i])){progress[i]=0;previous[i]=input.copyWithCount(1);dirty=true;}
   if(burn[i]>0){burn[i]--;dirty|=burn[i]==0;}
   var recipe=recipe(input);ItemStack result=recipe==null?ItemStack.EMPTY:smeltResult(recipe,input);
   boolean can=!result.isEmpty()&&(output.isEmpty()||(ItemStack.isSameItemSameComponents(output,result)&&output.getCount()+result.getCount()<=output.getMaxStackSize()));
   if(can&&burn[i]==0&&fuelTicks(fuel)>0){
    burn[i]=fuelTicks(fuel); // Compression preserves the material value of fuel.
    ItemStack remainder=fuel.is(Items.LAVA_BUCKET)?CW.convert(new ItemStack(Items.BUCKET),CW.lv(fuel)):ItemStack.EMPTY;
    fuel.shrink(1);if(fuel.isEmpty())items.set(i*3+1,remainder);dirty=true;
   }
   if(can&&burn[i]>0){duration[i]=recipe.cookingTime();if(++progress[i]>=duration[i]){progress[i]=0;if(input.is(Items.WET_SPONGE)&&items.get(i*3+1).is(Items.BUCKET))items.set(i*3+1,CW.convert(new ItemStack(Items.WATER_BUCKET),CW.lv(items.get(i*3+1))));input.shrink(1);if(output.isEmpty())items.set(i*3+2,result);else output.grow(result.getCount());experience+=recipe.experience()*CW.material(CW.lv(result));dirty=true;}}
   else if(progress[i]>0){progress[i]=Math.max(0,progress[i]-2);dirty=true;}
   lit|=burn[i]>0;
  }
  if(root.source.getValue(BlockStateProperties.LIT)!=lit){root.source=root.source.setValue(BlockStateProperties.LIT,lit);Giants.display(w,root);dirty=true;}
  if(dirty||lit&&w.getGameTime()%20==0)root.setChanged();
 }
 public void save(ValueOutput o){o.store("furnace_items",ItemStack.OPTIONAL_CODEC.listOf(),items);o.putIntArray("furnace_burn",burn);o.putIntArray("furnace_progress",progress);o.putIntArray("furnace_duration",duration);o.putDouble("furnace_xp",experience);}
 public void load(ValueInput in){var saved=in.read("furnace_items",ItemStack.OPTIONAL_CODEC.listOf()).orElse(List.of());for(int i=0;i<Math.min(96,saved.size());i++)items.set(i,saved.get(i));copy(in,"furnace_burn",burn);copy(in,"furnace_progress",progress);copy(in,"furnace_duration",duration);experience=in.getDoubleOr("furnace_xp",0);for(int i=0;i<32;i++)previous[i]=items.get(i*3).copyWithCount(1);}
 private void copy(ValueInput in,String name,int[] dest){var arr=in.getIntArray(name).orElse(new int[0]);System.arraycopy(arr,0,dest,0,Math.min(32,arr.length));}
 public void award(ServerLevel w){int amount=(int)experience;if(amount>0){ExperienceOrb.award(w,Vec3.atCenterOf(root.getBlockPos()),amount);experience-=amount;root.setChanged();}}
 public void dropContents(ServerLevel w){for(int i=0;i<96;i++){var s=items.get(i);items.set(i,ItemStack.EMPTY);if(!s.isEmpty())Block.popResource(w,root.getBlockPos(),s);}award(w);}
}
