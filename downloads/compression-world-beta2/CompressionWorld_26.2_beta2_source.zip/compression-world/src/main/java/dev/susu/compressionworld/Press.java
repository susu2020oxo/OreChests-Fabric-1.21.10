package dev.susu.compressionworld;
import net.minecraft.world.*;import net.minecraft.world.entity.player.*;import net.minecraft.world.item.*;import net.minecraft.world.level.Level;import net.minecraft.network.chat.Component;import java.util.*;
public class Press extends Item{
 public Press(Properties p){super(p);}static void give(Player p,ItemStack s){if(!p.getInventory().add(s))p.drop(s,false);}
 public InteractionResult use(Level w,Player p,InteractionHand h){if(w.isClientSide())return InteractionResult.SUCCESS;
  ItemStack selected=p.getItemInHand(h==InteractionHand.MAIN_HAND?InteractionHand.OFF_HAND:InteractionHand.MAIN_HAND);
  if(selected.isEmpty()||selected.is(this)){p.sendOverlayMessage(Component.literal("另一只手放目标物品，背包备齐4个相同物品。Shift+右键拆解。"));return InteractionResult.FAIL;}
  int l=CW.lv(selected);if(p.isShiftKeyDown()){if(l==0)return InteractionResult.FAIL;ItemStack out=CW.convert(selected,l-1);selected.shrink(1);for(int i=0;i<4;i++)give(p,out.copy());return InteractionResult.SUCCESS;}
  if(l==5){p.sendOverlayMessage(Component.literal("最高只能压缩5次"));return InteractionResult.FAIL;}
  List<ItemStack> matches=new ArrayList<>();int count=0;
  for(int i=0;i<p.getInventory().getContainerSize();i++){if(i>=36&&i!=Inventory.SLOT_OFFHAND)continue;ItemStack s=p.getInventory().getItem(i);if(ItemStack.isSameItemSameComponents(selected,s)){matches.add(s);count+=s.getCount();}}
  if(count<4){p.sendOverlayMessage(Component.literal("需要4个同种、同级、同附魔、同耐久的物品。"));return InteractionResult.FAIL;}
  ItemStack out=CW.convert(selected,l+1);int remaining=4;for(var s:matches){int take=Math.min(remaining,s.getCount());s.shrink(take);remaining-=take;if(remaining==0)break;}give(p,out);p.getInventory().setChanged();return InteractionResult.SUCCESS;
 }
}
