package dev.susu.compressionworld;
import net.minecraft.server.MinecraftServer;import net.minecraft.core.*;import net.minecraft.world.item.*;import net.minecraft.world.level.block.*;import net.minecraft.world.level.block.entity.BlockEntity;import net.minecraft.world.phys.*;import net.minecraft.world.inventory.*;import net.minecraft.world.InteractionHand;import net.fabricmc.fabric.api.entity.FakePlayer;
public final class UpgradeValidation{
 static void ok(boolean yes,String what){Validation.ok(yes,what);}
 public static void run(MinecraftServer server){var w=server.overworld();for(int x=-3;x<=9;x++)for(int z=-3;z<=9;z++)w.getChunk(x,z);
  var pos=new BlockPos(80,230,0);if(w.getBlockEntity(pos) instanceof GiantEntity old)Giants.remove(w,old);
  ok(Giants.place(w,pos,Blocks.FURNACE.defaultBlockState(),CW.convert(new ItemStack(Items.FURNACE),5),null,Direction.UP),"giant furnace placement");
  var root=(GiantEntity)w.getBlockEntity(pos);var furnace=root.furnace;ok(furnace.lanes()==32,"32 simultaneous furnace lanes");
  for(int i=0;i<32;i++){furnace.items.set(i*3,new ItemStack(Items.RAW_IRON,2));furnace.items.set(i*3+1,new ItemStack(Items.COAL));}
  for(int tick=0;tick<100;tick++)furnace.tick(w);for(int i=0;i<32;i++)ok(furnace.progress[i]==100,"parallel half progress "+i);
  var loaded=(GiantEntity)BlockEntity.loadStatic(pos,root.getBlockState(),root.saveWithFullMetadata(w.registryAccess()),w.registryAccess());ok(loaded.furnace.progress[31]==100&&loaded.furnace.burn[31]>0,"furnace progress serialized");loaded.setLevel(w);w.setBlockEntity(loaded);root=loaded;furnace=root.furnace;
  for(int tick=0;tick<100;tick++)furnace.tick(w);for(int i=0;i<32;i++)ok(furnace.items.get(i*3+2).is(Items.IRON_INGOT)&&furnace.items.get(i*3+2).getCount()==1,"parallel smelt output "+i);
  var player=FakePlayer.get(w);player.setPos(80,230,-2);var menu=new FurnaceMenu(7,player.getInventory(),furnace);ok(menu.slots.size()==90,"vanilla client menu size");ok(menu.mapped(0)==0&&menu.mapped(18)==2,"page one mapping");
  menu.clicked(17,0,ContainerInput.PICKUP,player);ok(menu.page==1&&menu.mapped(0)==48&&menu.mapped(52)==95,"page two mapping");ok(!menu.slots.get(18).mayPlace(new ItemStack(Items.DIRT)),"output insertion blocked");ok(!menu.slots.get(17).mayPickup(player),"navigation cannot be stolen");
  var moved=menu.quickMoveStack(player,18);ok(moved.is(Items.IRON_INGOT)&&furnace.items.get(50).isEmpty(),"page two quick move correct lane");ok(furnace.items.get(2).is(Items.IRON_INGOT),"page one unaffected");
  furnace.items.set(0,CW.convert(new ItemStack(Items.RAW_GOLD),2));furnace.items.set(1,CW.convert(new ItemStack(Items.LAVA_BUCKET),1));furnace.items.set(2,ItemStack.EMPTY);furnace.burn[0]=0;
  for(int tick=0;tick<200;tick++)furnace.tick(w);ok(furnace.items.get(2).is(Items.GOLD_INGOT)&&CW.lv(furnace.items.get(2))==2,"compressed ore smelting");ok(furnace.items.get(1).is(Items.BUCKET)&&CW.lv(furnace.items.get(1))==1,"compressed lava bucket remainder");
  int before=w.getEntitiesOfClass(net.minecraft.world.entity.item.ItemEntity.class,new AABB(pos).inflate(8)).stream().mapToInt(e->e.getItem().getCount()).sum();int contents=furnace.items.stream().mapToInt(ItemStack::getCount).sum();w.setBlock(pos,Blocks.AIR.defaultBlockState(),3);int after=w.getEntitiesOfClass(net.minecraft.world.entity.item.ItemEntity.class,new AABB(pos).inflate(8)).stream().mapToInt(e->e.getItem().getCount()).sum();ok(after-before==contents,"furnace contents drop once on replacement");ok(!menu.stillValid(player),"destroyed furnace closes menu");
  for(int l=1;l<=5;l++)ok(CompressedTnt.strength(l)==4*Math.pow(3,l),"TNT power x3 level "+l);
  var blast=new BlockPos(112,230,0);if(w.getBlockEntity(blast) instanceof GiantEntity g)Giants.remove(w,g);for(var p:BlockPos.betweenClosed(blast.offset(-5,-5,-5),blast.offset(6,6,6)))w.setBlock(p,Blocks.AIR.defaultBlockState(),3);
  ok(Giants.place(w,blast,Blocks.TNT.defaultBlockState(),CW.convert(new ItemStack(Items.TNT),1),null,Direction.UP),"compressed TNT placement");
  for(var p:BlockPos.betweenClosed(blast.offset(-4,-4,-4),blast.offset(5,5,5)))if(!w.getBlockState(p).is(CW.GIANT))w.setBlock(p,Blocks.STONE.defaultBlockState(),3);
  var bedrock=blast.offset(-3,0,0);w.setBlock(bedrock,Blocks.BEDROCK.defaultBlockState(),3);
  var tnt=(GiantEntity)w.getBlockEntity(blast);player.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(Items.FLINT_AND_STEEL));Giants.use(player,w,InteractionHand.MAIN_HAND,new BlockHitResult(Vec3.atCenterOf(blast),Direction.UP,blast,false));ok(tnt.fuse==80,"flint and steel primes TNT");
  var saved=(GiantEntity)BlockEntity.loadStatic(blast,tnt.getBlockState(),tnt.saveWithFullMetadata(w.registryAccess()),w.registryAccess());ok(saved.fuse==80&&saved.igniter.equals(player.getUUID()),"TNT fuse saved");
  tnt.fuse=2;CompressedTnt.tickFuse(w,tnt);ok(!tnt.isRemoved(),"fuse delay");CompressedTnt.tickFuse(w,tnt);ok(tnt.isRemoved()&&!CompressedTnt.JOBS.isEmpty(),"detonation enqueued");
  int ticks=0;while(!CompressedTnt.JOBS.isEmpty()&&ticks++<1000){var job=CompressedTnt.JOBS.getFirst();int previous=job.destroyed;CompressedTnt.tick();ok(job.destroyed-previous<=CompressedTnt.DESTROY_BUDGET,"bounded blast work");}
  ok(CompressedTnt.JOBS.isEmpty(),"blast completes");ok(w.getBlockState(bedrock).is(Blocks.BEDROCK),"bedrock survives");int destroyed=0;for(var p:BlockPos.betweenClosed(blast.offset(-4,-4,-4),blast.offset(5,5,5)))if(w.getBlockState(p).isAir())destroyed++;ok(destroyed>8,"actual blast destroys terrain");
 }
}
