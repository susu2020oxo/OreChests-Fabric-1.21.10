package dev.susu.compressionworld;
import java.util.*;import java.nio.file.*;import net.fabricmc.fabric.api.entity.FakePlayer;import net.minecraft.server.*;import net.minecraft.core.*;import net.minecraft.core.component.DataComponents;import net.minecraft.core.registries.BuiltInRegistries;import net.minecraft.world.item.*;import net.minecraft.world.item.crafting.*;import net.minecraft.world.entity.*;import net.minecraft.world.entity.item.ItemEntity;import net.minecraft.world.entity.ai.attributes.Attributes;import net.minecraft.world.level.block.*;import net.minecraft.world.level.block.entity.BlockEntity;import net.minecraft.world.phys.AABB;import net.minecraft.world.InteractionHand;
/** Opt-in disposable-world integration checks; never runs in normal play. */
public class Validation{
 static int checks=0;static void ok(boolean b,String s){if(!b)throw new AssertionError(s);checks++;}
 public static void run(MinecraftServer server){try{
  var w=server.overworld();var recipe=new CompressRecipe();int items=0;
  for(var type:BuiltInRegistries.ITEM){var raw=new ItemStack(type);if(raw.isEmpty()||raw.is(CW.PRESS))continue;items++;var s=raw;
   var diamond=CraftingInput.of(3,3,List.of(ItemStack.EMPTY,raw,ItemStack.EMPTY,raw,ItemStack.EMPTY,raw,ItemStack.EMPTY,raw,ItemStack.EMPTY));
   ok(recipe.matches(diamond,w),"workbench diamond pattern "+type);
   ok(CW.lv(server.getRecipeManager().getRecipeFor(RecipeType.CRAFTING,diamond,w).orElseThrow().value().assemble(diamond))==1,"actual workbench craft "+type);

   for(int l=1;l<=5;l++){var in=CraftingInput.of(2,2,List.of(s.copy(),s.copy(),s.copy(),s.copy()));ok(recipe.matches(in,null),"craft "+type+" level "+l);s=recipe.assemble(in);ok(CW.lv(s)==l,"level");}
   ok(!recipe.matches(CraftingInput.of(2,2,List.of(s,s,s,s)),w),"max");var back=CW.convert(s,0);ok(ItemStack.isSameItemSameComponents(raw,back),"roundtrip "+type);
  }
  var planks=new ItemStack(Items.OAK_PLANKS);var square=CraftingInput.of(2,2,List.of(planks,planks,planks,planks));ok(!recipe.matches(square,w),"vanilla crafting table preserved");ok(server.getRecipeManager().getRecipeFor(RecipeType.CRAFTING,square,w).orElseThrow().value().assemble(square).is(Items.CRAFTING_TABLE),"actual vanilla priority");var compressed=CW.convert(planks,1);square=CraftingInput.of(2,2,List.of(compressed,compressed,compressed,compressed));ok(CW.lv(server.getRecipeManager().getRecipeFor(RecipeType.CRAFTING,square,w).orElseThrow().value().assemble(square))==2,"actual compressed recipe priority");
  var sword=CW.convert(new ItemStack(Items.DIAMOND_SWORD),5);double damage=sword.get(DataComponents.ATTRIBUTE_MODIFIERS).compute(Attributes.ATTACK_DAMAGE,1,EquipmentSlot.MAINHAND);ok(damage==224,"sword damage="+damage);
  ok(CW.summons(1)==8&&CW.summons(5)==128,"summon math");ok(CW.arrows(5)==100000,"arrow math");
  for(int cx=-1;cx<=4;cx++)for(int cz=-1;cz<=4;cz++)w.getChunk(cx,cz);
  var base=new BlockPos(0,200,0);
  // A marker left on disk by a prior test run checks full save/reload independently of codec roundtrips.
  var persistent=new BlockPos(50,200,0);
  if(w.getBlockState(persistent).is(CW.GIANT)){ok(w.getBlockEntity(persistent) instanceof GiantEntity,"persisted entity");var ge=(GiantEntity)w.getBlockEntity(persistent);ok(CW.lv(ge.item)==5,"persisted item level");Giants.remove(w,ge);}
  for(int l=1;l<=5;l++){var pos=base.offset(l*8,0,10);var stack=CW.convert(new ItemStack(Items.STONE),l);int n=CW.size(l);ok(Giants.place(w,pos,Blocks.STONE.defaultBlockState(),stack,null,Direction.UP),"giant placement "+l);
   var root=(GiantEntity)w.getBlockEntity(pos);int cells=0;for(var q:BlockPos.betweenClosed(pos,pos.offset(n-1,n-1,n-1)))if(w.getBlockState(q).is(CW.GIANT))cells++;ok(cells==n*n*n,"collision cells");ok(w.getEntity(root.display) instanceof Display,"display");
   var loaded=BlockEntity.loadStatic(pos,root.getBlockState(),root.saveWithFullMetadata(w.registryAccess()),w.registryAccess());ok(loaded instanceof GiantEntity g&&CW.lv(g.item)==l&&g.source.is(Blocks.STONE),"giant serialization");
   var box=new AABB(pos).inflate(3);for(var it:w.getEntitiesOfClass(ItemEntity.class,box))it.discard();
   Giants.destroy(w,pos.offset(n-1,n-1,n-1),w.getBlockState(pos.offset(n-1,n-1,n-1)),null,new ItemStack(Items.DIAMOND_PICKAXE));
   ok(w.getBlockState(pos).isAir(),"whole removal");int drops=w.getEntitiesOfClass(ItemEntity.class,box).stream().filter(e->e.getItem().is(Items.COBBLESTONE)).mapToInt(e->e.getItem().getCount()).sum();ok(drops==CW.material(l),"drop count "+l+"="+drops);
  }
  var crop=base.offset(0,0,30);ok(Giants.place(w,crop,Blocks.WHEAT.defaultBlockState(),CW.convert(new ItemStack(Items.WHEAT_SEEDS),1),null,Direction.UP),"crop place");var ge=(GiantEntity)w.getBlockEntity(crop);for(int i=0;i<3;i++)Giants.grow(w,ge,true);ok(((CropBlock)ge.source.getBlock()).isMaxAge(ge.source),"crop mature");w.setBlock(crop,Blocks.AIR.defaultBlockState(),3);ok(w.getBlockState(crop.offset(1,1,1)).isAir(),"command cleanup");
  var player=FakePlayer.get(w);player.setPos(0,200,50);player.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(CW.PRESS));player.setItemInHand(InteractionHand.OFF_HAND,new ItemStack(Items.DIAMOND,4));((Press)CW.PRESS).use(w,player,InteractionHand.MAIN_HAND);ok(player.getInventory().contains(s->s.is(Items.DIAMOND)&&CW.lv(s)==1),"compressor inventory");
  var food=CW.convert(new ItemStack(Items.APPLE),2);float before=player.getMaxHealth();food.finishUsingItem(w,player);ok(player.getMaxHealth()==before+4,"food max health");
  var copy=FakePlayer.get(w,new com.mojang.authlib.GameProfile(UUID.randomUUID(),"CW_Copy"));Effects.copyHealth(player,copy,false);ok(copy.getMaxHealth()==player.getMaxHealth(),"health survives death copy");player.setItemSlot(EquipmentSlot.CHEST,CW.convert(new ItemStack(Items.DIAMOND_CHESTPLATE),5));ok(Effects.armor(player,player.damageSources().playerAttack(player),32)==1,"armor effective multiplier");
  var bow=CW.convert(new ItemStack(Items.BOW),1);player.setItemInHand(InteractionHand.MAIN_HAND,bow);player.getInventory().add(new ItemStack(Items.ARROW,5));((BowItem)Items.BOW).releaseUsing(bow,w,player,71800);ok(Effects.VOLLEYS.size()==1,"actual bow release queues volley");Effects.tick(server);ok(Effects.ACTIVE.size()==9,"nine extra arrows");for(var a:Effects.ACTIVE){ok(((dev.susu.compressionworld.mixin.ArrowAccess)a).cw$damage()==4,"arrow damage");a.discard();}Effects.clear();
  var mobs=base.offset(0,0,60);ok(Body.summon(w,EntityTypes.PIG,mobs,8)==8,"summon actual count");ok(Body.summon(w,EntityTypes.PIG,mobs,128)==128,"five-level summon count");
  var stone=base.offset(20,0,45);for(var q:BlockPos.betweenClosed(stone.offset(-1,-1,0),stone.offset(1,1,0)))w.setBlock(q,Blocks.STONE.defaultBlockState(),3);player.setPos(stone.getX(),stone.getY(),stone.getZ()-3);player.setXRot(0);player.setYRot(0);player.setItemInHand(InteractionHand.MAIN_HAND,CW.convert(new ItemStack(Items.DIAMOND_PICKAXE),1));ok(player.gameMode.destroyBlock(stone),"mine center");Effects.tick(server);int left=0;for(var q:BlockPos.betweenClosed(stone.offset(-1,-1,0),stone.offset(1,1,0)))if(w.getBlockState(q).is(Blocks.STONE))left++;ok(left==0,"3x3 actual mining left="+left);
  UpgradeValidation.run(server);
  Giants.place(w,persistent,Blocks.DIAMOND_BLOCK.defaultBlockState(),CW.convert(new ItemStack(Items.DIAMOND_BLOCK),5),null,Direction.UP);
  String result="PASS "+checks+" assertions; "+items+" item types; crafting, level cap, reversible components, damage, giant collision/loot/persistence, crop growth, legacy compressor, workbench recipes, food health, arrows, mining, summons, 32-lane furnace and paged menu, furnace persistence, compressed smelting and bucket remainders, TNT x3 strength/fuse/terrain destruction/budget/bedrock.";System.out.println("CW_TEST "+result);Files.writeString(Path.of("validation-result.txt"),result);
 }catch(Throwable e){e.printStackTrace();try{Files.writeString(Path.of("validation-result.txt"),"FAIL "+e);}catch(Exception ignored){}}finally{server.halt(false);}}
}
