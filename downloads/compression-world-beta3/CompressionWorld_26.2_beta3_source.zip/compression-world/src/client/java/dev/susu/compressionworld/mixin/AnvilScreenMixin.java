package dev.susu.compressionworld.mixin;
import net.minecraft.client.gui.screens.inventory.AnvilScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(AnvilScreen.class)public abstract class AnvilScreenMixin {
    @ModifyConstant(method="extractLabels",constant=@Constant(intValue=40))private int visibleCost(int normal){
        // A real server-provided result above 39 levels is valid for a compressed anvil.
        return ((AnvilScreen)(Object)this).getMenu().getSlot(2).hasItem()?Integer.MAX_VALUE:normal;
    }
}
