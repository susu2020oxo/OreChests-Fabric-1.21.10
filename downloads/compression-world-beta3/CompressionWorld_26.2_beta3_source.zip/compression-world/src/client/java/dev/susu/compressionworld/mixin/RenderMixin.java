package dev.susu.compressionworld.mixin;
import dev.susu.compressionworld.client.Scaled;
import com.mojang.blaze3d.vertex.PoseStack;import net.minecraft.client.renderer.item.ItemStackRenderState;import net.minecraft.client.renderer.SubmitNodeCollector;import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ItemStackRenderState.class)public abstract class RenderMixin implements Scaled{
 @Unique private float cw$size=1;@Unique private int cw$side=0;public void cw$held(int side){cw$side=side;}public void cw$scale(float f){cw$size=f;}
 @Inject(method="clear",at=@At("HEAD"))private void reset(CallbackInfo c){cw$size=1;cw$side=0;}
 @Inject(method="submit",at=@At("HEAD"))private void push(PoseStack p,SubmitNodeCollector s,int l,int o,int col,CallbackInfo c){if(cw$size!=1){p.pushPose();if(cw$side!=0)p.translate(.08*cw$side*(cw$size-1),-.12*(cw$size-1),0);p.scale(cw$size,cw$size,cw$size);}}
 @Inject(method="submit",at=@At("RETURN"))private void pop(PoseStack p,SubmitNodeCollector s,int l,int o,int col,CallbackInfo c){if(cw$size!=1)p.popPose();}}
