package dev.susu.compressionworld;

import java.util.*;
import java.util.stream.IntStream;
import net.minecraft.core.*;
import net.minecraft.core.dispenser.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.*;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.phys.*;

public final class Automation {
    public static boolean signal(Machine m){var w=m.root.getLevel();int n=CW.size(m.level());for(var q:BlockPos.betweenClosed(m.root.getBlockPos(),m.root.getBlockPos().offset(n-1,n-1,n-1)))if(w.hasNeighborSignal(q))return true;return false;}
    public static Container giantContainer(GiantEntity root){
        if(root.item.isEmpty())return null;
        if(root.furnace.enabled())return new Access(root,root.furnace.items.size(),true);
        var m=root.machine();if(m.kind==Machine.Kind.NONE||m.kind==Machine.Kind.ENDER||m.kind==Machine.Kind.BEACON)return null;
        return new Access(root,m.inv.getContainerSize(),false);
    }
    public static Container at(Level w,BlockPos p){if(!w.hasChunkAt(p))return null;var s=w.getBlockState(p);if(s.is(CW.GIANT)&&w.getBlockEntity(GiantBlock.root(p,s)) instanceof GiantEntity root)return giantContainer(root);return HopperBlockEntity.getContainerAt(w,p);}
    private static boolean puttable(Container target,int slot,ItemStack s,Direction face){return target.canPlaceItem(slot,s)&&(!(target instanceof WorldlyContainer side)||side.canPlaceItemThroughFace(slot,s,face)&&IntStream.of(side.getSlotsForFace(face)).anyMatch(i->i==slot));}
    private static boolean takeable(Container source,Container target,int slot,Direction face){return source.canTakeItem(target,slot,source.getItem(slot))&&(!(source instanceof WorldlyContainer side)||side.canTakeItemThroughFace(slot,source.getItem(slot),face)&&IntStream.of(side.getSlotsForFace(face)).anyMatch(i->i==slot));}
    public static int transfer(Container source,Container target,int limit,Direction sourceFace,Direction targetFace){
        if(source==null||target==null||source==target)return 0;int moved=0;
        for(int i=0;i<source.getContainerSize()&&moved<limit;i++){
            var s=source.getItem(i);if(s.isEmpty()||!takeable(source,target,i,sourceFace))continue;
            var offer=s.copyWithCount(Math.min(s.getCount(),limit-moved));var rest=MachineInventory.insert(target,offer,j->puttable(target,j,offer,targetFace));int n=offer.getCount()-rest.getCount();
            if(n>0){s.shrink(n);source.setChanged();moved+=n;}
        }return moved;
    }
    public static void hopper(Machine m){
        if(signal(m))return;var w=(ServerLevel)m.root.getLevel();var p=m.root.getBlockPos();int n=CW.size(m.level());
        var face=m.root.source.getValue(HopperBlock.FACING);var from=new Access(m.root,m.inv.getContainerSize(),false);
        BlockPos outlet=p.offset(n/2,n/2,n/2).relative(face,face.getAxisDirection()==Direction.AxisDirection.POSITIVE?n-n/2:n/2+1);
        transfer(from,at(w,outlet),m.factor(),face,face.getOpposite());
        var above=p.offset(n/2,n,n/2);int sucked=transfer(at(w,above),from,m.factor(),Direction.DOWN,Direction.UP);
        if(sucked<m.factor())for(var e:w.getEntitiesOfClass(ItemEntity.class,new AABB(p.getX()-m.level(),p.getY()+n-.2,p.getZ()-m.level(),p.getX()+n+m.level(),p.getY()+n+2,p.getZ()+n+m.level()))){
            if(sucked>=m.factor())break;var s=e.getItem();int amount=Math.min(s.getCount(),m.factor()-sucked);var offer=s.copyWithCount(amount);var rest=MachineInventory.insert(from,offer,i->true);int moved=amount-rest.getCount();s.shrink(moved);sucked+=moved;if(s.isEmpty())e.discard();else e.setItem(s);
        }
    }
    public static void dispense(Machine m){
        var w=(ServerLevel)m.root.getLevel();int n=CW.size(m.level());var face=m.root.source.getValue(DispenserBlock.FACING);var center=m.root.getBlockPos().offset(n/2,n/2,n/2);
        var mouth=center.relative(face,face.getAxisDirection()==Direction.AxisDirection.POSITIVE?n-n/2-1:n/2);var target=mouth.relative(face);
        for(int shot=0;shot<m.factor();shot++){
            List<Integer> occupied=new ArrayList<>();for(int i=0;i<m.inv.getContainerSize();i++)if(!m.inv.getItem(i).isEmpty())occupied.add(i);if(occupied.isEmpty())break;
            int index=occupied.get(w.getRandom().nextInt(occupied.size()));var stack=m.inv.getItem(index);ItemStack one=stack.copyWithCount(1),remaining=ItemStack.EMPTY;
            if(m.kind==Machine.Kind.DROPPER){
                var container=at(w,target);if(container!=null){var left=MachineInventory.insert(container,one,i->puttable(container,i,one,face.getOpposite()));if(!left.isEmpty())continue;}
                else{var e=new ItemEntity(w,target.getX()+.5,target.getY()+.5,target.getZ()+.5,one);e.setDeltaMovement(face.getStepX()*.2,face.getStepY()*.2+.1,face.getStepZ()*.2);w.addFreshEntity(e);}
            }else if(CW.lv(one)>0&&WaterOps.bucket(one)){
                boolean collect=WaterOps.amount(one)==0;int cap=CW.material(CW.lv(one));int moved=WaterOps.transfer(w,target,CW.lv(one),collect?cap:WaterOps.amount(one),collect,null,one);
                if(moved==0)continue;remaining=WaterOps.withAmount(one,WaterOps.amount(one)+(collect?moved:-moved));
            }else{
                var virtual=new DispenserBlockEntity(mouth,m.root.source){public ItemStack insertItem(ItemStack s){return MachineInventory.insert(m.inv,s,i->true);}};virtual.setLevel(w);
                var source=new BlockSource(w,mouth,m.root.source,virtual);
                var behavior=DispenserBlock.DISPENSER_REGISTRY.getOrDefault(one.getItem(),new DefaultDispenseItemBehavior());
                remaining=behavior.dispense(source,one);
            }
            stack.shrink(1);if(!remaining.isEmpty()){if(stack.isEmpty())m.inv.setItem(index,remaining);else{var left=MachineInventory.insert(m.inv,remaining,i->true);if(!left.isEmpty())Block.popResource(w,target,left);}}m.root.setChanged();
        }
    }
    public static final class Access extends SimpleContainer implements WorldlyContainer {
        final GiantEntity root;final boolean furnace;
        public Access(GiantEntity root,int size,boolean furnace){super(size);this.root=root;this.furnace=furnace;}
        public ItemStack getItem(int i){return furnace?root.furnace.items.get(i):root.machine().inv.getItem(i);}
        public void setItem(int i,ItemStack s){if(furnace)root.furnace.items.set(i,s);else root.machine().inv.setItem(i,s);setChanged();}
        public ItemStack removeItem(int i,int n){var out=getItem(i).split(n);setChanged();return out;}
        public ItemStack removeItemNoUpdate(int i){var s=getItem(i);setItem(i,ItemStack.EMPTY);return s;}
        public void setChanged(){if(root!=null)root.setChanged();}
        public boolean isEmpty(){for(int i=0;i<getContainerSize();i++)if(!getItem(i).isEmpty())return false;return true;}
        public void clearContent(){for(int i=0;i<getContainerSize();i++)setItem(i,ItemStack.EMPTY);}
        public boolean stillValid(net.minecraft.world.entity.player.Player p){return !root.isRemoved();}
        public boolean canPlaceItem(int i,ItemStack s){return furnace?i<root.furnace.lanes()*3&&(i%3==0?root.furnace.canInput(s):i%3==1&&root.furnace.fuelTicks(s)>0):root.machine().accepts(i,s);}
        public boolean canTakeItem(Container c,int i,ItemStack s){if(furnace)return i%3==2||i%3==1&&s.is(Items.BUCKET);return switch(root.machine().kind){case CRAFT,CRAFTER->i>=9;case STONE,COMPOST->i==1;case ENCHANT->i==2;case GRIND->i>=2;case SMITH->i==3;case CAMPFIRE->i%2==1;default->true;};}
        public int[] getSlotsForFace(Direction side){int size=furnace?root.furnace.lanes()*3:getContainerSize();return IntStream.range(0,size).filter(i->!furnace||side==Direction.UP?(!furnace||i%3==0):side==Direction.DOWN?i%3!=0:i%3==1).toArray();}
        public boolean canPlaceItemThroughFace(int i,ItemStack s,Direction side){return canPlaceItem(i,s);}
        public boolean canTakeItemThroughFace(int i,ItemStack s,Direction side){return canTakeItem(this,i,s);}
    }
}
