package dev.susu.compressionworld;

import java.util.*;
import com.mojang.math.Transformation;
import org.joml.Vector3f;
import org.joml.Quaternionf;
import dev.susu.compressionworld.mixin.*;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.*;
import net.minecraft.world.item.*;
import net.minecraft.world.phys.AABB;

/** A bounded sample of cooking items; the inventory remains the sole owner of real items. */
public final class CampfireDisplay {
    private static String tag(BlockPos pos){return "cw_campfood_"+pos.asLong();}
    public static void clear(ServerLevel w,BlockPos pos){
        for(var d:w.getEntitiesOfClass(Display.ItemDisplay.class,new AABB(pos).inflate(12),e->e.entityTags().contains(tag(pos))))d.discard();
    }
    public static void sync(ServerLevel w,Machine m){
        var pos=m.root.getBlockPos();var marker=tag(pos);
        var existing=w.getEntitiesOfClass(Display.ItemDisplay.class,new AABB(pos).inflate(12),e->e.entityTags().contains(marker));
        Map<Integer,Display.ItemDisplay> displays=new HashMap<>();
        for(var d:existing){int index=-1;for(int i=0;i<8;i++)if(d.entityTags().contains("cw_food_slot_"+i)){index=i;break;}
            if(index<0||displays.putIfAbsent(index,d)!=null)d.discard();}
        List<ItemStack> sample=new ArrayList<>();for(int lane=0;lane<4*m.factor()&&sample.size()<8;lane++){
            var s=m.inv.getItem(lane*2);if(s.isEmpty())s=m.inv.getItem(lane*2+1);if(!s.isEmpty())sample.add(s.copyWithCount(1));}
        float edge=CW.size(m.level());
        for(int i=0;i<8;i++){
            var d=displays.get(i);if(i>=sample.size()){if(d!=null)d.discard();continue;}
            if(d==null){d=new Display.ItemDisplay(EntityTypes.ITEM_DISPLAY,w);d.addTag(marker);d.addTag("cw_food_slot_"+i);}
            d.setPos(pos.getX()+edge*(.17+(i%4)*.22),pos.getY()+edge*.46+.05,pos.getZ()+edge*(.30+(i/4)*.40));
            ((ItemAccess)d).cw$item(CW.convert(sample.get(i),0));((ItemAccess)d).cw$context(ItemDisplayContext.NONE);
            var access=(DisplayAccess)d;access.cw$transform(new Transformation(new Vector3f(),new Quaternionf().rotationX((float)-Math.PI/2),new Vector3f(edge*.25f),null));access.cw$width(edge);access.cw$height(edge);
            if(!displays.containsKey(i))w.addFreshEntity(d);
        }
    }
}
