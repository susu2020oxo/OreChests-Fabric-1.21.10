package dev.susu.compressionworld;
import net.minecraft.core.NonNullList;import net.minecraft.world.item.*;import net.minecraft.world.item.crafting.*;import net.minecraft.world.level.Level;
public final class CompressRecipe extends CustomRecipe{
 public boolean matches(CraftingInput in,Level w){if(in.ingredientCount()!=4)return false;ItemStack first=ItemStack.EMPTY;for(ItemStack s:in.items()){if(s.isEmpty())continue;if(s.is(CW.PRESS)||CW.lv(s)>=5||UpgradeData.loadedContainer(s))return false;if(first.isEmpty())first=s;else if(!ItemStack.isSameItemSameComponents(first,s))return false;}if(in.width()==3&&in.height()==3&&in.getItem(0).isEmpty()&&in.getItem(2).isEmpty()&&in.getItem(4).isEmpty()&&in.getItem(6).isEmpty()&&in.getItem(8).isEmpty())return !first.isEmpty();if(!first.isEmpty()&&CW.lv(first)==0&&w instanceof net.minecraft.server.level.ServerLevel sw){for(var holder:sw.getServer().getRecipeManager().getRecipes()){if(holder.value() instanceof CraftingRecipe other && !(other instanceof CompressRecipe) && holder.id().identifier().getNamespace().equals("minecraft") && other.matches(in,w))return false;}}return !first.isEmpty();}
 public ItemStack assemble(CraftingInput in){if(!matches(in,null))return ItemStack.EMPTY;var s=in.items().stream().filter(i->!i.isEmpty()).findFirst().orElseThrow();return CW.convert(s,CW.lv(s)+1);}
 public NonNullList<ItemStack> getRemainingItems(CraftingInput in){return NonNullList.withSize(in.size(),ItemStack.EMPTY);}
 public RecipeSerializer<CompressRecipe> getSerializer(){return CW.RECIPE;}
}
