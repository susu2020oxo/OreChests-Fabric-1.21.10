package dev.susu.compressionworld;
import net.minecraft.world.Container;
public interface EnderStorage { Container cw$ender(); }
