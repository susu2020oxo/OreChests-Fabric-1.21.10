package dev.susu.compressionworld;

import java.util.*;
import java.lang.reflect.*;
import net.fabricmc.fabric.api.entity.FakePlayer;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.minecraft.core.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.*;
import net.minecraft.server.level.*;
import net.minecraft.world.*;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.animal.sheep.Sheep;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.projectile.throwableitemprojectile.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.item.alchemy.*;
import net.minecraft.world.item.crafting.*;
import net.minecraft.world.item.enchantment.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.phys.*;

/** Destructive integration suite. Runs only with the existing disposable-world selftest flag. */
public final class FunctionalValidation {
    static int next=160;
    static void ok(boolean yes,String name){Validation.ok(yes,"beta3 "+name);}
    static GiantEntity place(ServerLevel w,Block block,Item item,int level){
        var p=new BlockPos(next,220,96);next+=16;
        for(var e:w.getEntitiesOfClass(LivingEntity.class,new AABB(p).inflate(8)))e.discard();
        for(int x=(p.getX()-16)>>4;x<=(p.getX()+16)>>4;x++)for(int z=4;z<=7;z++)w.getChunk(x,z);
        for(var q:BlockPos.betweenClosed(p.offset(-6,-6,-6),p.offset(8,8,8)))if(w.getBlockState(q).is(CW.GIANT)&&w.getBlockEntity(GiantBlock.root(q,w.getBlockState(q))) instanceof GiantEntity old)Giants.remove(w,old);else if(!w.getBlockState(q).isAir())w.setBlock(q,Blocks.AIR.defaultBlockState(),3);
        ok(Giants.place(w,p,block.defaultBlockState(),CW.convert(new ItemStack(item),level),null,Direction.UP),"place "+item);
        return (GiantEntity)w.getBlockEntity(p);
    }
    static int itemCount(ServerLevel w,BlockPos at,Item type){return w.getEntitiesOfClass(ItemEntity.class,new AABB(at).inflate(8)).stream().filter(e->e.getItem().is(type)).mapToInt(e->e.getItem().getCount()).sum();}
    public static void run(MinecraftServer server)throws Exception{
        var w=server.overworld();var player=FakePlayer.get(w,new com.mojang.authlib.GameProfile(UUID.randomUUID(),"Beta3_QA"));player.setHealth(player.getMaxHealth());
        var chest=place(w,Blocks.CHEST,Items.CHEST,5);var storage=chest.machine();ok(storage.inv.getContainerSize()==864,"864 storage slots");storage.inv.setItem(863,new ItemStack(Items.DIAMOND,7));storage.inv.setItem(0,new ItemStack(Items.STONE,10));
        var loaded=(GiantEntity)BlockEntity.loadStatic(chest.getBlockPos(),chest.getBlockState(),chest.saveWithFullMetadata(w.registryAccess()),w.registryAccess());ok(loaded.machine().inv.getItem(863).getCount()==7,"last storage page persisted");
        player.setPos(chest.getBlockPos().getX(),220,94);var menu=new MachineMenu(8,player.getInventory(),storage,storage.inv,864);
        for(int i=0;i<19;i++)menu.clicked(46,0,ContainerInput.PICKUP,player);ok(menu.page==19&&menu.mapped(8)==863,"last page navigation");menu.quickMoveStack(player,8);ok(storage.inv.getItem(863).isEmpty()&&player.getInventory().countItem(Items.DIAMOND)==7,"last page shift transfer");ok(!menu.slots.get(46).mayPickup(player),"buttons protected");
        var shulker=place(w,Blocks.SHULKER_BOX,Items.SHULKER_BOX,2);shulker.machine().inv.setItem(100,new ItemStack(Items.EMERALD,13));var pos=shulker.getBlockPos();Giants.destroy(w,pos,w.getBlockState(pos),null,new ItemStack(Items.DIAMOND_PICKAXE));
        var packed=w.getEntitiesOfClass(ItemEntity.class,new AABB(pos).inflate(4)).stream().map(ItemEntity::getItem).filter(s->s.is(Items.SHULKER_BOX)).findFirst().orElseThrow();ok(CW.lv(packed)==2&&packed.get(UpgradeData.CARGO).get(100).getCount()==13,"shulker packed inventory");
        ok(!new CompressRecipe().matches(CraftingInput.of(2,2,List.of(packed,packed,packed,packed)),w),"filled container compression denied");
        ok(Giants.place(w,pos,Blocks.SHULKER_BOX.defaultBlockState(),packed,null,Direction.UP),"shulker replace");ok(((GiantEntity)w.getBlockEntity(pos)).machine().inv.getItem(100).getCount()==13,"shulker contents restored exactly");
        var privateInv=((EnderStorage)player).cw$ender();privateInv.setItem(863,new ItemStack(Items.GOLD_INGOT,17));var other=FakePlayer.get(w,new com.mojang.authlib.GameProfile(UUID.randomUUID(),"Beta3_Other"));ok(((EnderStorage)other).cw$ender().getItem(863).isEmpty(),"ender storage privacy");ServerPlayerEvents.COPY_FROM.invoker().copyFromPlayer(player,other,false);ok(((EnderStorage)other).cw$ender().getItem(863).getCount()==17,"ender storage death copy");
        var savedPlayer=net.minecraft.world.level.storage.TagValueOutput.createWithContext(net.minecraft.util.ProblemReporter.DISCARDING,w.registryAccess());player.saveWithoutId(savedPlayer);((EnderStorage)other).cw$ender().setItem(863,ItemStack.EMPTY);other.load(net.minecraft.world.level.storage.TagValueInput.create(net.minecraft.util.ProblemReporter.DISCARDING,w.registryAccess(),savedPlayer.buildResult()));ok(((EnderStorage)other).cw$ender().getItem(863).getCount()==17,"ender extra slots survive player NBT reload");
        var craft=place(w,Blocks.CRAFTING_TABLE,Items.CRAFTING_TABLE,2).machine();craft.inv.setItem(0,new ItemStack(Items.OAK_LOG,4));ok(MachineWork.craft(craft,4,player)==4,"batch workbench count");ok(craft.inv.getItem(9).is(Items.OAK_PLANKS)&&craft.inv.getItem(9).getCount()==16&&craft.inv.getItem(0).isEmpty(),"batch material conservation");
        var stone=place(w,Blocks.STONECUTTER,Items.STONECUTTER,1).machine();stone.inv.setItem(0,CW.convert(new ItemStack(Items.STONE),2).copyWithCount(4));MachineWork.stone(stone,2);ok(stone.inv.getItem(0).getCount()==2&&CW.lv(stone.inv.getItem(1))==2,"compressed stone recipe");
        var enchant=place(w,Blocks.ENCHANTING_TABLE,Items.ENCHANTING_TABLE,2).machine();var ep=enchant.root.getBlockPos();ok(Structures.shelfLevel(enchant)==0,"no shelf boost without shelves");
        int[][] offsets={{-5,0},{5,0},{0,-5},{0,5}};for(var off:offsets){var bp=ep.offset(off[0],0,off[1]);w.getChunkAt(bp);ok(Giants.place(w,bp,Blocks.BOOKSHELF.defaultBlockState(),CW.convert(new ItemStack(Items.BOOKSHELF),1),null,Direction.UP),"shelf placement");}
        ok(Structures.shelfLevel(enchant)==1,"shelf level limits table");player.experienceLevel=50;enchant.inv.setItem(0,new ItemStack(Items.DIAMOND_SWORD));enchant.inv.setItem(1,new ItemStack(Items.LAPIS_LAZULI,8));Structures.enchant(enchant,player);
        var enchanted=enchant.inv.getItem(2);ok(!EnchantmentHelper.getEnchantmentsForCrafting(enchanted).isEmpty()&&player.experienceLevel==47&&enchant.inv.getItem(1).getCount()==5,"enchant actual consumption");
        for(var e:EnchantmentHelper.getEnchantmentsForCrafting(enchanted).entrySet())if(e.getKey().value().getMaxLevel()>1)ok(e.getIntValue()%2==0&&e.getIntValue()<=e.getKey().value().getMaxLevel()*2,"tier one enchant multiplier");
        var grind=place(w,Blocks.GRINDSTONE,Items.GRINDSTONE,1).machine();grind.inv.setItem(0,enchanted.copy());grind.inv.setItem(1,new ItemStack(Items.BOOK));MachineWork.grind(grind,player,true);ok(grind.inv.getItem(0).isEmpty()&&grind.inv.getItem(1).isEmpty()&&grind.inv.getItem(3).is(Items.ENCHANTED_BOOK)&&!EnchantmentHelper.hasAnyEnchantments(grind.inv.getItem(2)),"grind extraction transfers not duplicates");
        grind.inv.clearContent();var worn1=CW.convert(new ItemStack(Items.DIAMOND_SWORD),1);worn1.setDamageValue(1000);grind.inv.setItem(0,worn1);grind.inv.setItem(1,worn1.copy());MachineWork.grind(grind,player,false);ok(!grind.inv.getItem(2).isEmpty()&&CW.lv(grind.inv.getItem(2))==1&&grind.inv.getItem(2).getDamageValue()<1000,"grind native two-item repair");
        var anvil=place(w,Blocks.ANVIL,Items.ANVIL,2);player.setPos(anvil.getBlockPos().getX(),220,94);var am=new GiantAnvilMenu(9,player.getInventory(),anvil);var damaged=new ItemStack(Items.DIAMOND_SWORD);damaged.setDamageValue(1000);am.getSlot(0).set(damaged);am.getSlot(1).set(new ItemStack(Items.DIAMOND));am.createResult();ok(am.getSlot(2).hasItem()&&am.getSlot(2).getItem().getDamageValue()==0,"anvil enhanced material repair");
        var sharp=w.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.SHARPNESS);var sword=new ItemStack(Items.DIAMOND_SWORD);sword.enchant(sharp,10);var book=new ItemStack(Items.ENCHANTED_BOOK);book.set(DataComponents.STORED_ENCHANTMENTS,new ItemEnchantments.Mutable(ItemEnchantments.EMPTY){{set(sharp,10);}}.toImmutable());am.getSlot(0).set(sword);am.getSlot(1).set(book);am.createResult();ok(EnchantmentHelper.getItemEnchantmentLevel(sharp,am.getSlot(2).getItem())==11,"anvil preserves high level merge");
        var smith=place(w,Blocks.SMITHING_TABLE,Items.SMITHING_TABLE,2).machine();smith.inv.setItem(0,CW.convert(new ItemStack(Items.NETHERITE_UPGRADE_SMITHING_TEMPLATE),2));smith.inv.setItem(1,CW.convert(damaged,2));smith.inv.setItem(2,CW.convert(new ItemStack(Items.NETHERITE_INGOT),2));MachineWork.smith(smith);ok(smith.inv.getItem(3).is(Items.NETHERITE_SWORD)&&CW.lv(smith.inv.getItem(3))==2&&smith.inv.getItem(0).isEmpty(),"smith compressed equipment");
        var brew=place(w,Blocks.BREWING_STAND,Items.BREWING_STAND,1).machine();for(int lane=0;lane<2;lane++){int i=lane*5;for(int b=0;b<3;b++)brew.inv.setItem(i+b,PotionContents.createItemStack(Items.POTION,Potions.AWKWARD));brew.inv.setItem(i+3,CW.convert(new ItemStack(Items.PUFFERFISH),1));brew.inv.setItem(i+4,new ItemStack(Items.BLAZE_POWDER));}
        for(int t=0;t<400;t++)brew.tick(w);for(int lane=0;lane<2;lane++){var effects=brew.inv.getItem(lane*5).get(DataComponents.POTION_CONTENTS);ok(effects!=null&&effects.getAllEffects().iterator().next().getDuration()==7200,"brew compressed pufferfish water breathing");ok(brew.inv.getItem(lane*5+3).isEmpty()&&brew.fuel[lane]==19,"brew reagent and fuel consumption");}
        var camp=place(w,Blocks.CAMPFIRE,Items.CAMPFIRE,1).machine();for(int i=0;i<8;i++)camp.inv.setItem(i*2,new ItemStack(Items.COD));for(int t=0;t<600;t++)camp.tick(w);for(int i=0;i<8;i++)ok(camp.inv.getItem(i*2+1).is(Items.COOKED_COD),"campfire parallel cooking");
        CampfireDisplay.sync(w,camp);CampfireDisplay.sync(w,camp);ok(w.getEntitiesOfClass(Display.ItemDisplay.class,new AABB(camp.root.getBlockPos()).inflate(12),e->e.entityTags().contains("cw_campfood_"+camp.root.getBlockPos().asLong())).size()==8,"campfire visible food bounded and deduplicated");
        var compost=place(w,Blocks.COMPOSTER,Items.COMPOSTER,1).machine();compost.inv.setItem(0,CW.convert(new ItemStack(Items.PUMPKIN_PIE),1).copyWithCount(2));var compostTick=Machine.class.getDeclaredMethod("compost",ServerLevel.class);compostTick.setAccessible(true);for(int t=0;t<20;t++)compostTick.invoke(compost,w);ok(compost.inv.getItem(1).is(Items.BONE_MEAL),"compressed compost material value");
        var bucket=CW.convert(new ItemStack(Items.WATER_BUCKET),3);ok(WaterOps.amount(bucket)==64,"compressed water initial capacity");var pond=new BlockPos(next,220,96);for(int x=(next-16)>>4;x<=(next+16)>>4;x++)w.getChunk(x,6);next+=32;
        int placed=WaterOps.transfer(w,pond,3,64,false,null,bucket);ok(placed==49,"bounded water placement");int collected=WaterOps.transfer(w,pond,3,64,true,null,bucket);ok(collected==49,"water collection matches actual source blocks");ok(WaterOps.amount(WaterOps.withAmount(bucket,15))==15,"partial bucket tracks actual volume");
        var cauldron=place(w,Blocks.CAULDRON,Items.CAULDRON,1).machine();cauldron.inv.setItem(0,CW.convert(new ItemStack(Items.WATER_BUCKET),1));WaterOps.cauldronSlots(cauldron,true);ok(cauldron.water==4&&cauldron.inv.getItem(1).is(Items.BUCKET),"cauldron receives stored water");
        var hop=place(w,Blocks.HOPPER,Items.HOPPER,2).machine();var destination=new MachineInventory(2,()->{});hop.inv.setItem(0,new ItemStack(Items.IRON_INGOT,20));ok(Automation.transfer(Automation.giantContainer(hop.root),destination,4,Direction.DOWN,Direction.UP)==4&&hop.inv.getItem(0).getCount()==16,"hopper transfer budget");
        var furnace=place(w,Blocks.FURNACE,Items.FURNACE,2);hop.inv.setItem(0,new ItemStack(Items.RAW_IRON,8));hop.inv.setItem(1,new ItemStack(Items.COAL,8));Automation.transfer(hop.inv,Automation.giantContainer(furnace),4,Direction.DOWN,Direction.UP);ok(furnace.furnace.items.get(0).is(Items.RAW_IRON),"hopper furnace top input");Automation.transfer(hop.inv,Automation.giantContainer(furnace),4,Direction.DOWN,Direction.NORTH);ok(furnace.furnace.items.get(1).is(Items.COAL),"hopper furnace side fuel");
        var dispenser=place(w,Blocks.DISPENSER,Items.DISPENSER,2).machine();dispenser.inv.setItem(0,CW.convert(new ItemStack(Items.EXPERIENCE_BOTTLE),1).copyWithCount(8));Automation.dispense(dispenser);ok(dispenser.inv.getItem(0).getCount()==4,"dispenser emits four charged bottles");
        var bottle=w.getEntitiesOfClass(ThrownExperienceBottle.class,new AABB(dispenser.root.getBlockPos()).inflate(10)).stream().findFirst().orElseThrow();ok(CW.lv(bottle.getItem())==1,"dispenser preserves bottle compression");
        var onHit=ThrownExperienceBottle.class.getDeclaredMethod("onHit",HitResult.class);onHit.setAccessible(true);var bx=bottle.position();int xpBefore=w.getEntitiesOfClass(ExperienceOrb.class,new AABB(bx,bx).inflate(4)).stream().mapToInt(ExperienceOrb::getValue).sum();onHit.invoke(bottle,new BlockHitResult(bx,Direction.UP,bottle.blockPosition(),false));int xp=w.getEntitiesOfClass(ExperienceOrb.class,new AABB(bx,bx).inflate(4)).stream().mapToInt(ExperienceOrb::getValue).sum()-xpBefore;ok(xp>=30&&xp<=110&&xp%10==0,"experience bottle actual impact x10");
        var totem=CW.convert(new ItemStack(Items.TOTEM_OF_UNDYING),2);var bearer=EntityTypes.ZOMBIE.create(w,EntitySpawnReason.COMMAND);bearer.setPos(next,220,96);w.getChunkAt(bearer.blockPosition());w.addFreshEntity(bearer);bearer.setItemInHand(InteractionHand.MAIN_HAND,totem);bearer.setHealth(1);bearer.invulnerableTime=0;bearer.hurtServer(w,bearer.damageSources().generic(),10000);ok(bearer.isAlive()&&totem.getOrDefault(UpgradeData.USES,0)==3,"actual totem saves and consumes one charge");bearer.discard();
        var milk=CW.convert(new ItemStack(Items.MILK_BUCKET),1);player.addEffect(new MobEffectInstance(MobEffects.POISON,200,0));var remaining=milk.finishUsingItem(w,player);ok(remaining.is(Items.MILK_BUCKET)&&remaining.get(UpgradeData.USES)==1&&!player.hasEffect(MobEffects.POISON),"milk removes effects and retains charge");remaining=remaining.finishUsingItem(w,player);ok(remaining.is(Items.BUCKET)&&CW.lv(remaining)==1,"milk final use returns compressed bucket");
        var puff=CW.convert(new ItemStack(Items.PUFFERFISH),2);puff.finishUsingItem(w,player);ok(player.hasEffect(UpgradeEffects.TOXIC)&&player.getEffect(UpgradeEffects.TOXIC).getAmplifier()==1,"pufferfish applies scaled poison");player.removeAllEffects();
        var potion=PotionContents.createItemStack(Items.POTION,Potions.SWIFTNESS);CW.convert(potion,2).finishUsingItem(w,player);ok(player.hasEffect(MobEffects.SPEED)&&player.getEffect(MobEffects.SPEED).getAmplifier()==3,"compressed drink potion strength");player.removeAllEffects();
        var sheep=EntityTypes.SHEEP.create(w,EntitySpawnReason.COMMAND);sheep.setPos(next,220,96);w.getChunkAt(sheep.blockPosition());w.addFreshEntity(sheep);int woolBefore=w.getEntitiesOfClass(ItemEntity.class,new AABB(sheep.blockPosition()).inflate(3)).stream().mapToInt(e->e.getItem().getCount()).sum();sheep.shear(w,net.minecraft.sounds.SoundSource.PLAYERS,CW.convert(new ItemStack(Items.SHEARS),2));int wool=w.getEntitiesOfClass(ItemEntity.class,new AABB(sheep.blockPosition()).inflate(3)).stream().mapToInt(e->e.getItem().getCount()).sum()-woolBefore;ok(wool>=4&&wool<=12&&wool%4==0,"shears actual wool multiplier");sheep.discard();
        var beacon=place(w,Blocks.BEACON,Items.BEACON,1).machine();var bp=beacon.root.getBlockPos();for(int x=-1;x<=1;x++)for(int z=-1;z<=1;z++)ok(Giants.place(w,bp.offset(x*2,-2,z*2),Blocks.IRON_BLOCK.defaultBlockState(),CW.convert(new ItemStack(Items.IRON_BLOCK),1),null,Direction.UP),"beacon base tile");ok(Structures.base(beacon)[0]==1,"beacon compressed pyramid recognized");player.setPos(bp.getX()+5,220,bp.getZ());w.addFreshEntity(player);beacon.powered=true;Structures.beacon(beacon);ok(player.hasEffect(MobEffects.SPEED)&&player.getEffect(MobEffects.SPEED).getAmplifier()==2,"beacon strength x3");
        for(int l=1;l<=5;l++)ok(Math.abs(UpgradeData.handScale(l)-(1+.15f*l))<.0001&&UpgradeData.handScale(l)<=1.75,"held scale cap");
        for(var e:w.getEntitiesOfClass(LivingEntity.class,new AABB(-100,180,-100,2000,300,300)))if(e!=player&&e!=other)e.discard();
    }
}
