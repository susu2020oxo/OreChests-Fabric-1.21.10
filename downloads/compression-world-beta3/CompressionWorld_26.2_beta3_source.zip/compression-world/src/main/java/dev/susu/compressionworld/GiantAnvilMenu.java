package dev.susu.compressionworld;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.inventory.*;
public final class GiantAnvilMenu extends AnvilMenu {
    public final GiantEntity root;
    public GiantAnvilMenu(int id,Inventory inv,GiantEntity root){super(id,inv,ContainerLevelAccess.NULL);this.root=root;}
    public void removed(Player p){super.removed(p);clearContainer(p,inputSlots);}
    public int factor(){return root==null?1:CW.power(CW.lv(root.item));}
    public boolean stillValid(Player p){return root!=null&&!root.isRemoved()&&root.getLevel()==p.level()&&p.distanceToSqr(root.getBlockPos().getX()+.5,root.getBlockPos().getY()+.5,root.getBlockPos().getZ()+.5)<256;}
}
