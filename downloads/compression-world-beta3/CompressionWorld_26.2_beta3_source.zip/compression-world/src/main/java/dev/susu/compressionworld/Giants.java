package dev.susu.compressionworld;
import com.mojang.math.Transformation;import org.joml.Vector3f;import dev.susu.compressionworld.mixin.*;import net.minecraft.core.*;import net.minecraft.core.component.DataComponents;import net.minecraft.network.chat.Component;import net.minecraft.server.level.ServerLevel;import net.minecraft.world.*;import net.minecraft.world.entity.*;import net.minecraft.world.entity.player.Player;import net.minecraft.world.item.*;import net.minecraft.world.item.context.*;import net.minecraft.world.level.*;import net.minecraft.world.level.block.*;import net.minecraft.world.level.block.state.*;import net.minecraft.world.level.block.state.properties.IntegerProperty;import net.minecraft.world.phys.*;
public final class Giants{
 static boolean removing;
 public static InteractionResult use(Player p,Level w,InteractionHand h,BlockHitResult hit){var held=p.getItemInHand(h);var clicked=w.getBlockState(hit.getBlockPos());
  if(clicked.is(CW.GIANT)&&!p.isSpectator()){
   var at=GiantBlock.root(hit.getBlockPos(),clicked);if(w.getBlockEntity(at) instanceof GiantEntity root){
    if(root.machine().kind==Machine.Kind.CAULDRON&&WaterOps.bucket(held)&&CW.lv(held)>0)return WaterOps.use(w,p,h);
    if(root.source.getBlock() instanceof AnvilBlock&&!p.isShiftKeyDown()){if(w instanceof ServerLevel)p.openMenu(new net.minecraft.world.SimpleMenuProvider((id,inv,user)->new GiantAnvilMenu(id,inv,root),Component.literal("压缩铁砧")));return InteractionResult.SUCCESS;}
    if(root.machine().kind!=Machine.Kind.NONE&&!p.isShiftKeyDown()){if(w instanceof ServerLevel)root.machine().open(p);return InteractionResult.SUCCESS;}
    if(root.furnace.enabled()&&!p.isShiftKeyDown()){if(w instanceof ServerLevel)p.openMenu(new net.minecraft.world.SimpleMenuProvider((id,inv,user)->new FurnaceMenu(id,inv,root.furnace),Component.literal("压缩熔炉 · "+root.furnace.lanes()+"组并行")));return InteractionResult.SUCCESS;}
    if(root.source.is(Blocks.TNT)&&(held.is(Items.FLINT_AND_STEEL)||held.is(Items.FIRE_CHARGE))){if(w instanceof ServerLevel sw&&CompressedTnt.prime(sw,root,p,80)){if(held.is(Items.FLINT_AND_STEEL))held.hurtAndBreak(1,p,h);else held.consume(1,p);}return InteractionResult.SUCCESS;}
   }
  }
  if(clicked.is(CW.GIANT)&&held.is(Items.BONE_MEAL)){if(w instanceof ServerLevel sw&&w.getBlockEntity(GiantBlock.root(hit.getBlockPos(),clicked)) instanceof GiantEntity e&&grow(sw,e,true))held.consume(1,p);return InteractionResult.SUCCESS;}
  if(CW.lv(held)==0||!(held.getItem() instanceof BlockItem bi)||p.isSpectator())return InteractionResult.PASS;if(w.isClientSide())return InteractionResult.SUCCESS;
  var context=new BlockPlaceContext(new UseOnContext(p,h,hit));var source=bi.getBlock().getStateForPlacement(context);if(source==null)return InteractionResult.FAIL;
  int n=CW.size(CW.lv(held));var origin=context.getClickedPos();switch(hit.getDirection()){case WEST->origin=origin.west(n-1);case NORTH->origin=origin.north(n-1);case DOWN->origin=origin.below(n-1);default->{}}
  if(!place((ServerLevel)w,origin,source,held,p,hit.getDirection())){p.sendOverlayMessage(Component.literal("需要 "+n+"×"+n+"×"+n+" 格空位，不能覆盖方块或玩家。"));return InteractionResult.FAIL;}held.consume(1,p);return InteractionResult.SUCCESS;
 }
 public static boolean place(ServerLevel w,BlockPos p,BlockState source,ItemStack item,Player player,Direction face){int n=CW.size(CW.lv(item));
  for(var pos:BlockPos.betweenClosed(p,p.offset(n-1,n-1,n-1))){if(!w.hasChunkAt(pos)||w.isOutsideBuildHeight(pos)||!w.getWorldBorder().isWithinBounds(pos)||!w.getBlockState(pos).canBeReplaced()||w.getBlockEntity(pos)!=null)return false;if(player!=null&&(!w.mayInteract(player,pos)||!player.mayUseItemAt(pos,face,item)))return false;}
  boolean solid=!source.getCollisionShape(w,p).isEmpty();var bounds=new AABB(p.getX(),p.getY(),p.getZ(),p.getX()+n,p.getY()+n,p.getZ()+n);
  if(solid&&!w.getEntities((Entity)null,bounds,e->e.isAlive()&&!e.isSpectator()&&e.blocksBuilding).isEmpty())return false;
  for(int x=0;x<n;x++)for(int y=0;y<n;y++)for(int z=0;z<n;z++)w.setBlock(p.offset(x,y,z),CW.GIANT.defaultBlockState().setValue(GiantBlock.X,x).setValue(GiantBlock.Y,y).setValue(GiantBlock.Z,z).setValue(GiantBlock.SOLID,solid),3);
  var root=(GiantEntity)w.getBlockEntity(p);root.item=item.copyWithCount(1);root.source=source;if(root.machine().kind!=Machine.Kind.NONE)root.machine().initialize();root.setChanged();w.sendBlockUpdated(p,root.getBlockState(),root.getBlockState(),3);display(w,root);if(source.is(Blocks.TNT)){for(var q:BlockPos.betweenClosed(p,p.offset(n-1,n-1,n-1)))if(w.hasNeighborSignal(q)){CompressedTnt.prime(w,root,player,80);break;}}return true;
 }
 public static void display(ServerLevel w,GiantEntity root){
  var candidates=w.getEntitiesOfClass(Display.class,new AABB(root.getBlockPos()).inflate(12),d->d.entityTags().contains("cw_anchor_"+root.getBlockPos().asLong()));
  if(!candidates.isEmpty()){Display keep=candidates.stream().filter(d->d.getUUID().equals(root.display)).findFirst().orElse(candidates.getFirst());for(var d:candidates)if(d!=keep)d.discard();root.display=keep.getUUID();}
  if(root.display!=null&&w.getEntity(root.display) instanceof Display old){if(old instanceof Display.BlockDisplay b)((BlockAccess)b).cw$state(root.source);return;}
  int n=CW.size(CW.lv(root.item));var p=root.getBlockPos();Display d;
  if(root.source.getRenderShape()==RenderShape.MODEL){var b=new Display.BlockDisplay(EntityTypes.BLOCK_DISPLAY,w);((BlockAccess)b).cw$state(root.source);d=b;d.setPos(p.getX(),p.getY(),p.getZ());}
  else{var b=new Display.ItemDisplay(EntityTypes.ITEM_DISPLAY,w);((ItemAccess)b).cw$item(CW.convert(root.item,0));((ItemAccess)b).cw$context(ItemDisplayContext.NONE);d=b;d.setPos(p.getX()+n/2.,p.getY()+n/2.,p.getZ()+n/2.);}
  var a=(DisplayAccess)d;a.cw$transform(new Transformation(new Vector3f(),null,new Vector3f(n),null));a.cw$width(n*2f);a.cw$height(n*2f);d.addTag("compressionworld_giant");d.addTag("cw_anchor_"+p.asLong());w.addFreshEntity(d);root.display=d.getUUID();root.setChanged();
 }
 public static void destroy(ServerLevel w,BlockPos p,BlockState s,Player player,ItemStack tool){if(removing)return;var origin=GiantBlock.root(p,s);if(!(w.getBlockEntity(origin) instanceof GiantEntity root)||root.item.isEmpty()){w.removeBlock(p,false);return;}
  if(root.source.getBlock() instanceof ShulkerBoxBlock){var packed=root.item.copy();packed.set(UpgradeData.CARGO,root.machine().inv.snapshot());root.machine().inv.clearContent();remove(w,root);if(player==null||!player.hasInfiniteMaterials())Block.popResource(w,origin,packed);return;}
  var item=root.item.copy();var source=root.source;boolean drops=player==null||!player.hasInfiniteMaterials();var loot=drops&&(player==null||player.hasCorrectToolForDrops(source))?Block.getDrops(source,w,origin,null,player,tool):java.util.List.<ItemStack>of();remove(w,root);w.levelEvent(2001,origin,Block.getId(source));
  if(drops&&(item.has(DataComponents.CONTAINER)||item.has(DataComponents.BLOCK_ENTITY_DATA)))Block.popResource(w,origin,item);
  else for(var drop:loot){int count=drop.getCount()*CW.material(CW.lv(item));while(count>0){int batch=Math.min(drop.getMaxStackSize(),count);Block.popResource(w,origin,drop.copyWithCount(batch));count-=batch;}}
  if(player!=null&&!player.hasInfiniteMaterials()&&tool.isDamageableItem())tool.hurtAndBreak(1,player,InteractionHand.MAIN_HAND);
 }
 public static void remove(ServerLevel w,GiantEntity e){if(removing)return;removing=true;try{CampfireDisplay.clear(w,e.getBlockPos());e.furnace.dropContents(w);if(!e.item.isEmpty())e.machine().drop(w);int n=CW.size(CW.lv(e.item));var p=e.getBlockPos();if(e.display!=null&&w.getEntity(e.display)!=null)w.getEntity(e.display).discard();for(var q:BlockPos.betweenClosed(p,p.offset(n-1,n-1,n-1))){var s=w.getBlockState(q);if(s.is(CW.GIANT)&&GiantBlock.root(q,s).equals(p))w.setBlock(q,Blocks.AIR.defaultBlockState(),3);}}finally{removing=false;}}
 public static void cleanup(ServerLevel w,BlockPos origin){if(removing)return;removing=true;try{CampfireDisplay.clear(w,origin);for(var p:BlockPos.betweenClosed(origin,origin.offset(4,4,4))){var s=w.getBlockState(p);if(s.is(CW.GIANT)&&GiantBlock.root(p,s).equals(origin))w.setBlock(p,Blocks.AIR.defaultBlockState(),3);}for(var d:w.getEntitiesOfClass(Display.class,new AABB(origin).inflate(12)))if(d.entityTags().contains("cw_anchor_"+origin.asLong()))d.discard();}finally{removing=false;}}
 public static boolean grow(ServerLevel w,GiantEntity e,boolean bone){if(!(e.source.getBlock() instanceof CropBlock)&&!e.source.is(Blocks.NETHER_WART)&&!e.source.is(Blocks.COCOA)&&!e.source.is(Blocks.SWEET_BERRY_BUSH))return false;
  if(!bone&&w.getMaxLocalRawBrightness(e.getBlockPos().above())<9&&!e.source.is(Blocks.NETHER_WART))return false;
  for(var p:e.source.getProperties())if(p instanceof IntegerProperty age&&age.getName().equals("age")){int max=age.getPossibleValues().stream().mapToInt(Integer::intValue).max().orElse(0);int a=e.source.getValue(age);if(a==max)return false;e.source=e.source.setValue(age,Math.min(max,a+(bone?3:1)));e.setChanged();display(w,e);w.sendBlockUpdated(e.getBlockPos(),e.getBlockState(),e.getBlockState(),3);return true;}return false;}
}
