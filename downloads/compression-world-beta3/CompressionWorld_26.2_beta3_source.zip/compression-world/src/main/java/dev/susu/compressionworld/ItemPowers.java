package dev.susu.compressionworld;

import java.util.*;
import net.minecraft.core.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.*;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.phys.BlockHitResult;

public final class ItemPowers {
    public static PotionContents boostPotion(PotionContents original,int level){
        if(level==0)return original;List<MobEffectInstance> effects=new ArrayList<>();
        for(var e:original.getAllEffects()){
            var type=e.getEffect();boolean time=type.equals(MobEffects.WATER_BREATHING)||type.equals(MobEffects.NIGHT_VISION)||type.equals(MobEffects.INVISIBILITY)||type.equals(MobEffects.FIRE_RESISTANCE)||type.equals(MobEffects.SLOW_FALLING)||type.equals(MobEffects.CONDUIT_POWER);
            int duration=time?Math.min(1728000,e.getDuration()*CW.power(level)):e.getDuration();
            int amp=time?e.getAmplifier():type.value().isInstantaneous()?Math.min(20,e.getAmplifier()+level):Math.min(255,(e.getAmplifier()+1)*CW.power(level)-1);
            effects.add(new MobEffectInstance(type,duration,amp,e.isAmbient(),e.isVisible(),e.showIcon()));
        }return new PotionContents(Optional.empty(),Optional.of(original.getColor()),effects,original.customName());
    }
    public static void awardExperience(ServerLevel w,net.minecraft.world.phys.Vec3 pos,int amount){
        int orbs=Math.min(8,Math.max(1,amount));for(int i=0;i<orbs;i++){int part=amount/orbs+(i<amount%orbs?1:0);w.addFreshEntity(new ExperienceOrb(w,pos.x,pos.y,pos.z,part));}
    }
    public static void consumeCharge(ItemStack stack,int amount){int l=CW.lv(stack);if(l==0){stack.shrink(amount);return;}int uses=stack.getOrDefault(UpgradeData.USES,CW.power(l));if(uses>amount)stack.set(UpgradeData.USES,uses-amount);else stack.shrink(1);}
    public static InteractionResult boneMeal(Player p,Level level,InteractionHand hand,BlockHitResult hit){
        var stack=p.getItemInHand(hand);int l=CW.lv(stack);if(!stack.is(Items.BONE_MEAL)||l==0||p.isSpectator())return InteractionResult.PASS;
        if(level.isClientSide())return InteractionResult.SUCCESS;var w=(ServerLevel)level;int r=p.isShiftKeyDown()?0:l,success=0;Set<BlockPos> roots=new HashSet<>();
        for(var pos:BlockPos.betweenClosed(hit.getBlockPos().offset(-r,0,-r),hit.getBlockPos().offset(r,0,r))){
            if(!w.hasChunkAt(pos)||!w.mayInteract(p,pos)||!p.mayUseItemAt(pos,hit.getDirection(),stack))continue;
            var state=w.getBlockState(pos);boolean grown=false;
            if(state.is(CW.GIANT)){var at=GiantBlock.root(pos,state);if(roots.add(at)&&w.getBlockEntity(at) instanceof GiantEntity e)grown=Giants.grow(w,e,true);}
            else {grown=BoneMealItem.growCrop(new ItemStack(Items.BONE_MEAL),w,pos);if(!grown&&w.getBlockState(pos).is(Blocks.WATER))grown=BoneMealItem.growWaterPlant(new ItemStack(Items.BONE_MEAL),w,pos,hit.getDirection());}
            if(grown){success++;w.levelEvent(1505,pos,0);}
        }
        if(success>0){stack.consume(1,p);p.sendOverlayMessage(Component.literal("已对 "+success+" 处植物施肥"));return InteractionResult.SUCCESS;}return InteractionResult.FAIL;
    }
    public static void poisonAttack(LivingEntity target,net.minecraft.world.damagesource.DamageSource source,float raw,float taken,boolean blocked){
        if(!blocked&&taken>0&&source.getEntity() instanceof Player p&&source.getDirectEntity()==p&&p.getMainHandItem().is(Items.PUFFERFISH)&&CW.lv(p.getMainHandItem())>0)
            target.addEffect(new MobEffectInstance(UpgradeEffects.TOXIC,100,CW.lv(p.getMainHandItem())-1),p);
    }
    public static void tooltips(ItemStack s,List<Component> lines){int l=CW.lv(s);if(l==0)return;
        if(WaterOps.bucket(s))lines.add(Component.literal("储水："+WaterOps.amount(s)+"/"+CW.material(l)+"格 · Shift单格操作"));
        if(s.is(Items.TOTEM_OF_UNDYING)||s.is(Items.MILK_BUCKET))lines.add(Component.literal("剩余使用次数："+s.getOrDefault(UpgradeData.USES,CW.power(l))));
        if(s.is(Items.EXPERIENCE_BOTTLE))lines.add(Component.literal("经验点数×"+CW.arrows(l)));
        if(s.is(Items.PUFFERFISH))lines.add(Component.literal("毒性×"+CW.power(l)+" · 攻击使目标中毒"));
        if(s.is(Items.FISHING_ROD))lines.add(Component.literal("每次成功捕鱼独立抽取 "+CW.power(l)+" 份战利品"));
        if(s.has(UpgradeData.CARGO))lines.add(Component.literal("包含保存的压缩容器库存"));
    }
}
