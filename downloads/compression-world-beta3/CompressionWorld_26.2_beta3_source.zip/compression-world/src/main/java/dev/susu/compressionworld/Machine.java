package dev.susu.compressionworld;

import java.util.*;
import net.minecraft.core.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.crafting.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.storage.*;

/** Inventory owner for giant machines. Outputs are real stored stacks, never clickable previews. */
public final class Machine {
    public enum Kind { NONE, STORAGE, SHULKER, ENDER, CRAFT, CRAFTER, BREW, ENCHANT, GRIND, STONE, SMITH, HOPPER, DISPENSER, DROPPER, CAMPFIRE, COMPOST, CAULDRON, BEACON }
    public final GiantEntity root;
    public final Kind kind;
    public final MachineInventory inv;
    public final int[] timers=new int[128],fuel=new int[32];
    private final ItemStack[] campfireKeys=new ItemStack[128];
    private final List<List<ItemStack>> brewingKeys=new ArrayList<>();
    public int selection,water,compost;
    public boolean powered;
    public String message="准备就绪";
    public Machine(GiantEntity root){
        this.root=root;this.kind=kind(root.source.getBlock());
        inv=new MachineInventory(capacity(),root::setChanged);
        for(int i=0;i<32;i++)brewingKeys.add(List.of());
    }
    public static Kind kind(Block b){
        if(b instanceof ShulkerBoxBlock)return Kind.SHULKER;
        if(b==Blocks.ENDER_CHEST)return Kind.ENDER;
        if(b instanceof ChestBlock||b==Blocks.BARREL)return Kind.STORAGE;
        if(b==Blocks.CRAFTING_TABLE)return Kind.CRAFT;if(b==Blocks.CRAFTER)return Kind.CRAFTER;
        if(b==Blocks.BREWING_STAND)return Kind.BREW;if(b==Blocks.ENCHANTING_TABLE)return Kind.ENCHANT;
        if(b==Blocks.GRINDSTONE)return Kind.GRIND;if(b==Blocks.STONECUTTER)return Kind.STONE;
        if(b==Blocks.SMITHING_TABLE)return Kind.SMITH;if(b==Blocks.HOPPER)return Kind.HOPPER;
        if(b==Blocks.DROPPER)return Kind.DROPPER;if(b==Blocks.DISPENSER)return Kind.DISPENSER;
        if(b instanceof CampfireBlock)return Kind.CAMPFIRE;if(b==Blocks.COMPOSTER)return Kind.COMPOST;
        if(b==Blocks.CAULDRON||b==Blocks.WATER_CAULDRON)return Kind.CAULDRON;
        if(b==Blocks.BEACON)return Kind.BEACON;return Kind.NONE;
    }
    public int level(){return CW.lv(root.item);}public int factor(){return CW.power(level());}
    public boolean storage(){return kind==Kind.STORAGE||kind==Kind.SHULKER||kind==Kind.ENDER;}
    public int capacity(){return switch(kind){
        case STORAGE,SHULKER,ENDER->27*factor();case HOPPER->5*factor();case DISPENSER,DROPPER->9*factor();
        case BREW->5*factor();case CAMPFIRE->8*factor();case CRAFT,CRAFTER->18;
        case ENCHANT->3;case GRIND,SMITH->4;case STONE,COMPOST,CAULDRON->2;case BEACON->1;default->0;};}
    public boolean accepts(int slot,ItemStack s){
        if(kind==Kind.SHULKER&&s.getItem() instanceof BlockItem b&&b.getBlock() instanceof ShulkerBoxBlock)return false;
        return switch(kind){
            case CRAFT,CRAFTER->slot<9;case BREW->slot%5<3?s.has(DataComponents.POTION_CONTENTS):slot%5==3?((ServerLevel)root.getLevel()).potionBrewing().isIngredient(CW.convert(s,0)):s.is(Items.BLAZE_POWDER);
            case ENCHANT->slot==0||slot==1&&s.is(Items.LAPIS_LAZULI);case GRIND->slot<2;
            case STONE,COMPOST->slot==0;case SMITH->slot<3;case CAMPFIRE->slot%2==0;
            case CAULDRON->slot==0;case BEACON->s.is(Items.IRON_INGOT)||s.is(Items.GOLD_INGOT)||s.is(Items.DIAMOND)||s.is(Items.EMERALD)||s.is(Items.NETHERITE_INGOT);
            default->true;};
    }
    public void initialize(){
        var cargo=root.item.get(UpgradeData.CARGO);
        if(cargo!=null)inv.load(cargo);
        else if(root.item.has(DataComponents.CONTAINER)&&!storageIsEnder())inv.load(root.item.get(DataComponents.CONTAINER).allItemsCopyStream().toList());
        // The block owns its contents after placement. Do not leave another copy in the stored item.
        root.item.remove(UpgradeData.CARGO);root.item.remove(DataComponents.CONTAINER);
    }
    private boolean storageIsEnder(){return kind==Kind.ENDER;}
    public void open(Player p){
        Container contents=kind==Kind.ENDER?((EnderStorage)p).cw$ender():inv;
        p.openMenu(new SimpleMenuProvider((id,pi,user)->new MachineMenu(id,pi,this,contents,capacity()),
            Component.literal("压缩 "+level()+"级 · ").append(root.item.getItem().getName(root.item))));
    }
    public String hint(){return switch(kind){case CRAFT,CRAFTER->"左边3×3为配方，右边3×3为产物";case BREW->"每5格：药水×3、材料、烈焰粉";case CAMPFIRE->"每2格：原料、产物";case ENCHANT->"物品、青金石、产物";case GRIND->"装备、书或待修装备、装备产物、附魔书";case SMITH->"模板、装备、材料、产物";case STONE->"石材、产物";case COMPOST->"植物、骨粉";case BEACON->"先放入一枚激活材料，再选效果";default->"右键操作，Shift快速移动";};}
    public String progressText(){return kind==Kind.CAULDRON?water+"/"+(CW.material(level())*3)+"格水":Arrays.stream(timers).max().orElse(0)+" ticks";}
    public String status(){return message;}
    public String button(int n){return switch(kind){
        case CRAFT,CRAFTER->n==0?"合成1次":n==1?"批量合成×"+factor():"左边3×3放配方，右边取产物";
        case ENCHANT->n==0?"附魔：消耗3级经验和3青金石":n==1?"检查4个压缩书架":"附魔强度取书架与附魔台较低等级";
        case GRIND->n==0?"清除普通附魔":n==1?"提取附魔至空白书":"诅咒保留";
        case STONE->n==0?"加工×"+factor():n==1?"下一种配方":"当前："+MachineWork.stoneName(this);
        case SMITH->n==0?"锻造升级／纹饰":"模板和材料需提供同等级或足量材料";
        case BEACON->n==0?"支付材料并启用":n==1?"切换效果":"已选："+Structures.effectName(selection);
        case CAULDRON->n==0?"从槽内水桶注水":n==1?"装满槽内空桶":"也可手持压缩水桶右键操作";
        default->"自动工作，无需点击";};}
    public void action(Player p,int button){
        switch(kind){
            case CRAFT,CRAFTER->{if(button<2)MachineWork.craft(this,button==0?1:factor(),p);}
            case ENCHANT->{if(button==0)Structures.enchant(this,p);else message=Structures.bookshelves(this);}
            case GRIND->{if(button<2)MachineWork.grind(this,p,button==1);}
            case STONE->{if(button==1)selection++;else if(button==0)MachineWork.stone(this,factor());}
            case SMITH->{if(button==0)MachineWork.smith(this);}
            case BEACON->{if(button==1){selection=(selection+1)%6;powered=false;}else if(button==0&&!inv.getItem(0).isEmpty()){inv.getItem(0).shrink(1);powered=true;}Structures.beacon(this);}
            case CAULDRON->{if(button<2)WaterOps.cauldronSlots(this,button==0);}
            default->{}
        }root.setChanged();p.sendOverlayMessage(Component.literal(message));
    }
    public void tick(ServerLevel w){
        switch(kind){
            case BREW->brew(w);case CAMPFIRE->{cook(w);if(w.getGameTime()%20==Math.floorMod(root.getBlockPos().asLong(),20))CampfireDisplay.sync(w,this);}
            case HOPPER->{if(w.getGameTime()%8==0)Automation.hopper(this);}
            case CRAFTER,DISPENSER,DROPPER->{boolean on=Automation.signal(this);if(on&&!powered){if(kind==Kind.CRAFTER)MachineWork.craft(this,factor(),null);else Automation.dispense(this);}if(on!=powered){powered=on;root.setChanged();}}
            case COMPOST->{if(w.getGameTime()%10==0)compost(w);}
            case BEACON->{if(w.getGameTime()%80==0)Structures.beacon(this);}
            default->{}
        }
    }
    private void brew(ServerLevel w){
        var brewing=w.potionBrewing();
        for(int lane=0;lane<factor();lane++){
            int i=lane*5;var ingredient=inv.getItem(i+3);var raw=CW.convert(ingredient,0);
            boolean can=false;for(int b=0;b<3;b++)can|=brewing.hasMix(CW.convert(inv.getItem(i+b),0),raw);
            var key=List.of(inv.getItem(i).copyWithCount(1),inv.getItem(i+1).copyWithCount(1),inv.getItem(i+2).copyWithCount(1),raw.copyWithCount(1));
            var prev=brewingKeys.get(lane);if(prev.size()!=4||!java.util.stream.IntStream.range(0,4).allMatch(k->ItemStack.isSameItemSameComponents(prev.get(k),key.get(k)))){timers[lane]=0;brewingKeys.set(lane,key);}
            if(!can){timers[lane]=0;continue;}
            if(fuel[lane]==0&&inv.getItem(i+4).is(Items.BLAZE_POWDER)){fuel[lane]=20*CW.material(CW.lv(inv.getItem(i+4)));inv.getItem(i+4).shrink(1);root.setChanged();}
            if(fuel[lane]<=0)continue;
            if(++timers[lane]>=400){
                for(int b=0;b<3;b++){var potion=inv.getItem(i+b);var normal=CW.convert(potion,0);if(brewing.hasMix(normal,raw)){
                    var output=brewing.mix(raw,normal);output=CW.convert(output,CW.lv(potion));
                    if(ingredient.is(Items.PUFFERFISH)&&CW.lv(ingredient)>0)output.set(DataComponents.POTION_CONTENTS,ItemPowers.boostPotion(output.getOrDefault(DataComponents.POTION_CONTENTS,PotionContents.EMPTY),CW.lv(ingredient)));
                    inv.setItem(i+b,output);
                }}ingredient.shrink(1);fuel[lane]--;timers[lane]=0;root.setChanged();
            }else if(w.getGameTime()%20==0)root.setChanged();
        }
    }
    private void cook(ServerLevel w){
        if(root.source.hasProperty(net.minecraft.world.level.block.state.properties.BlockStateProperties.LIT)&&!root.source.getValue(net.minecraft.world.level.block.state.properties.BlockStateProperties.LIT))return;
        for(int lane=0;lane<4*factor();lane++){
            int i=lane*2;var in=inv.getItem(i);if(campfireKeys[lane]==null||!ItemStack.isSameItemSameComponents(in,campfireKeys[lane])){timers[lane]=0;campfireKeys[lane]=in.copyWithCount(1);}var ri=new SingleRecipeInput(CW.convert(in,0));
            var recipe=w.getServer().getRecipeManager().getRecipeFor(RecipeType.CAMPFIRE_COOKING,ri,w);
            if(recipe.isEmpty()){timers[lane]=0;continue;}
            var plain=recipe.get().value().assemble(ri);var result=CW.convert(plain,CW.lv(in)).copyWithCount(plain.getCount());
            if(!MachineWork.fits(inv,i+1,result))continue;
            if(++timers[lane]>=recipe.get().value().cookingTime()){MachineWork.put(inv,i+1,result);in.shrink(1);timers[lane]=0;root.setChanged();}
            else if(w.getGameTime()%20==0)root.setChanged();
        }
    }
    private void compost(ServerLevel w){
        int pending=Math.min(compost/7,64-inv.getItem(1).getCount());if(pending>0){MachineWork.put(inv,1,new ItemStack(Items.BONE_MEAL,pending));compost-=pending*7;root.setChanged();}
        var in=inv.getItem(0);if(in.isEmpty())return;float chance=ComposterBlock.COMPOSTABLES.getFloat(in.getItem());if(chance<=0)return;
        if(!MachineWork.fits(inv,1,new ItemStack(Items.BONE_MEAL)))return;
        int trials=CW.material(CW.lv(in));for(int j=0;j<trials;j++)if(w.getRandom().nextFloat()<chance)compost++;
        in.shrink(1);int out=Math.min(compost/7,64-inv.getItem(1).getCount());if(out>0){MachineWork.put(inv,1,new ItemStack(Items.BONE_MEAL,out));compost-=7*out;}root.setChanged();
    }
    public void save(ValueOutput out){if(kind==Kind.NONE)return;out.store("machine_items",ItemStack.OPTIONAL_CODEC.listOf(),inv.snapshot());out.putIntArray("machine_timers",timers);out.putIntArray("machine_fuel",fuel);out.putInt("machine_selection",selection);out.putInt("machine_water",water);out.putInt("machine_compost",compost);out.putBoolean("machine_powered",powered);}
    public void load(ValueInput in){inv.load(in.read("machine_items",ItemStack.OPTIONAL_CODEC.listOf()).orElse(List.of()));copy(in,"machine_timers",timers);copy(in,"machine_fuel",fuel);selection=in.getIntOr("machine_selection",0);water=in.getIntOr("machine_water",0);compost=in.getIntOr("machine_compost",0);powered=in.getBooleanOr("machine_powered",false);
        if(kind==Kind.CAMPFIRE)for(int lane=0;lane<4*factor();lane++)campfireKeys[lane]=inv.getItem(lane*2).copyWithCount(1);
        if(kind==Kind.BREW)for(int lane=0;lane<factor();lane++){int i=lane*5;brewingKeys.set(lane,List.of(inv.getItem(i).copyWithCount(1),inv.getItem(i+1).copyWithCount(1),inv.getItem(i+2).copyWithCount(1),CW.convert(inv.getItem(i+3),0)));}}
    private static void copy(ValueInput in,String name,int[] to){var arr=in.getIntArray(name).orElse(new int[0]);System.arraycopy(arr,0,to,0,Math.min(to.length,arr.length));}
    public void drop(ServerLevel w){if(kind==Kind.ENDER)return;for(int i=0;i<inv.getContainerSize();i++){var s=inv.removeItemNoUpdate(i);if(!s.isEmpty())Block.popResource(w,root.getBlockPos(),s);}}
}
