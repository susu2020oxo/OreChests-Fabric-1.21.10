package dev.susu.compressionworld;

import java.util.*;
import net.minecraft.world.*;
import net.minecraft.world.item.*;

/** Mutable stacks have one owning inventory. All transfers commit only what actually fits. */
public class MachineInventory extends SimpleContainer {
    private final Runnable changed;
    public MachineInventory(int size, Runnable changed) { super(size); this.changed = changed; }
    @Override public void setChanged() { super.setChanged(); if (changed != null) changed.run(); }
    public List<ItemStack> snapshot() {
        List<ItemStack> out = new ArrayList<>();
        for (int i=0; i<getContainerSize(); i++) out.add(getItem(i).copy());
        return out;
    }
    public void load(List<ItemStack> stacks) {
        for(int i=0;i<getContainerSize();i++) setItem(i, i<stacks.size()?stacks.get(i).copy():ItemStack.EMPTY);
    }
    public static ItemStack insert(Container target, ItemStack offered, java.util.function.IntPredicate allowed) {
        ItemStack left=offered.copy();
        for(int pass=0;pass<2;pass++) for(int i=0;i<target.getContainerSize()&&!left.isEmpty();i++) {
            if(!allowed.test(i)||!target.canPlaceItem(i,left))continue;
            ItemStack existing=target.getItem(i);
            if(pass==0&&existing.isEmpty()||pass==1&&!existing.isEmpty())continue;
            if(!existing.isEmpty()&&!ItemStack.isSameItemSameComponents(existing,left))continue;
            int n=Math.min(left.getCount(),Math.min(left.getMaxStackSize(),target.getMaxStackSize(left))-existing.getCount());
            if(n<=0)continue;
            if(existing.isEmpty())target.setItem(i,left.copyWithCount(n));else {existing.grow(n);target.setChanged();}
            left.shrink(n);
        }
        return left;
    }
    public void sort() {
        var all=snapshot().stream().filter(s->!s.isEmpty()).sorted(Comparator.comparing(s->net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(s.getItem()).toString())).toList();
        clearContent(); for(var s:all)insert(this,s,i->true);setChanged();
    }
}
