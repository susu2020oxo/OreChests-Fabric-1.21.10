package dev.susu.compressionworld;

import net.minecraft.world.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;

/** Vanilla chest protocol: 45 content slots and a guarded command row. */
public final class MachineMenu extends AbstractContainerMenu {
    public final Machine machine;
    public final Container inventory;
    public final Player player;
    public int page;
    private final int visible;
    private final View view=new View();
    public MachineMenu(int id, Inventory playerInv, Machine machine, Container inventory, int visible) {
        super(MenuType.GENERIC_9x6,id);this.machine=machine;this.inventory=inventory;this.visible=visible;this.player=playerInv.player;
        for(int i=0;i<54;i++){final int at=i;addSlot(new Slot(view,i,8+i%9*18,18+i/9*18){
            public boolean mayPlace(ItemStack s){return mapped(at)>=0&&machine.accepts(mapped(at),s);}
            public boolean mayPickup(Player p){return mapped(at)>=0;}
        });}
        for(int row=0;row<3;row++)for(int col=0;col<9;col++)addSlot(new Slot(playerInv,9+row*9+col,8+col*18,140+row*18));
        for(int col=0;col<9;col++)addSlot(new Slot(playerInv,col,8+col*18,198));
    }
    public int mapped(int at){
        if(machine.kind==Machine.Kind.CRAFT||machine.kind==Machine.Kind.CRAFTER){if(at<0||at>=27)return -1;int x=at%9,y=at/9;if(x<3)return y*3+x;if(x>=6)return 9+y*3+x-6;return -1;}
        int n=page*45+at;return at>=0&&at<45&&n<visible?n:-1;
    }
    public boolean stillValid(Player p){return !machine.root.isRemoved()&&p.level()==machine.root.getLevel()&&p.distanceToSqr(machine.root.getBlockPos().getX()+.5,machine.root.getBlockPos().getY()+.5,machine.root.getBlockPos().getZ()+.5)<256;}
    public void clicked(int at,int button,ContainerInput input,Player p){
        if(!stillValid(p))return;
        if(at>=0&&at<54&&mapped(at)<0){
            if(input==ContainerInput.PICKUP){
                if(at==45)page=Math.max(0,page-1);
                if(at==46)page=Math.min((visible-1)/45,page+1);
                if(at==47&&machine.storage())sortVisible();
                if(at==48&&machine.storage())mergeFromPlayer();
                if(at==49||at==50||at==51)machine.action(p,at-49);
                broadcastFullState();
            }return;
        }super.clicked(at,button,input,p);
    }
    private void sortVisible(){var temp=new MachineInventory(visible,()->{});for(int i=0;i<visible;i++)temp.setItem(i,inventory.getItem(i).copy());temp.sort();for(int i=0;i<visible;i++)inventory.setItem(i,temp.getItem(i));}
    private void mergeFromPlayer(){for(int i=0;i<36;i++){var s=player.getInventory().getItem(i);if(s.isEmpty())continue;boolean exists=false;for(int j=0;j<visible;j++)exists|=ItemStack.isSameItemSameComponents(s,inventory.getItem(j));if(exists)player.getInventory().setItem(i,MachineInventory.insert(inventory,s,j->j<visible&&machine.accepts(j,s)));}}
    public ItemStack quickMoveStack(Player p,int at){
        if(at<0||at>=slots.size())return ItemStack.EMPTY;var from=slots.get(at);if(!from.hasItem()||!from.mayPickup(p))return ItemStack.EMPTY;
        var s=from.getItem();var before=s.copy();
        if(at<54){if(!moveItemStackTo(s,54,slots.size(),true))return ItemStack.EMPTY;}
        else {boolean moved=false;for(int i=0;i<45&&!s.isEmpty();i++)if(slots.get(i).mayPlace(s))moved|=moveItemStackTo(s,i,i+1,false);if(!moved)return ItemStack.EMPTY;}
        if(s.isEmpty())from.setByPlayer(ItemStack.EMPTY);else from.setChanged();from.onTake(p,before.copyWithCount(before.getCount()-s.getCount()));return before;
    }
    static ItemStack label(Item item,String text){var s=new ItemStack(item);s.set(DataComponents.ITEM_NAME,Component.literal(text));return s;}
    private final class View extends SimpleContainer {
        View(){super(54);}
        public ItemStack getItem(int at){int i=mapped(at);if(i>=0)return inventory.getItem(i);return switch(at){
            case 45->label(Items.ARROW,"上一页");case 46->label(Items.ARROW,"下一页");
            case 47->label(Items.CHEST,machine.storage()?"整理仓库":"槽位说明："+machine.hint());
            case 48->label(Items.HOPPER,machine.storage()?"归并背包中的同类物品":"进度："+machine.progressText());
            case 49,50,51->label(Items.PAPER,machine.button(at-49));
            case 52->label(Items.BOOK,"第"+(page+1)+"/"+((visible+44)/45)+"页 · "+visible+"格");
            case 53->label(Items.KNOWLEDGE_BOOK,machine.status());default->label(Items.IRON_BARS,"未开放槽位");};}
        public void setItem(int at,ItemStack s){int i=mapped(at);if(i>=0)inventory.setItem(i,s);}
        public ItemStack removeItem(int at,int n){int i=mapped(at);return i<0?ItemStack.EMPTY:inventory.removeItem(i,n);}
        public ItemStack removeItemNoUpdate(int at){int i=mapped(at);return i<0?ItemStack.EMPTY:inventory.removeItemNoUpdate(i);}
        public void setChanged(){if(inventory!=null)inventory.setChanged();}
        public boolean stillValid(Player p){return MachineMenu.this.stillValid(p);}
    }
}
