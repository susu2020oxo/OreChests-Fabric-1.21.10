package dev.susu.compressionworld;

import java.util.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.*;
import net.minecraft.world.item.enchantment.*;
import net.minecraft.tags.EnchantmentTags;

public final class MachineWork {
    public static boolean fits(Container inv,int at,ItemStack output){var s=inv.getItem(at);return s.isEmpty()||ItemStack.isSameItemSameComponents(s,output)&&s.getCount()+output.getCount()<=s.getMaxStackSize();}
    public static void put(Container inv,int at,ItemStack output){var s=inv.getItem(at);if(s.isEmpty())inv.setItem(at,output.copy());else{s.grow(output.getCount());inv.setChanged();}}
    public static int craft(Machine m,int times,Player player){
        var w=(ServerLevel)m.root.getLevel();int completed=0;
        for(int n=0;n<times;n++){
            List<ItemStack> grid=new ArrayList<>();for(int i=0;i<9;i++)grid.add(m.inv.getItem(i).copy());
            var input=CraftingInput.of(3,3,grid);var holder=w.getServer().getRecipeManager().getRecipeFor(RecipeType.CRAFTING,input,w);
            if(holder.isEmpty())break;
            var recipe=holder.get().value();ItemStack result=recipe.assemble(input);if(result.isEmpty())break;
            var temp=new MachineInventory(18,()->{});temp.load(m.inv.snapshot());
            if(!MachineInventory.insert(temp,result,i->i>=9).isEmpty())break;
            boolean room=true;for(var remain:recipe.getRemainingItems(input))if(!remain.isEmpty()&&!MachineInventory.insert(temp,remain,i->i>=9).isEmpty()){room=false;break;}
            if(!room)break;
            for(int i=0;i<9;i++)if(!temp.getItem(i).isEmpty())temp.getItem(i).shrink(1);
            m.inv.load(temp.snapshot());completed++;
        }
        m.message="完成 "+completed+" 次合成";return completed;
    }
    private static List<StonecutterRecipe> stoneRecipes(Machine m){
        var w=(ServerLevel)m.root.getLevel();var input=new SingleRecipeInput(CW.convert(m.inv.getItem(0),0));
        return w.getServer().getRecipeManager().getRecipes().stream().sorted(Comparator.comparing(r->r.id().identifier().toString()))
            .map(RecipeHolder::value).filter(r->r instanceof StonecutterRecipe s&&s.matches(input,w)).map(r->(StonecutterRecipe)r).toList();
    }
    public static String stoneName(Machine m){if(!(m.root.getLevel() instanceof ServerLevel))return "无";var recipes=stoneRecipes(m);if(recipes.isEmpty())return "无匹配配方";var result=recipes.get(Math.floorMod(m.selection,recipes.size())).assemble(new SingleRecipeInput(CW.convert(m.inv.getItem(0),0)));return result.getHoverName().getString();}
    public static void stone(Machine m,int times){var recipes=stoneRecipes(m);if(recipes.isEmpty()){m.message="请放入可切制的石材";return;}int n=0;
        var input=m.inv.getItem(0);var raw=new SingleRecipeInput(CW.convert(input,0));var plain=recipes.get(Math.floorMod(m.selection,recipes.size())).assemble(raw);var output=CW.convert(plain,CW.lv(input)).copyWithCount(plain.getCount());
        for(;n<times&&!input.isEmpty()&&fits(m.inv,1,output);n++){put(m.inv,1,output);input.shrink(1);}m.message="已加工 "+n+" 次";m.root.setChanged();
    }
    public static void grind(Machine m,Player p,boolean extract){
        var input=m.inv.getItem(0);if(input.isEmpty()){m.message="先放入装备或附魔书";return;}
        if(!extract&&!m.inv.getItem(1).isEmpty()&&!m.inv.getItem(1).is(Items.BOOK)){
            var second=m.inv.getItem(1);if(CW.lv(second)!=CW.lv(input)){m.message="合并修复需要相同压缩等级";return;}
            var nativeMenu=new net.minecraft.world.inventory.GrindstoneMenu(-1,p.getInventory());nativeMenu.getSlot(0).set(input.copyWithCount(1));nativeMenu.getSlot(1).set(second.copyWithCount(1));
            var merged=nativeMenu.getSlot(2).getItem().copy();if(merged.isEmpty()||!fits(m.inv,2,merged)){m.message="无法合并这两件物品，或产物槽已满";return;}
            int xp=0;for(var source:List.of(input,second))for(var en:EnchantmentHelper.getEnchantmentsForCrafting(source).entrySet())if(!en.getKey().is(EnchantmentTags.CURSE))xp+=en.getKey().value().getMinCost(en.getIntValue());
            input.shrink(1);second.shrink(1);put(m.inv,2,merged);if(xp>0)p.giveExperiencePoints(Math.max(1,xp/2));m.message="两件装备已合并修复";m.root.setChanged();return;
        }
        var old=EnchantmentHelper.getEnchantmentsForCrafting(input);var keep=new ItemEnchantments.Mutable(old);var removed=new ItemEnchantments.Mutable(ItemEnchantments.EMPTY);
        for(var e:old.entrySet())if(!e.getKey().is(EnchantmentTags.CURSE))removed.set(e.getKey(),e.getIntValue());
        if(removed.toImmutable().isEmpty()){m.message="没有可移除的普通附魔";return;}
        keep.removeIf(e->!e.is(EnchantmentTags.CURSE));var output=input.copyWithCount(1);EnchantmentHelper.setEnchantments(output,keep.toImmutable());output.remove(DataComponents.REPAIR_COST);
        if(output.is(Items.ENCHANTED_BOOK)&&keep.toImmutable().isEmpty())output=output.transmuteCopy(Items.BOOK);
        var book=new ItemStack(Items.ENCHANTED_BOOK);book.set(DataComponents.STORED_ENCHANTMENTS,removed.toImmutable());
        if(extract&&(!m.inv.getItem(1).is(Items.BOOK)||CW.lv(m.inv.getItem(1))!=0)){m.message="提取需要一本普通空白书";return;}
        if(!fits(m.inv,2,output)||extract&&!fits(m.inv,3,book)){m.message="请先取走产物";return;}
        input.shrink(1);put(m.inv,2,output);if(extract){m.inv.getItem(1).shrink(1);put(m.inv,3,book);}else{
            int xp=0;for(var e:removed.toImmutable().entrySet())xp+=e.getKey().value().getMinCost(e.getIntValue());p.giveExperiencePoints(Math.max(1,xp/2));
        }m.message=extract?"附魔已转移，原物品不再保留这些附魔":"普通附魔已清除，诅咒保留";m.root.setChanged();
    }
    public static void smith(Machine m){
        var template=m.inv.getItem(0);var base=m.inv.getItem(1);var addition=m.inv.getItem(2);int level=CW.lv(base);
        if(base.isEmpty()||CW.lv(template)>level||CW.lv(addition)>level){m.message="模板和材料等级不能高于装备";return;}
        int templates=CW.material(level)/CW.material(CW.lv(template)),materials=CW.material(level)/CW.material(CW.lv(addition));
        if(template.getCount()<templates||addition.getCount()<materials){m.message="需要模板×"+templates+"、材料×"+materials+"；可使用同级压缩材料";return;}
        var rawBase=CW.convert(base,0);var input=new SmithingRecipeInput(CW.convert(template,0),rawBase,CW.convert(addition,0));var w=(ServerLevel)m.root.getLevel();
        var recipe=w.getServer().getRecipeManager().getRecipeFor(RecipeType.SMITHING,input,w);
        if(recipe.isEmpty()){m.message="没有匹配的锻造配方";return;}
        var output=CW.convert(recipe.get().value().assemble(input),level);
        if(base.isDamageableItem()&&output.isDamageableItem())output.setDamageValue((int)Math.round((double)base.getDamageValue()/base.getMaxDamage()*output.getMaxDamage()));
        if(!fits(m.inv,3,output)){m.message="请先取走产物";return;}
        template.shrink(templates);addition.shrink(materials);base.shrink(1);put(m.inv,3,output);m.message="锻造完成，压缩等级与附魔保留";m.root.setChanged();
    }
}
