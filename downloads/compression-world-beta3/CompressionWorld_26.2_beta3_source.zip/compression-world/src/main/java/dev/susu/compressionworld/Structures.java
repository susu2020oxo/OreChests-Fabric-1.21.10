package dev.susu.compressionworld;

import java.util.*;
import net.minecraft.core.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.effect.*;
import net.minecraft.world.item.*;
import net.minecraft.world.item.enchantment.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.phys.AABB;
import net.minecraft.tags.EnchantmentTags;

public final class Structures {
    private static final List<Holder<MobEffect>> EFFECTS=List.of(MobEffects.SPEED,MobEffects.HASTE,MobEffects.RESISTANCE,MobEffects.JUMP_BOOST,MobEffects.STRENGTH,MobEffects.REGENERATION);
    private static final List<String> NAMES=List.of("速度","急迫","抗性提升","跳跃提升","力量","生命恢复");
    public static String effectName(int i){return NAMES.get(Math.floorMod(i,NAMES.size()));}
    /** Count root objects, not their occupied cells. Four shelves of at least a tier unlock that tier. */
    public static int shelfLevel(Machine m){
        var w=(ServerLevel)m.root.getLevel();var p=m.root.getBlockPos();int n=CW.size(m.level()),r=n+8;Set<BlockPos> seen=new HashSet<>();List<Integer> levels=new ArrayList<>();
        for(var q:BlockPos.betweenClosed(p.offset(-r,-1,-r),p.offset(n+r,n+1,n+r))){
            if(!w.hasChunkAt(q))continue;var s=w.getBlockState(q);if(!s.is(CW.GIANT))continue;var at=GiantBlock.root(q,s);if(!seen.add(at))continue;
            if(w.getBlockEntity(at) instanceof GiantEntity e&&e.source.is(Blocks.BOOKSHELF)&&!e.item.isEmpty())levels.add(CW.lv(e.item));
        }
        levels.sort(Comparator.reverseOrder());return levels.size()<4?0:Math.min(m.level(),levels.get(3));
    }
    public static String bookshelves(Machine m){int l=shelfLevel(m);return l==0?"周围需要4个压缩书架（距离外沿8格内）":"可用附魔等级："+l+" · 强度×"+CW.power(l);}
    public static void enchant(Machine m,Player p){
        int level=shelfLevel(m);var input=m.inv.getItem(0);var lapis=m.inv.getItem(1);
        if(level==0){m.message=bookshelves(m);return;}
        if(input.isEmpty()||input.getCount()!=1||!input.isEnchantable()||EnchantmentHelper.hasAnyEnchantments(input)){m.message="请放入一件可附魔且尚未附魔的物品";return;}
        if(!p.hasInfiniteMaterials()&&(p.experienceLevel<30||!lapis.is(Items.LAPIS_LAZULI)||lapis.getCount()<3)){m.message="需要达到30级，并消耗3级经验和3颗青金石";return;}
        if(!m.inv.getItem(2).isEmpty()){m.message="请先取走上一件产物";return;}
        var w=(ServerLevel)m.root.getLevel();var registry=w.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
        var options=registry.getOrThrow(EnchantmentTags.IN_ENCHANTING_TABLE).stream().map(x->(Holder<Enchantment>)x);
        ItemStack output=EnchantmentHelper.enchantItem(p.getRandom(),input.copy(),30,options);
        var enchants=EnchantmentHelper.getEnchantmentsForCrafting(output);var boosted=new ItemEnchantments.Mutable(enchants);
        for(var e:enchants.entrySet())if(e.getKey().value().getMaxLevel()>1)boosted.set(e.getKey(),Math.min(255,e.getIntValue()*CW.power(level)));
        EnchantmentHelper.setEnchantments(output,boosted.toImmutable());if(enchants.isEmpty()){m.message="本物品没有可用附魔";return;}
        if(!p.hasInfiniteMaterials()){p.giveExperienceLevels(-3);lapis.shrink(3);}input.shrink(1);m.inv.setItem(2,output);m.message="附魔完成 · 强度×"+CW.power(level);m.root.setChanged();
    }
    public static boolean mineral(Block b){return b==Blocks.IRON_BLOCK||b==Blocks.GOLD_BLOCK||b==Blocks.DIAMOND_BLOCK||b==Blocks.EMERALD_BLOCK||b==Blocks.NETHERITE_BLOCK;}
    /** Pyramid tiles are logical compressed blocks. Each tier is n physical blocks tall. */
    public static int[] base(Machine m){var w=(ServerLevel)m.root.getLevel();var p=m.root.getBlockPos();int n=CW.size(m.level()),effective=m.level(),layers=0;
        for(int depth=1;depth<=4;depth++){
            int lowest=effective;boolean valid=true;
            for(int x=-depth;x<=depth&&valid;x++)for(int z=-depth;z<=depth;z++){
                var at=p.offset(x*n,-depth*n,z*n);if(!w.hasChunkAt(at)||!(w.getBlockEntity(at) instanceof GiantEntity e)||!mineral(e.source.getBlock())||e.item.isEmpty()||CW.size(CW.lv(e.item))!=n){valid=false;break;}
                lowest=Math.min(lowest,CW.lv(e.item));
            }
            if(!valid)break;layers++;effective=lowest;
        }return new int[]{layers,effective};
    }
    public static void beacon(Machine m){
        if(!m.powered){m.message="信标未激活：放入支付材料并点击启用";return;}var w=(ServerLevel)m.root.getLevel();var p=m.root.getBlockPos();int n=CW.size(m.level());var structure=base(m);
        if(structure[0]==0){m.message="底部需要3×3同尺寸的压缩矿物块底座";return;}
        for(int y=p.getY()+n;y<w.getMaxY();y++){var s=w.getBlockState(new BlockPos(p.getX()+n/2,y,p.getZ()+n/2));if(s.getLightDampening()>0&&!s.is(Blocks.BEDROCK)){m.message="信标上方被不透光方块阻挡";return;}}
        int power=CompressedTnt.multiplier(structure[1]),range=Math.min(192,32+16*structure[0]+16*structure[1]);
        var effect=EFFECTS.get(Math.floorMod(m.selection,EFFECTS.size()));
        for(var player:w.getEntitiesOfClass(Player.class,new AABB(p).inflate(range)))player.addEffect(new MobEffectInstance(effect,220,power-1,true,true));
        m.message=effectName(m.selection)+" ×"+power+" · 半径"+range+"格 · 底座"+structure[0]+"层";
    }
}
