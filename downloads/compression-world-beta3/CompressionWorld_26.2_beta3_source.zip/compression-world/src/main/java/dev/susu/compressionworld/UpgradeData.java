package dev.susu.compressionworld;

import com.mojang.serialization.Codec;
import net.minecraft.core.*;
import net.minecraft.core.component.*;
import net.minecraft.core.registries.*;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.world.item.ItemStack;
import java.util.List;

public final class UpgradeData {
    public static final DataComponentType<Integer> WATER = integer("water", 1024);
    public static final DataComponentType<Integer> USES = integer("uses", 32);
    public static final DataComponentType<List<ItemStack>> CARGO = Registry.register(BuiltInRegistries.DATA_COMPONENT_TYPE,
        CW.id("cargo"), DataComponentType.<List<ItemStack>>builder()
            .persistent(ItemStack.OPTIONAL_CODEC.listOf(0, 864))
            .networkSynchronized(ItemStack.OPTIONAL_STREAM_CODEC.apply(ByteBufCodecs.list(864))).build());

    private static DataComponentType<Integer> integer(String name, int max) {
        return Registry.register(BuiltInRegistries.DATA_COMPONENT_TYPE, CW.id(name),
            DataComponentType.<Integer>builder().persistent(Codec.intRange(0, max)).networkSynchronized(ByteBufCodecs.VAR_INT).build());
    }
    public static boolean loadedContainer(ItemStack stack){
        var cargo=stack.get(CARGO);if(cargo!=null&&cargo.stream().anyMatch(s->!s.isEmpty()))return true;
        var vanilla=stack.get(DataComponents.CONTAINER);return vanilla!=null&&vanilla.nonEmptyItemCopyStream().findAny().isPresent();
    }
    public static void init() {}
    public static float handScale(int level) { return Math.min(1.75f, 1 + 0.15f * level); }
}
