package dev.susu.compressionworld;
import net.minecraft.core.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.LivingEntity;
public final class UpgradeEffects {
    public static final Holder<MobEffect> TOXIC=Registry.registerForHolder(BuiltInRegistries.MOB_EFFECT,CW.id("compressed_poison"),new MobEffect(MobEffectCategory.HARMFUL,0x80aa22){
        public boolean shouldApplyEffectTickThisTick(int duration,int amplifier){return true;}
        public boolean applyEffectTick(ServerLevel w,LivingEntity e,int amplifier){float damage=Math.min(e.getHealth()-1,CW.power(Math.min(5,amplifier+1))/3f);if(damage>0){int old=e.invulnerableTime;e.invulnerableTime=0;e.hurtServer(w,e.damageSources().magic(),damage);e.invulnerableTime=old;}return true;}
    });
    public static void init(){}
}
