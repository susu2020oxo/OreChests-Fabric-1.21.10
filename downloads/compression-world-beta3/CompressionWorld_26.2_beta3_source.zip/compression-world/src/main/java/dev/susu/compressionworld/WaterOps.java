package dev.susu.compressionworld;

import java.util.*;
import net.minecraft.core.*;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.phys.*;

public final class WaterOps {
    public static boolean bucket(ItemStack s){return s.is(Items.BUCKET)||s.is(Items.WATER_BUCKET);}
    public static int amount(ItemStack s){return s.getOrDefault(UpgradeData.WATER,s.is(Items.WATER_BUCKET)?CW.material(CW.lv(s)):0);}
    public static ItemStack withAmount(ItemStack original,int amount){var s=original.transmuteCopy(amount>0?Items.WATER_BUCKET:Items.BUCKET,1);s.set(UpgradeData.WATER,Math.max(0,Math.min(CW.material(CW.lv(s)),amount)));return s;}
    public static InteractionResult use(Level level,Player p,InteractionHand hand){
        var held=p.getItemInHand(hand);if(!bucket(held)||CW.lv(held)==0)return InteractionResult.PASS;
        if(level.isClientSide())return InteractionResult.SUCCESS;
        var w=(ServerLevel)level;Vec3 start=p.getEyePosition(),end=start.add(p.getLookAngle().scale(p.blockInteractionRange()));
        var hit=w.clip(new ClipContext(start,end,ClipContext.Block.OUTLINE,ClipContext.Fluid.SOURCE_ONLY,p));
        if(hit.getType()!=HitResult.Type.BLOCK)return InteractionResult.PASS;
        var state=w.getBlockState(hit.getBlockPos());
        if(state.is(CW.GIANT)&&w.getBlockEntity(GiantBlock.root(hit.getBlockPos(),state)) instanceof GiantEntity g&&g.machine().kind==Machine.Kind.CAULDRON){
            var m=g.machine();int stored=amount(held),capacity=CW.material(CW.lv(held));
            int n=stored>0?Math.min(stored,CW.material(m.level())*3-m.water):Math.min(capacity,m.water);
            if(n<=0)return InteractionResult.FAIL;
            m.water+=stored>0?n:-n;replaceHeld(p,hand,withAmount(held,stored>0?stored-n:n));g.setChanged();p.sendOverlayMessage(Component.literal("炼药锅："+m.water+"格水"));return InteractionResult.SUCCESS;
        }
        boolean collect=state.getFluidState().is(FluidTags.WATER)&&state.getFluidState().isSource();
        BlockPos at=collect?hit.getBlockPos():hit.getBlockPos().relative(hit.getDirection());
        int stored=amount(held),capacity=CW.material(CW.lv(held));
        int limit=p.isShiftKeyDown()?1:Math.min(collect?capacity-stored:stored,(2*CW.lv(held)+1)*(2*CW.lv(held)+1));
        if(limit<=0){p.sendOverlayMessage(Component.literal(collect?"桶已装满":"桶中没有水"));return InteractionResult.FAIL;}
        if(!collect&&w.environmentAttributes().getValue(net.minecraft.world.attribute.EnvironmentAttributes.WATER_EVAPORATES,at)){p.sendOverlayMessage(Component.literal("此维度无法放置水"));return InteractionResult.FAIL;}
        int n=transfer(w,at,CW.lv(held),limit,collect,p,held);
        if(n==0)return InteractionResult.FAIL;
        replaceHeld(p,hand,withAmount(held,stored+(collect?n:-n)));p.sendOverlayMessage(Component.literal((collect?"收集 ":"放出 ")+n+"格水 · "+amount(p.getItemInHand(hand))+"/"+capacity));return InteractionResult.SUCCESS;
    }
    public static int transfer(ServerLevel w,BlockPos center,int radius,int limit,boolean collect,Player p,ItemStack held){
        List<BlockPos> positions=new ArrayList<>();for(int x=-radius;x<=radius;x++)for(int z=-radius;z<=radius;z++)positions.add(center.offset(x,0,z));
        positions.sort(Comparator.comparingDouble(center::distSqr));int n=0;
        for(var q:positions){if(n>=limit)break;if(!w.hasChunkAt(q)||w.isOutsideBuildHeight(q)||!w.getWorldBorder().isWithinBounds(q))continue;
            if(p!=null&&(!w.mayInteract(p,q)||!p.mayUseItemAt(q,Direction.UP,held)))continue;
            var s=w.getBlockState(q);if(w.getBlockEntity(q)!=null)continue;
            if(collect){if(!s.is(Blocks.WATER)||!s.getFluidState().isSource())continue;w.setBlock(q,Blocks.AIR.defaultBlockState(),3);}
            else{if(!s.isAir()||w.environmentAttributes().getValue(net.minecraft.world.attribute.EnvironmentAttributes.WATER_EVAPORATES,q))continue;w.setBlock(q,Blocks.WATER.defaultBlockState(),3);}n++;
        }return n;
    }
    public static void replaceHeld(Player p,InteractionHand hand,ItemStack result){var original=p.getItemInHand(hand);if(original.getCount()>1){original.shrink(1);if(!p.getInventory().add(result))p.drop(result,false);}else p.setItemInHand(hand,result);}
    public static void cauldronSlots(Machine m,boolean pour){var held=m.inv.getItem(0);if(!bucket(held)){m.message="第1格放入水桶或空桶，第2格取出";return;}int stored=amount(held),n=pour?Math.min(stored,CW.material(m.level())*3-m.water):Math.min(CW.material(CW.lv(held))-stored,m.water);
        if(n<=0){m.message="容量不足或没有可转移的水";return;}var output=withAmount(held,stored+(pour?-n:n));if(!MachineWork.fits(m.inv,1,output)){m.message="请先取走产物";return;}
        m.water+=pour?n:-n;held.shrink(1);MachineWork.put(m.inv,1,output);m.message="炼药锅水量："+m.water; m.root.setChanged();
    }
}
