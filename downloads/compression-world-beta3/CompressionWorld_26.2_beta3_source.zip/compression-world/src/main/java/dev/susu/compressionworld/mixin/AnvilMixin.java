package dev.susu.compressionworld.mixin;
import dev.susu.compressionworld.*;
import net.minecraft.world.inventory.AnvilMenu;
import net.minecraft.world.item.enchantment.Enchantment;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(AnvilMenu.class)
public abstract class AnvilMixin {
    private int factor(){return (Object)this instanceof GiantAnvilMenu m?m.factor():1;}
    @Redirect(method="createResult",at=@At(value="INVOKE",target="Lnet/minecraft/world/item/enchantment/Enchantment;getMaxLevel()I"))
    private int cap(Enchantment enchant){return enchant.getMaxLevel()==1?1:Math.min(255,enchant.getMaxLevel()*factor());}
    @ModifyConstant(method="createResult",constant=@Constant(intValue=40))private int costCap(int value){return value*factor();}
    @ModifyArg(method="createResult",at=@At(value="INVOKE",target="Ljava/lang/Math;min(II)I",ordinal=0),index=1)
    private int repairFirst(int value){return value*factor();}
    @ModifyArg(method="createResult",at=@At(value="INVOKE",target="Ljava/lang/Math;min(II)I",ordinal=1),index=1)
    private int repairNext(int value){return value*factor();}
}
