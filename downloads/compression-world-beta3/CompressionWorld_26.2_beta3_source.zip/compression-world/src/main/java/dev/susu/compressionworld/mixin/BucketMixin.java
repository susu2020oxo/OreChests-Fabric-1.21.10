package dev.susu.compressionworld.mixin;
import dev.susu.compressionworld.*;
import net.minecraft.world.*;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(BucketItem.class) public abstract class BucketMixin {
    @Inject(method="use",at=@At("HEAD"),cancellable=true) private void use(Level w,Player p,InteractionHand h,CallbackInfoReturnable<InteractionResult> ci){if(CW.lv(p.getItemInHand(h))>0&&WaterOps.bucket(p.getItemInHand(h)))ci.setReturnValue(WaterOps.use(w,p,h));}
}
