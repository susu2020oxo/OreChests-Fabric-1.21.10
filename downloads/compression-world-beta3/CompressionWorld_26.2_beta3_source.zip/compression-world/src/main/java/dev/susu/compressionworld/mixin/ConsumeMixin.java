package dev.susu.compressionworld.mixin;
import dev.susu.compressionworld.*;
import net.minecraft.world.item.*;
import net.minecraft.world.item.component.Consumable;
import net.minecraft.world.item.consume_effects.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.effect.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(Consumable.class)public abstract class ConsumeMixin {
    @Inject(method="onConsume",at=@At("HEAD"),cancellable=true)
    private void milk(Level w,LivingEntity e,ItemStack s,CallbackInfoReturnable<ItemStack> ci){
        int l=CW.lv(s);if(l==0||!s.is(Items.MILK_BUCKET))return;
        if(!w.isClientSide())e.removeAllEffects();
        if(e instanceof Player p&&p.hasInfiniteMaterials()){ci.setReturnValue(s);return;}
        int remaining=s.getOrDefault(UpgradeData.USES,CW.power(l))-1;
        if(remaining>0){s.set(UpgradeData.USES,remaining);ci.setReturnValue(s);}
        else{var out=CW.convert(new ItemStack(Items.BUCKET),l);s.shrink(1);ci.setReturnValue(out);}
    }
}
