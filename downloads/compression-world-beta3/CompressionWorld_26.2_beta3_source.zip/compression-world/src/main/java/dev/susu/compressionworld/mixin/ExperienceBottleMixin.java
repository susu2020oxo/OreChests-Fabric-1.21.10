package dev.susu.compressionworld.mixin;
import dev.susu.compressionworld.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrownExperienceBottle;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(ThrownExperienceBottle.class) public abstract class ExperienceBottleMixin {
    @Redirect(method="onHit",at=@At(value="INVOKE",target="Lnet/minecraft/world/entity/ExperienceOrb;awardWithDirection(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;I)V"))
    private void xp(ServerLevel w,Vec3 pos,Vec3 direction,int amount){int l=CW.lv(((ThrownExperienceBottle)(Object)this).getItem());if(l==0)ExperienceOrb.awardWithDirection(w,pos,direction,amount);else ItemPowers.awardExperience(w,pos,amount*CW.arrows(l));}
}
