package dev.susu.compressionworld.mixin;
import dev.susu.compressionworld.*;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.projectile.FishingHook;
import net.minecraft.world.level.storage.loot.*;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(FishingHook.class) public abstract class FishingMixin {
    @Unique private int cw$rolls=1;
    @Inject(method="retrieve",at=@At("HEAD"))private void begin(ItemStack rod,CallbackInfoReturnable<Integer> ci){cw$rolls=CW.power(CW.lv(rod));}
    @Redirect(method="retrieve",at=@At(value="INVOKE",target="Lnet/minecraft/world/level/storage/loot/LootTable;getRandomItems(Lnet/minecraft/world/level/storage/loot/LootParams;)Lit/unimi/dsi/fastutil/objects/ObjectArrayList;"))
    private ObjectArrayList<ItemStack> fish(LootTable table,LootParams params){var out=new ObjectArrayList<ItemStack>();for(int i=0;i<cw$rolls;i++)out.addAll(table.getRandomItems(params));return out;}
}
