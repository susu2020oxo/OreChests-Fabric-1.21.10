package dev.susu.compressionworld.mixin;
import dev.susu.compressionworld.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrownLingeringPotion;
import net.minecraft.world.phys.HitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ThrownLingeringPotion.class)public abstract class LingeringMixin {
    @Inject(method="onHitAsPotion",at=@At("HEAD"),cancellable=true)private void hit(ServerLevel w,ItemStack stack,HitResult hit,CallbackInfo ci){int l=CW.lv(stack);if(l==0)return;var self=(ThrownLingeringPotion)(Object)this;
        var cloud=new AreaEffectCloud(w,self.getX(),self.getY(),self.getZ());if(self.getOwner() instanceof LivingEntity owner)cloud.setOwner(owner);
        cloud.setRadius(3+l);cloud.setRadiusOnUse(-.5f);cloud.setWaitTime(10);cloud.setDuration(600);cloud.setRadiusPerTick(-cloud.getRadius()/cloud.getDuration());
        cloud.setPotionContents(ItemPowers.boostPotion(stack.getOrDefault(DataComponents.POTION_CONTENTS,PotionContents.EMPTY),l));w.addFreshEntity(cloud);ci.cancel();}
}
