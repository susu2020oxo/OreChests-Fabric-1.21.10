package dev.susu.compressionworld.mixin;
import dev.susu.compressionworld.*;
import net.minecraft.world.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.*;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(Player.class)
public abstract class PlayerStorageMixin implements EnderStorage {
    @Unique private MachineInventory cw$extra;
    public Container cw$ender(){if(cw$extra==null)cw$extra=new MachineInventory(864,()->{}){
        public ItemStack getItem(int i){return i<27?((Player)(Object)PlayerStorageMixin.this).getEnderChestInventory().getItem(i):super.getItem(i);}
        public void setItem(int i,ItemStack s){if(i<27)((Player)(Object)PlayerStorageMixin.this).getEnderChestInventory().setItem(i,s);else super.setItem(i,s);}
        public ItemStack removeItem(int i,int n){if(i<27)return ((Player)(Object)PlayerStorageMixin.this).getEnderChestInventory().removeItem(i,n);return super.removeItem(i,n);}
        public ItemStack removeItemNoUpdate(int i){if(i<27)return ((Player)(Object)PlayerStorageMixin.this).getEnderChestInventory().removeItemNoUpdate(i);return super.removeItemNoUpdate(i);}
    };return cw$extra;}
    @Inject(method="addAdditionalSaveData",at=@At("TAIL"))private void save(ValueOutput out,CallbackInfo ci){if(cw$extra!=null)out.store("compressionworld_ender",ItemStack.OPTIONAL_CODEC.listOf(),cw$extra.snapshot().subList(27,864));}
    @Inject(method="readAdditionalSaveData",at=@At("TAIL"))private void load(ValueInput in,CallbackInfo ci){var v=in.read("compressionworld_ender",ItemStack.OPTIONAL_CODEC.listOf()).orElse(java.util.List.of());if(!v.isEmpty()){var inv=cw$ender();for(int i=0;i<Math.min(837,v.size());i++)inv.setItem(i+27,v.get(i));}}
}
