package dev.susu.compressionworld.mixin;
import dev.susu.compressionworld.*;
import net.minecraft.world.item.*;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.component.Consumable;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(PotionContents.class)public abstract class PotionDrinkMixin {
    @Inject(method="onConsume",at=@At("HEAD"),cancellable=true)private void drink(Level w,LivingEntity e,ItemStack s,Consumable c,CallbackInfo ci){int l=CW.lv(s);if(l>0){if(!w.isClientSide())ItemPowers.boostPotion((PotionContents)(Object)this,l).applyToLivingEntity(e,1);ci.cancel();}}
}
