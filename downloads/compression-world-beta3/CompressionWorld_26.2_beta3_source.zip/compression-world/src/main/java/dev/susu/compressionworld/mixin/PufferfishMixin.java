package dev.susu.compressionworld.mixin;
import dev.susu.compressionworld.*;
import net.minecraft.world.item.*;
import net.minecraft.world.item.consume_effects.ApplyStatusEffectsConsumeEffect;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(ApplyStatusEffectsConsumeEffect.class)public abstract class PufferfishMixin {
    @Inject(method="apply",at=@At("HEAD"),cancellable=true)private void apply(Level w,ItemStack stack,LivingEntity e,CallbackInfoReturnable<Boolean> ci){
        int l=CW.lv(stack);if(l==0||!stack.is(Items.PUFFERFISH))return;var self=(ApplyStatusEffectsConsumeEffect)(Object)this;
        if(!w.isClientSide()&&e.getRandom().nextFloat()<self.probability())for(var effect:self.effects()){
            if(effect.getEffect().equals(MobEffects.POISON))e.addEffect(new MobEffectInstance(UpgradeEffects.TOXIC,effect.getDuration(),l-1));else e.addEffect(new MobEffectInstance(effect));
        }ci.setReturnValue(true);
    }
}
