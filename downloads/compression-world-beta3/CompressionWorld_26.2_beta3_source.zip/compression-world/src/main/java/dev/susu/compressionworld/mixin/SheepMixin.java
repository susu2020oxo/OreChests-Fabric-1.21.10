package dev.susu.compressionworld.mixin;
import dev.susu.compressionworld.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.animal.sheep.Sheep;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(Sheep.class)public abstract class SheepMixin {
    @Unique private int cw$factor=1;
    @Inject(method="shear",at=@At("HEAD"))private void start(ServerLevel w,net.minecraft.sounds.SoundSource sound,ItemStack shears,CallbackInfo ci){cw$factor=CW.power(CW.lv(shears));}
    @ModifyVariable(method="lambda$shear$0",at=@At("HEAD"),argsOnly=true)private ItemStack wool(ItemStack s){var out=s.copy();out.setCount(s.getCount()*cw$factor);return out;}
    @Inject(method="shear",at=@At("RETURN"))private void end(ServerLevel w,net.minecraft.sounds.SoundSource sound,ItemStack shears,CallbackInfo ci){cw$factor=1;}
}
