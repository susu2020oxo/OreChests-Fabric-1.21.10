package dev.susu.compressionworld.mixin;
import dev.susu.compressionworld.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.damagesource.DamageSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(LivingEntity.class)public abstract class ShieldMixin {
    @Inject(method="blockUsingItem",at=@At("TAIL"))private void knock(ServerLevel w,LivingEntity attacker,DamageSource damage,float amount,CallbackInfo ci){var defender=(LivingEntity)(Object)this;var shield=defender.getItemBlockingWith();int l=shield==null?0:CW.lv(shield);if(l>0){double dx=defender.getX()-attacker.getX(),dz=defender.getZ()-attacker.getZ();attacker.knockback(.5*CW.power(l),dx,dz,damage,amount);}}
}
