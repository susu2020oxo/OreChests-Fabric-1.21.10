package dev.susu.compressionworld.mixin;
import dev.susu.compressionworld.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.*;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrownSplashPotion;
import net.minecraft.world.phys.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ThrownSplashPotion.class)public abstract class SplashMixin {
    @Inject(method="onHitAsPotion",at=@At("HEAD"),cancellable=true)
    private void hit(ServerLevel w,ItemStack stack,HitResult hit,CallbackInfo ci){
        int l=CW.lv(stack);if(l==0)return;var self=(ThrownSplashPotion)(Object)this;double radius=4+2*l;
        var potion=ItemPowers.boostPotion(stack.getOrDefault(DataComponents.POTION_CONTENTS,PotionContents.EMPTY),l);
        for(var e:w.getEntitiesOfClass(LivingEntity.class,self.getBoundingBox().inflate(radius))) {
            double d=e.distanceToSqr(self);if(d>=radius*radius)continue;double strength=hit instanceof EntityHitResult eh&&eh.getEntity()==e?1:1-Math.sqrt(d)/radius;
            for(var effect:potion.getAllEffects())if(effect.getEffect().value().isInstantaneous())effect.getEffect().value().applyInstantaneousEffect(w,self,self.getOwner(),e,effect.getAmplifier(),strength);
            else {int duration=(int)(effect.getDuration()*strength);if(duration>=20)e.addEffect(new MobEffectInstance(effect.getEffect(),duration,effect.getAmplifier()),self.getOwner());}
        }ci.cancel();
    }
}
