package dev.susu.compressionworld.mixin;
import dev.susu.compressionworld.*;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(LivingEntity.class) public abstract class TotemMixin {
    @Redirect(method="checkTotemDeathProtection",at=@At(value="INVOKE",target="Lnet/minecraft/world/item/ItemStack;shrink(I)V"))
    private void use(ItemStack s,int count){ItemPowers.consumeCharge(s,count);}
}
