@echo off
setlocal
set GRADLE_VERSION=8.14.3
set GRADLE_HOME=%USERPROFILE%\.gradle\manual\gradle-%GRADLE_VERSION%
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  echo Downloading Gradle %GRADLE_VERSION% ...
  if not exist "%USERPROFILE%\.gradle\manual" mkdir "%USERPROFILE%\.gradle\manual"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip'; $z=Join-Path $env:USERPROFILE '.gradle\manual\gradle.zip'; Invoke-WebRequest $u -OutFile $z; Expand-Archive -Force $z (Join-Path $env:USERPROFILE '.gradle\manual'); Remove-Item $z"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
endlocal
