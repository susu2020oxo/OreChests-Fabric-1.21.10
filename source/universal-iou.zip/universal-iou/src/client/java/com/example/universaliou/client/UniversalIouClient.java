package com.example.universaliou.client;

import com.example.universaliou.AbilityEvents;
import com.example.universaliou.ModItems;
import com.example.universaliou.UniversalIouMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import org.lwjgl.glfw.GLFW;

public class UniversalIouClient implements ClientModInitializer {
    private static final KeyBinding.Category BORROW_CATEGORY = KeyBinding.Category.create(UniversalIouMod.id("main"));
    private static KeyBinding borrowKey;

    @Override
    public void onInitializeClient() {
        borrowKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.universal_iou.borrow",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_F,
                BORROW_CATEGORY
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (borrowKey.wasPressed()) {
                if (client.player != null && client.interactionManager != null
                        && client.crosshairTarget instanceof EntityHitResult hit) {
                    client.interactionManager.interactEntity(client.player, hit.getEntity(), Hand.MAIN_HAND);
                }
            }
        });

        // 胃袋拥有者的饱食度图标覆盖为粉色，原版 HUD 其余部分保持不变。
        HudElementRegistry.addLast(UniversalIouMod.id("pink_food_bar"), (context, tickCounter) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null || !AbilityEvents.hasItem(client.player, ModItems.PIG_STOMACH)) return;

            int right = client.getWindow().getScaledWidth() / 2 + 91;
            int y = client.getWindow().getScaledHeight() - 39;
            int food = client.player.getHungerManager().getFoodLevel();
            for (int i = 0; i < 10; i++) {
                int points = food - i * 2;
                if (points <= 0) continue;
                int x = right - i * 8;
                // 小型像素肉排图标：保留当前饱食度，只把已填充部分染成粉色。
                int width = points == 1 ? 3 : 6;
                context.fill(x + 2, y + 1, x + 2 + width, y + 5, 0xFFFF6FAE);
                context.fill(x + 1, y + 2, x + 1 + width, y + 4, 0xFFFF6FAE);
                context.fill(x + 3, y + 5, x + 4 + width / 2, y + 7, 0xFFFFB8D3);
                context.fill(x + 5, y + 6, x + 7, y + 8, 0xFFFFD5E4);
            }
        });
    }
}
