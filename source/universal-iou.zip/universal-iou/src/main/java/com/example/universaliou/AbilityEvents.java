package com.example.universaliou;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.potion.Potions;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.particle.ParticleTypes;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class AbilityEvents {
    private AbilityEvents() {}

    private static final Map<UUID, Boolean> WAS_GROUNDED = new HashMap<>();
    private static final Map<UUID, Integer> WARDEN_SHOTS_REMAINING = new HashMap<>();
    private static final Map<UUID, Long> WARDEN_NEXT_SHOT_TICK = new HashMap<>();

    public static void initialize() {
        UseItemCallback.EVENT.register(AbilityEvents::onUseItem);
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (!world.isClient() && hand == Hand.MAIN_HAND && player.getMainHandStack().isOf(ModItems.COW_HORN)
                    && entity instanceof LivingEntity target && target.isAlive()) {
                Vec3d direction = target.getEntityPos().subtract(player.getEntityPos()).normalize();
                target.addVelocity(direction.x * 8.0, 2.0, direction.z * 8.0);
            }
            return ActionResult.PASS;
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                boolean grounded = player.isOnGround();
                boolean hasChickenFeet = player.getEquippedStack(EquipmentSlot.FEET).isOf(ModItems.CHICKEN_FEET);

                if (hasChickenFeet) {
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 30, 1, true, false, false));
                    boolean wasGrounded = WAS_GROUNDED.getOrDefault(player.getUuid(), grounded);
                    if (wasGrounded && !grounded && player.getVelocity().y > 0.05) {
                        Vec3d velocity = player.getVelocity();
                        player.setVelocity(velocity.x, Math.max(velocity.y, 0.72), velocity.z);
                        player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 55, 0, true, false, false));
                    }
                }

                if (hasFullWoolSet(player)) {
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 40, 2, true, false, false));
                }

                if (hasFullIronSet(player)) {
                    // Health Boost XXV adds 100 health points (50 hearts).
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.HEALTH_BOOST, 40, 24, true, false, false));
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 40, 4, true, false, false));
                }

                WAS_GROUNDED.put(player.getUuid(), grounded);
                processWardenVolley(player);
            }
        });
    }

    public static boolean hasItem(PlayerEntity player, net.minecraft.item.Item item) {
        return player.getInventory().contains(new ItemStack(item))
                || player.getEquippedStack(EquipmentSlot.CHEST).isOf(item);
    }

    private static boolean hasFullWoolSet(PlayerEntity player) {
        return player.getEquippedStack(EquipmentSlot.HEAD).isOf(ModItems.WOOL_HELMET)
                && player.getEquippedStack(EquipmentSlot.CHEST).isOf(ModItems.WOOL_CHESTPLATE)
                && player.getEquippedStack(EquipmentSlot.LEGS).isOf(ModItems.WOOL_LEGGINGS)
                && player.getEquippedStack(EquipmentSlot.FEET).isOf(ModItems.WOOL_BOOTS);
    }

    private static boolean hasFullIronSet(PlayerEntity player) {
        return player.getEquippedStack(EquipmentSlot.HEAD).isOf(ModItems.IRON_BLOCK_HELMET)
                && player.getEquippedStack(EquipmentSlot.CHEST).isOf(ModItems.IRON_BLOCK_CHESTPLATE)
                && player.getEquippedStack(EquipmentSlot.LEGS).isOf(ModItems.IRON_BLOCK_LEGGINGS)
                && player.getEquippedStack(EquipmentSlot.FEET).isOf(ModItems.IRON_BLOCK_BOOTS);
    }

    private static ActionResult onUseItem(PlayerEntity player, World world, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);

        if (stack.isOf(ModItems.ZOMBIE_LETTER)) {
            if (!world.isClient()) {
                player.sendMessage(Text.literal("朋友，我虽然离开了，"), false);
                player.sendMessage(Text.literal("以后的日子你也要好好的生活，"), false);
                player.sendMessage(Text.literal("记得按时吃饭，"), false);
                player.sendMessage(Text.literal("死去的人其实并不可怕，"), false);
                player.sendMessage(Text.literal("他是别人每天朝思暮想的人。"), false);
            }
            return ActionResult.SUCCESS;
        }

        if (stack.isOf(ModItems.ENDER_BLINK)) {
            if (!world.isClient()) blinkForward(player, world);
            return ActionResult.SUCCESS;
        }

        if (stack.isOf(ModItems.PIGLIN_TREASURE_BOX)) {
            if (!world.isClient()) {
                givePiglinBarterSet(player);
                if (!player.isCreative()) stack.decrement(1);
                player.sendMessage(Text.literal("百宝箱已打开：猪灵交易物品每种 64 个！"), true);
            }
            return ActionResult.SUCCESS;
        }

        if (stack.isOf(ModItems.WARDEN_HEAD)) {
            if (!world.isClient()) queueFiveSonicBooms(player);
            return ActionResult.SUCCESS;
        }

        // 拥有猪胃袋时，每次成功开始食用普通食物都会永久增加 2 点最大生命值。
        if (!world.isClient() && stack.get(DataComponentTypes.FOOD) != null
                && player.canConsume(false) && hasItem(player, ModItems.PIG_STOMACH)) {
            addPermanentPigHealth(player);
        }

        return ActionResult.PASS;
    }

    private static void addPermanentPigHealth(PlayerEntity player) {
        EntityAttributeInstance maxHealth = player.getAttributeInstance(EntityAttributes.MAX_HEALTH);
        if (maxHealth == null || maxHealth.getValue() >= 200.0) return;

        Identifier modifierId = Identifier.of(UniversalIouMod.MOD_ID,
                "pig_stomach_food_" + player.getEntityWorld().getTime() + "_" + player.getRandom().nextInt(1_000_000));
        maxHealth.addPersistentModifier(new EntityAttributeModifier(
                modifierId, 2.0, EntityAttributeModifier.Operation.ADD_VALUE));
        player.setHealth(Math.min((float) maxHealth.getValue(), player.getHealth() + 2.0F));
    }

    private static void blinkForward(PlayerEntity player, World world) {
        Vec3d look = player.getRotationVec(1.0F);
        Vec3d origin = player.getEntityPos();
        for (int distance = 14; distance >= 2; distance--) {
            Vec3d destination = origin.add(look.multiply(distance));
            Box movedBox = player.getBoundingBox().offset(destination.subtract(origin));
            if (world.isSpaceEmpty(player, movedBox)) {
                player.requestTeleport(destination.x, destination.y, destination.z);
                player.fallDistance = 0.0F;
                return;
            }
        }
        player.sendMessage(Text.literal("前方空间不足，无法闪现。"), true);
    }

    private static void givePiglinBarterSet(PlayerEntity player) {
        Registry<Enchantment> enchantments = player.getEntityWorld().getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
        RegistryEntry<Enchantment> soulSpeed = enchantments.getEntry(Enchantments.SOUL_SPEED.getValue()).orElseThrow();

        ItemStack soulSpeedBook = new ItemStack(Items.ENCHANTED_BOOK);
        soulSpeedBook.addEnchantment(soulSpeed, 3);
        giveCount(player, soulSpeedBook, 64);
        ItemStack soulSpeedBoots = new ItemStack(Items.IRON_BOOTS);
        soulSpeedBoots.addEnchantment(soulSpeed, 3);
        giveCount(player, soulSpeedBoots, 64);

        giveCount(player, potion(Items.POTION, Potions.FIRE_RESISTANCE), 64);
        giveCount(player, potion(Items.SPLASH_POTION, Potions.FIRE_RESISTANCE), 64);
        giveCount(player, potion(Items.POTION, Potions.WATER), 64);

        giveCount(player, new ItemStack(Items.DRIED_GHAST), 64);
        giveCount(player, new ItemStack(Items.IRON_NUGGET), 64);
        giveCount(player, new ItemStack(Items.ENDER_PEARL), 64);
        giveCount(player, new ItemStack(Items.STRING), 64);
        giveCount(player, new ItemStack(Items.QUARTZ), 64);
        giveCount(player, new ItemStack(Items.OBSIDIAN), 64);
        giveCount(player, new ItemStack(Items.CRYING_OBSIDIAN), 64);
        giveCount(player, new ItemStack(Items.FIRE_CHARGE), 64);
        giveCount(player, new ItemStack(Items.LEATHER), 64);
        giveCount(player, new ItemStack(Items.SOUL_SAND), 64);
        giveCount(player, new ItemStack(Items.NETHER_BRICK), 64);
        giveCount(player, new ItemStack(Items.SPECTRAL_ARROW), 64);
        giveCount(player, new ItemStack(Items.GRAVEL), 64);
        giveCount(player, new ItemStack(Items.BLACKSTONE), 64);
    }

    private static ItemStack potion(net.minecraft.item.Item item, RegistryEntry<net.minecraft.potion.Potion> potion) {
        ItemStack stack = new ItemStack(item);
        stack.set(DataComponentTypes.POTION_CONTENTS, new PotionContentsComponent(potion));
        return stack;
    }

    private static void giveCount(PlayerEntity player, ItemStack prototype, int count) {
        int max = Math.max(1, prototype.getMaxCount());
        int remaining = count;
        while (remaining > 0) {
            int amount = Math.min(max, remaining);
            ItemStack copy = prototype.copy();
            copy.setCount(amount);
            player.giveItemStack(copy);
            remaining -= amount;
        }
    }

    private static void queueFiveSonicBooms(PlayerEntity player) {
        UUID id = player.getUuid();
        WARDEN_SHOTS_REMAINING.put(id, 5);
        WARDEN_NEXT_SHOT_TICK.put(id, player.getEntityWorld().getTime());
        player.sendMessage(Text.literal("监守者音波：五连发！"), true);
    }

    private static void processWardenVolley(ServerPlayerEntity player) {
        UUID id = player.getUuid();
        int remaining = WARDEN_SHOTS_REMAINING.getOrDefault(id, 0);
        if (remaining <= 0) return;

        long now = player.getEntityWorld().getTime();
        long nextShot = WARDEN_NEXT_SHOT_TICK.getOrDefault(id, now);
        if (now < nextShot) return;

        if (player.getEntityWorld() instanceof ServerWorld serverWorld) {
            fireOneSonicBoom(player, serverWorld);
        }

        remaining--;
        if (remaining <= 0) {
            WARDEN_SHOTS_REMAINING.remove(id);
            WARDEN_NEXT_SHOT_TICK.remove(id);
        } else {
            WARDEN_SHOTS_REMAINING.put(id, remaining);
            WARDEN_NEXT_SHOT_TICK.put(id, now + 2);
        }
    }

    private static void fireOneSonicBoom(ServerPlayerEntity player, ServerWorld world) {
        Vec3d look = player.getRotationVec(1.0F);
        Vec3d start = player.getEyePos();
        LivingEntity target = findTargetInFront(player, world, look, 24.0);

        world.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.ENTITY_WARDEN_SONIC_BOOM, SoundCategory.HOSTILE, 2.0F, 1.0F);
        for (int step = 1; step <= 12; step++) {
            Vec3d particlePos = start.add(look.multiply(step * 2.0));
            world.spawnParticles(ParticleTypes.SONIC_BOOM,
                    particlePos.x, particlePos.y, particlePos.z, 1, 0, 0, 0, 0);
        }
        if (target != null && target.isAlive()) {
            target.damage(world, world.getDamageSources().sonicBoom(player), 30.0F);
            target.addVelocity(look.x * 0.35, 0.08, look.z * 0.35);
            target.velocityModified = true;
        }
    }

    private static LivingEntity findTargetInFront(PlayerEntity player, World world, Vec3d look, double range) {
        Box searchBox = player.getBoundingBox().stretch(look.multiply(range)).expand(1.5);
        LivingEntity nearest = null;
        double bestDistance = range * range;

        for (Entity entity : world.getOtherEntities(player, searchBox, e -> e instanceof LivingEntity && e.isAlive())) {
            if (!(entity instanceof LivingEntity living)) continue;
            Vec3d delta = living.getBoundingBox().getCenter().subtract(player.getEyePos());
            double distanceSquared = delta.lengthSquared();
            if (distanceSquared > bestDistance || distanceSquared < 0.01) continue;
            if (delta.normalize().dotProduct(look) < 0.92) continue;
            bestDistance = distanceSquared;
            nearest = living;
        }
        return nearest;
    }
}
