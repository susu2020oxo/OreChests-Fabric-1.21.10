package com.example.universaliou;

import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.EndermanEntity;
import net.minecraft.entity.mob.SkeletonEntity;
import net.minecraft.entity.mob.PiglinEntity;
import net.minecraft.entity.mob.WardenEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.passive.ChickenEntity;
import net.minecraft.entity.passive.CowEntity;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.passive.PigEntity;
import net.minecraft.entity.passive.SheepEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.world.World;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.component.DataComponentTypes;

public final class BorrowEvents {
    private BorrowEvents() {}

    public static void initialize() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            PlayerEntity player = handler.player;
            if (!hasReceipt(player)) {
                player.giveItemStack(new ItemStack(ModItems.UNIVERSAL_IOU));
                player.sendMessage(Text.literal("获得了：万能借条。看向生物按 F 即可借取物品！").formatted(Formatting.GOLD), false);
            }
        });

        UseEntityCallback.EVENT.register(BorrowEvents::onEntityUse);
    }

    public static boolean hasReceipt(PlayerEntity player) {
        return player.getInventory().contains(new ItemStack(ModItems.UNIVERSAL_IOU));
    }

    private static ActionResult onEntityUse(PlayerEntity player, World world, Hand hand, Entity entity, EntityHitResult hitResult) {
        if (player.isSpectator() || !hasReceipt(player)) return ActionResult.PASS;

        Item borrowed = null;
        String borrowedName = null;

        if (entity instanceof ChickenEntity) {
            borrowed = ModItems.CHICKEN_FEET;
            borrowedName = "鸡脚";
        } else if (entity instanceof PigEntity) {
            borrowed = ModItems.PIG_STOMACH;
            borrowedName = "猪的胃袋";
        } else if (entity instanceof CowEntity) {
            borrowed = ModItems.COW_HORN;
            borrowedName = "牛角";
        } else if (entity instanceof SheepEntity) {
            borrowed = Items.WHITE_WOOL;
            borrowedName = "白色羊毛";
        } else if (entity instanceof CreeperEntity) {
            borrowed = ModItems.BIG_TNT;
            borrowedName = "正版 TNT（100 倍威力）";
        } else if (entity instanceof ZombieEntity) {
            borrowed = ModItems.ZOMBIE_LETTER;
            borrowedName = "僵尸的信";
        } else if (entity instanceof EndermanEntity) {
            borrowed = ModItems.ENDER_BLINK;
            borrowedName = "末影闪现";
        } else if (entity instanceof SkeletonEntity) {
            borrowedName = "小白祖传神功";
        } else if (entity instanceof IronGolemEntity) {
            borrowedName = "铁块重甲（四件套）";
        } else if (entity instanceof PiglinEntity) {
            borrowed = ModItems.PIGLIN_TREASURE_BOX;
            borrowedName = "猪灵百宝箱";
        } else if (entity instanceof EnderDragonEntity) {
            borrowed = Items.DRAGON_EGG;
            borrowedName = "末影龙蛋";
        } else if (entity instanceof WardenEntity) {
            borrowed = ModItems.WARDEN_HEAD;
            borrowedName = "监守者头颅";
        }

        if (borrowedName == null) return ActionResult.PASS;
        if (world.isClient()) return ActionResult.SUCCESS;

        if (entity instanceof SkeletonEntity) {
            ItemStack bow = new ItemStack(ModItems.SKELETON_BOW);
            bow.set(DataComponentTypes.CUSTOM_NAME, Text.literal("小白祖传神功").formatted(Formatting.AQUA));
            Registry<Enchantment> enchantments = world.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
            addEnchantment(bow, enchantments, Enchantments.MULTISHOT, 100);
            addEnchantment(bow, enchantments, Enchantments.INFINITY, 1);
            addEnchantment(bow, enchantments, Enchantments.UNBREAKING, 400);
            player.giveItemStack(bow);
        } else if (entity instanceof IronGolemEntity) {
            player.giveItemStack(new ItemStack(ModItems.IRON_BLOCK_HELMET));
            player.giveItemStack(new ItemStack(ModItems.IRON_BLOCK_CHESTPLATE));
            player.giveItemStack(new ItemStack(ModItems.IRON_BLOCK_LEGGINGS));
            player.giveItemStack(new ItemStack(ModItems.IRON_BLOCK_BOOTS));
        } else if (borrowed != null) {
            player.giveItemStack(new ItemStack(borrowed));
        }

        player.sendMessage(Text.literal("借到了：" + borrowedName).formatted(Formatting.GREEN), true);
        return ActionResult.SUCCESS;
    }

    private static void addEnchantment(ItemStack stack, Registry<Enchantment> registry,
                                       net.minecraft.registry.RegistryKey<Enchantment> key, int level) {
        RegistryEntry<Enchantment> entry = registry.getEntry(key).orElseThrow();
        stack.addEnchantment(entry, level);
    }
}
