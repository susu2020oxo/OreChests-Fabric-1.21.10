package com.example.universaliou;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.EndermanEntity;
import net.minecraft.entity.mob.SkeletonEntity;
import net.minecraft.entity.mob.PiglinEntity;
import net.minecraft.entity.mob.WardenEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.passive.ChickenEntity;
import net.minecraft.entity.passive.CowEntity;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.passive.PigEntity;
import net.minecraft.entity.passive.SheepEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.village.VillagerProfession;
import net.minecraft.village.TradeOffer;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.context.LootWorldContext;
import net.minecraft.loot.context.LootContextTypes;
import net.minecraft.loot.context.LootContextParameters;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.enchantment.EnchantmentLevelEntry;

import java.util.List;
import java.util.Optional;
import java.util.ArrayList;

public final class BorrowEvents {
    private BorrowEvents() {}

    public static void initialize() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            PlayerEntity player = handler.player;
            if (!hasReceipt(player)) {
                player.giveItemStack(new ItemStack(ModItems.UNIVERSAL_IOU));
                player.sendMessage(Text.literal("获得了：万能借条。手持借条，对准生物按 F 即可借取物品！").formatted(Formatting.GOLD, Formatting.BOLD), false);
            }
        });
        // 只接收客户端 F 键发来的借款请求；鼠标右键及空手不能借。
        PayloadTypeRegistry.playC2S().register(BorrowPayload.ID, BorrowPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(BorrowPayload.ID, (payload, context) -> {
            context.server().execute(() -> {
                ServerPlayerEntity player = context.player();
                Entity target = player.getEntityWorld().getEntityById(payload.entityId());
                if (target != null) borrowFromFKey(player, target);
            });
        });
    }

    public static boolean hasReceipt(PlayerEntity player) {
        return player.getInventory().contains(new ItemStack(ModItems.UNIVERSAL_IOU));
    }

    private static void borrowFromFKey(ServerPlayerEntity player, Entity entity) {
        // 服务端二次验证，借条必须拿在主手或副手；按 F 默认可能触发原版主副手交换。
        if (player.isSpectator() || (!player.getMainHandStack().isOf(ModItems.UNIVERSAL_IOU)
                && !player.getOffHandStack().isOf(ModItems.UNIVERSAL_IOU))) return;
        if (!isBorrowable(entity) || entity.squaredDistanceTo(player) > 36.0) return;
        World world = player.getEntityWorld();

        if (entity instanceof VillagerEntity villager
                && (villager.getVillagerData().profession().equals(VillagerProfession.NONE)
                || villager.getVillagerData().profession().equals(VillagerProfession.NITWIT))) {
            player.sendMessage(Text.literal("对不起，我没上班，所以没钱借你。")
                    .formatted(Formatting.YELLOW, Formatting.BOLD), false);
            return;
        }

        if (world.random.nextFloat() < 0.10F) {
            player.sendMessage(Text.literal("没钱不借，走开！").formatted(Formatting.RED, Formatting.BOLD), false);
            return;
        }
        ItemStack result = createBorrowResult(entity, player, world);
        if (result.isEmpty()) return;
        // giveItemStack 会修改传入的 ItemStack（成功插入后可能变为空气），先缓存真实名称和数量。
        Text borrowedName = result.getName().copy();
        int borrowedCount = result.getCount();
        player.giveItemStack(result);
        player.sendMessage(Text.literal("借到了：").append(borrowedName)
                .append(Text.literal(" x" + borrowedCount + "。好吧好吧，记得还钱！"))
                .formatted(Formatting.GREEN, Formatting.BOLD), false);
    }

    private static boolean isBorrowable(Entity entity) {
        // 所有原版及模组 MobEntity 均可借取；玩家和非生物实体不参与。
        return entity instanceof MobEntity && !(entity instanceof PlayerEntity);
    }

    private static ItemStack createBorrowResult(Entity entity, ServerPlayerEntity player, World world) {
        // 村民保留职业交易逻辑；无职业村民已在借取入口处拦截。
        if (entity instanceof VillagerEntity villager) return createVillagerBorrowResult(villager, world);

        ItemStack special = createSpecialBorrowResult(entity, player, world);
        ItemStack vanillaDrop = createEntityLoot(entity, player);

        // 与原有设计一致：有专属物品时，约一半概率借到专属物品，另一半概率借到原版掉落物。
        if (!special.isEmpty() && (vanillaDrop.isEmpty() || world.random.nextBoolean())) return special;
        if (!vanillaDrop.isEmpty()) return withLore(vanillaDrop, "原版生物掉落物：从该生物的原版战利品表中抽取。");
        if (!special.isEmpty()) return special;

        // 少数原版生物没有常规掉落表（例如悦灵、蝙蝠），给它们设计对应的纪念性借取物。
        ItemStack fallback = createNoLootFallback(entity);
        if (!fallback.isEmpty()) return fallback;
        return withLore(new ItemStack(Items.BONE), "生物纪念掉落物：该生物没有常规物品掉落表。");
    }

    private static ItemStack createEntityLoot(Entity entity, ServerPlayerEntity player) {
        if (!(entity.getEntityWorld() instanceof ServerWorld serverWorld)) return ItemStack.EMPTY;
        Optional<RegistryKey<LootTable>> lootKey = entity.getLootTableKey();
        if (lootKey.isEmpty()) return ItemStack.EMPTY;

        try {
            LootTable table = serverWorld.getServer().getReloadableRegistries().getLootTable(lootKey.get());
            LootWorldContext parameters = new LootWorldContext.Builder(serverWorld)
                    .add(LootContextParameters.THIS_ENTITY, entity)
                    .add(LootContextParameters.ORIGIN, entity.getEntityPos())
                    .add(LootContextParameters.DAMAGE_SOURCE, serverWorld.getDamageSources().playerAttack(player))
                    .addOptional(LootContextParameters.ATTACKING_ENTITY, player)
                    .addOptional(LootContextParameters.DIRECT_ATTACKING_ENTITY, player)
                    .addOptional(LootContextParameters.LAST_DAMAGE_PLAYER, player)
                    .addOptional(LootContextParameters.TOOL, player.getMainHandStack())
                    .luck(player.getLuck())
                    .build(LootContextTypes.ENTITY);
            List<ItemStack> drops = table.generateLoot(parameters);
            List<ItemStack> nonEmpty = new ArrayList<>();
            for (ItemStack stack : drops) if (!stack.isEmpty()) nonEmpty.add(stack);
            if (nonEmpty.isEmpty()) return ItemStack.EMPTY;
            return nonEmpty.get(serverWorld.random.nextInt(nonEmpty.size())).copy();
        } catch (RuntimeException exception) {
            // 个别特殊实体可能没有 ENTITY 类型的战利品上下文；继续尝试专属物品/兜底掉落。
            return ItemStack.EMPTY;
        }
    }

    private static ItemStack createSpecialBorrowResult(Entity entity, PlayerEntity player, World world) {
        if (entity instanceof ChickenEntity) return new ItemStack(ModItems.CHICKEN_FEET);
        if (entity instanceof PigEntity) return new ItemStack(ModItems.PIG_STOMACH);
        if (entity instanceof CowEntity) return new ItemStack(ModItems.COW_HORN);
        if (entity instanceof SheepEntity) return withLore(new ItemStack(Items.WHITE_WOOL), "羊毛：可用于合成羊毛四件套；穿齐获得抗性 III。");
        if (entity instanceof CreeperEntity) return new ItemStack(ModItems.BIG_TNT);
        if (entity instanceof ZombieEntity) return new ItemStack(ModItems.ZOMBIE_LETTER);
        if (entity instanceof EndermanEntity) return new ItemStack(ModItems.ENDER_BLINK);
        if (entity instanceof SkeletonEntity) return createSkeletonBow(player, world);
        if (entity instanceof IronGolemEntity) return randomIronArmorPiece(world);
        if (entity instanceof PiglinEntity) {
            return world.random.nextBoolean() ? createPiglinGoldenSword(world) : new ItemStack(ModItems.PIGLIN_TREASURE_BOX);
        }
        if (entity instanceof EnderDragonEntity) return withLore(new ItemStack(Items.DRAGON_EGG), "末影龙借出的龙蛋：稀有专属物品。");
        if (entity instanceof WardenEntity) return new ItemStack(ModItems.WARDEN_HEAD);

        String type = Registries.ENTITY_TYPE.getId(entity.getType()).getPath();
        if (isHorseType(type)) return new ItemStack(ModItems.HORSE_LEGS);
        return switch (type) {
            case "blaze" -> new ItemStack(ModItems.BLAZE_CORE);
            case "spider", "cave_spider" -> new ItemStack(ModItems.SPIDER_EYE_RELIC);
            case "slime" -> new ItemStack(ModItems.SLIME_CORE);
            case "magma_cube" -> new ItemStack(ModItems.MAGMA_CORE);
            case "phantom" -> new ItemStack(ModItems.PHANTOM_MEMBRANE_RELIC);
            case "bee" -> new ItemStack(ModItems.QUEEN_BEE_HIVE);
            case "guardian", "elder_guardian" -> new ItemStack(ModItems.SEA_SCALE);
            case "breeze" -> new ItemStack(ModItems.STORM_CORE);
            case "allay" -> new ItemStack(ModItems.ALLAY_CRYSTAL);
            case "ravager" -> new ItemStack(ModItems.RAVAGER_HORN);
            case "ghast" -> new ItemStack(ModItems.GHAST_TEAR_RELIC);
            case "wither_skeleton" -> new ItemStack(ModItems.WITHER_CROWN);
            default -> ItemStack.EMPTY;
        };
    }

    private static boolean isHorseType(String type) {
        return type.equals("horse") || type.equals("donkey") || type.equals("mule")
                || type.equals("skeleton_horse") || type.equals("zombie_horse") || type.equals("camel");
    }

    private static ItemStack createPiglinGoldenSword(World world) {
        // 必须使用原版金剑物品本体，继承原版近战攻击伤害与攻速属性；
        // 锋利 X 写入真正的 ENCHANTMENTS 数据组件，而不是仅显示在名称/描述中。
        ItemStack sword = new ItemStack(Items.GOLDEN_SWORD);
        sword.set(DataComponentTypes.CUSTOM_NAME, Text.literal("猪人的金剑").formatted(Formatting.GOLD, Formatting.BOLD));
        sword.set(DataComponentTypes.LORE, new LoreComponent(List.of(
                Text.literal("附魔：锋利 X").formatted(Formatting.YELLOW, Formatting.BOLD),
                Text.literal("原版金剑 · 猪灵祖传的战斗武器。").formatted(Formatting.GRAY))));
        Registry<Enchantment> enchantments = world.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
        addEnchantment(sword, enchantments, Enchantments.SHARPNESS, 10);
        return sword;
    }

    private static ItemStack createNamedRelic(Item item, String name, String description) {
        ItemStack stack = new ItemStack(item);
        stack.set(DataComponentTypes.CUSTOM_NAME, Text.literal(name).formatted(Formatting.GOLD, Formatting.BOLD));
        stack.set(DataComponentTypes.LORE, new LoreComponent(List.of(
                Text.literal(description).formatted(Formatting.YELLOW, Formatting.BOLD))));
        return stack;
    }

    private static ItemStack createNoLootFallback(Entity entity) {
        String type = Registries.ENTITY_TYPE.getId(entity.getType()).getPath();
        return switch (type) {
            case "bat" -> new ItemStack(Items.PHANTOM_MEMBRANE);
            case "allay" -> new ItemStack(Items.AMETHYST_SHARD);
            case "horse", "donkey", "mule", "skeleton_horse", "zombie_horse", "camel", "llama", "trader_llama" -> new ItemStack(Items.LEATHER);
            case "wandering_trader" -> new ItemStack(Items.EMERALD);
            case "fox" -> new ItemStack(Items.SWEET_BERRIES);
            case "cat", "ocelot" -> new ItemStack(Items.STRING);
            case "dolphin" -> new ItemStack(Items.COD);
            case "axolotl" -> new ItemStack(Items.TROPICAL_FISH);
            case "panda" -> new ItemStack(Items.BAMBOO);
            case "sniffer" -> new ItemStack(Items.TORCHFLOWER_SEEDS);
            case "silverfish", "endermite" -> new ItemStack(Items.STONE);
            default -> ItemStack.EMPTY;
        };
    }

    private static ItemStack createVillagerBorrowResult(VillagerEntity villager, World world) {
        // 村民借取只从其当前已生成的真实交易列表中抽取商品，另有机会直接借到绿宝石。
        if (world.random.nextFloat() < 0.35F) {
            return new ItemStack(Items.EMERALD, 1 + world.random.nextInt(5));
        }
        var offers = villager.getOffers();
        if (offers.isEmpty()) return new ItemStack(Items.EMERALD, 1 + world.random.nextInt(5));
        TradeOffer offer = offers.get(world.random.nextInt(offers.size()));
        ItemStack sold = offer.getSellItem().copy();
        if (sold.isEmpty()) return new ItemStack(Items.EMERALD, 1 + world.random.nextInt(5));
        return sold;
    }

    private static ItemStack randomStack(World world, Item first, Item second) {
        return new ItemStack(world.random.nextBoolean() ? first : second);
    }

    private static ItemStack randomIronArmorPiece(World world) {
        Item[] pieces = {ModItems.IRON_BLOCK_HELMET, ModItems.IRON_BLOCK_CHESTPLATE,
                ModItems.IRON_BLOCK_LEGGINGS, ModItems.IRON_BLOCK_BOOTS};
        return new ItemStack(pieces[world.random.nextInt(pieces.length)]);
    }

    private static ItemStack createSkeletonBow(PlayerEntity player, World world) {
        ItemStack bow = new ItemStack(ModItems.SKELETON_BOW);
        bow.set(DataComponentTypes.CUSTOM_NAME, Text.literal("小白祖传神功").formatted(Formatting.AQUA, Formatting.BOLD));
        Registry<Enchantment> enchantments = world.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
        addEnchantment(bow, enchantments, Enchantments.MULTISHOT, 100);
        addEnchantment(bow, enchantments, Enchantments.INFINITY, 1);
        addEnchantment(bow, enchantments, Enchantments.UNBREAKING, 400);
        return bow;
    }

    private static ItemStack withLore(ItemStack stack, String description) {
        stack.set(DataComponentTypes.LORE, new LoreComponent(List.of(
                Text.literal(description).formatted(Formatting.YELLOW, Formatting.BOLD))));
        return stack;
    }

    private static void addEnchantment(ItemStack stack, Registry<Enchantment> registry,
                                       net.minecraft.registry.RegistryKey<Enchantment> key, int level) {
        RegistryEntry<Enchantment> entry = registry.getEntry(key.getValue()).orElseThrow();
        stack.addEnchantment(entry, level);
    }
}
