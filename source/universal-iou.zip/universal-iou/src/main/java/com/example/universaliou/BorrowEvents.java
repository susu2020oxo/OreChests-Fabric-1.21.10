package com.example.universaliou;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.EndermanEntity;
import net.minecraft.entity.mob.SkeletonEntity;
import net.minecraft.entity.mob.PiglinEntity;
import net.minecraft.entity.mob.WardenEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.passive.ChickenEntity;
import net.minecraft.entity.passive.CowEntity;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.passive.PigEntity;
import net.minecraft.entity.passive.SheepEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.village.VillagerProfession;
import net.minecraft.village.TradeOffer;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.enchantment.EnchantmentLevelEntry;

import java.util.List;

public final class BorrowEvents {
    private BorrowEvents() {}

    public static void initialize() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            PlayerEntity player = handler.player;
            if (!hasReceipt(player)) {
                player.giveItemStack(new ItemStack(ModItems.UNIVERSAL_IOU));
                player.sendMessage(Text.literal("获得了：万能借条。手持借条，对准生物按 F 即可借取物品！").formatted(Formatting.GOLD, Formatting.BOLD), false);
            }
        });
        // 只接收客户端 F 键发来的借款请求；鼠标右键及空手不能借。
        PayloadTypeRegistry.playC2S().register(BorrowPayload.ID, BorrowPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(BorrowPayload.ID, (payload, context) -> {
            context.server().execute(() -> {
                ServerPlayerEntity player = context.player();
                Entity target = player.getEntityWorld().getEntityById(payload.entityId());
                if (target != null) borrowFromFKey(player, target);
            });
        });
    }

    public static boolean hasReceipt(PlayerEntity player) {
        return player.getInventory().contains(new ItemStack(ModItems.UNIVERSAL_IOU));
    }

    private static void borrowFromFKey(ServerPlayerEntity player, Entity entity) {
        // 服务端二次验证，借条必须拿在主手或副手；按 F 默认可能触发原版主副手交换。
        if (player.isSpectator() || (!player.getMainHandStack().isOf(ModItems.UNIVERSAL_IOU)
                && !player.getOffHandStack().isOf(ModItems.UNIVERSAL_IOU))) return;
        if (!isBorrowable(entity) || entity.squaredDistanceTo(player) > 36.0) return;
        World world = player.getEntityWorld();

        if (entity instanceof VillagerEntity villager
                && (villager.getVillagerData().getProfession() == VillagerProfession.NONE
                || villager.getVillagerData().getProfession() == VillagerProfession.NITWIT)) {
            player.sendMessage(Text.literal("对不起，我没上班，所以没钱借你。")
                    .formatted(Formatting.YELLOW, Formatting.BOLD), false);
            return;
        }

        if (world.random.nextFloat() < 0.10F) {
            player.sendMessage(Text.literal("没钱不借，走开！").formatted(Formatting.RED, Formatting.BOLD), false);
            return;
        }
        ItemStack result = createBorrowResult(entity, player, world);
        if (result.isEmpty()) return;
        // giveItemStack 会修改传入的 ItemStack（成功插入后可能变为空气），先缓存真实名称和数量。
        Text borrowedName = result.getName().copy();
        int borrowedCount = result.getCount();
        player.giveItemStack(result);
        player.sendMessage(Text.literal("借到了：").append(borrowedName)
                .append(Text.literal(" x" + borrowedCount + "。好吧好吧，记得还钱！"))
                .formatted(Formatting.GREEN, Formatting.BOLD), false);
    }

    private static boolean isBorrowable(Entity entity) {
        return entity instanceof ChickenEntity || entity instanceof PigEntity || entity instanceof CowEntity
                || entity instanceof SheepEntity || entity instanceof CreeperEntity || entity instanceof ZombieEntity
                || entity instanceof EndermanEntity || entity instanceof SkeletonEntity || entity instanceof IronGolemEntity
                || entity instanceof PiglinEntity || entity instanceof EnderDragonEntity || entity instanceof WardenEntity
                || entity instanceof VillagerEntity;
    }

    private static ItemStack createBorrowResult(Entity entity, PlayerEntity player, World world) {
        // 村民只借取当前职业交易列表里的商品或绿宝石，不参与普通生物掉落物抽取。
        if (entity instanceof VillagerEntity villager) return createVillagerBorrowResult(villager, world);
        // 每次只会发放一种物品类型：可先抽到原版掉落物，也可能抽到专属借取物。
        boolean vanillaDrop = world.random.nextBoolean() && hasVanillaDrop(entity);
        if (vanillaDrop) return withLore(createVanillaDrop(entity, world), "原版生物掉落物：本次借取随机获得。");

        if (entity instanceof ChickenEntity) return new ItemStack(ModItems.CHICKEN_FEET);
        if (entity instanceof PigEntity) return new ItemStack(ModItems.PIG_STOMACH);
        if (entity instanceof CowEntity) return new ItemStack(ModItems.COW_HORN);
        if (entity instanceof SheepEntity) return withLore(new ItemStack(Items.WHITE_WOOL), "羊毛：可用于合成羊毛四件套；穿齐获得抗性 III。");
        if (entity instanceof CreeperEntity) return new ItemStack(ModItems.BIG_TNT);
        if (entity instanceof ZombieEntity) return new ItemStack(ModItems.ZOMBIE_LETTER);
        if (entity instanceof EndermanEntity) return new ItemStack(ModItems.ENDER_BLINK);
        if (entity instanceof SkeletonEntity) return createSkeletonBow(player, world);
        if (entity instanceof IronGolemEntity) return randomIronArmorPiece(world);
        if (entity instanceof PiglinEntity) return new ItemStack(ModItems.PIGLIN_TREASURE_BOX);
        if (entity instanceof EnderDragonEntity) return withLore(new ItemStack(Items.DRAGON_EGG), "末影龙借出的龙蛋：稀有专属物品。");
        if (entity instanceof WardenEntity) return new ItemStack(ModItems.WARDEN_HEAD);
        return ItemStack.EMPTY;
    }

    private static ItemStack createVillagerBorrowResult(VillagerEntity villager, World world) {
        // 村民借取只从其当前已生成的真实交易列表中抽取商品，另有机会直接借到绿宝石。
        if (world.random.nextFloat() < 0.35F) {
            return new ItemStack(Items.EMERALD, 1 + world.random.nextInt(5));
        }
        var offers = villager.getOffers();
        if (offers.isEmpty()) return new ItemStack(Items.EMERALD, 1 + world.random.nextInt(5));
        TradeOffer offer = offers.get(world.random.nextInt(offers.size()));
        ItemStack sold = offer.getSellItem().copy();
        if (sold.isEmpty()) return new ItemStack(Items.EMERALD, 1 + world.random.nextInt(5));
        return sold;
    }

    private static boolean hasVanillaDrop(Entity entity) {
        return !(entity instanceof EnderDragonEntity) && !(entity instanceof WardenEntity);
    }

    private static ItemStack createVanillaDrop(Entity entity, World world) {
        if (entity instanceof ChickenEntity) return randomStack(world, Items.FEATHER, Items.CHICKEN);
        if (entity instanceof PigEntity) return new ItemStack(Items.PORKCHOP);
        if (entity instanceof CowEntity) return randomStack(world, Items.BEEF, Items.LEATHER);
        if (entity instanceof SheepEntity) return new ItemStack(Items.MUTTON);
        if (entity instanceof CreeperEntity) return new ItemStack(Items.GUNPOWDER);
        if (entity instanceof ZombieEntity) return new ItemStack(Items.ROTTEN_FLESH);
        if (entity instanceof EndermanEntity) return new ItemStack(Items.ENDER_PEARL);
        if (entity instanceof SkeletonEntity) return randomStack(world, Items.BONE, Items.ARROW);
        if (entity instanceof IronGolemEntity) return randomStack(world, Items.IRON_INGOT, Items.POPPY);
        if (entity instanceof PiglinEntity) return new ItemStack(Items.GOLDEN_SWORD);
        return ItemStack.EMPTY;
    }

    private static ItemStack randomStack(World world, Item first, Item second) {
        return new ItemStack(world.random.nextBoolean() ? first : second);
    }

    private static ItemStack randomIronArmorPiece(World world) {
        Item[] pieces = {ModItems.IRON_BLOCK_HELMET, ModItems.IRON_BLOCK_CHESTPLATE,
                ModItems.IRON_BLOCK_LEGGINGS, ModItems.IRON_BLOCK_BOOTS};
        return new ItemStack(pieces[world.random.nextInt(pieces.length)]);
    }

    private static ItemStack createSkeletonBow(PlayerEntity player, World world) {
        ItemStack bow = new ItemStack(ModItems.SKELETON_BOW);
        bow.set(DataComponentTypes.CUSTOM_NAME, Text.literal("小白祖传神功").formatted(Formatting.AQUA, Formatting.BOLD));
        Registry<Enchantment> enchantments = world.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
        addEnchantment(bow, enchantments, Enchantments.MULTISHOT, 100);
        addEnchantment(bow, enchantments, Enchantments.INFINITY, 1);
        addEnchantment(bow, enchantments, Enchantments.UNBREAKING, 400);
        return bow;
    }

    private static ItemStack withLore(ItemStack stack, String description) {
        stack.set(DataComponentTypes.LORE, new LoreComponent(List.of(
                Text.literal(description).formatted(Formatting.YELLOW, Formatting.BOLD))));
        return stack;
    }

    private static void addEnchantment(ItemStack stack, Registry<Enchantment> registry,
                                       net.minecraft.registry.RegistryKey<Enchantment> key, int level) {
        RegistryEntry<Enchantment> entry = registry.getEntry(key.getValue()).orElseThrow();
        stack.addEnchantment(entry, level);
    }
}
