package com.example.universaliou;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** The only way a player requests a loan: the F key on the client. */
public record BorrowPayload(int entityId) implements CustomPayload {
    public static final Id<BorrowPayload> ID = new Id<>(UniversalIouMod.id("borrow_entity"));
    public static final PacketCodec<RegistryByteBuf, BorrowPayload> CODEC =
            PacketCodec.tuple(PacketCodecs.VAR_INT, BorrowPayload::entityId, BorrowPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
