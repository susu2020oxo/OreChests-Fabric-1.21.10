package com.example.universaliou;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.TntBlock;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Explosion;
import net.minecraft.world.World;
import net.minecraft.block.BlockState;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.block.AbstractBlock;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class ModBlocks {
    private ModBlocks() {}

    public static final BigTntBlock BIG_TNT_BLOCK = Registry.register(
            Registries.BLOCK,
            RegistryKey.of(RegistryKeys.BLOCK, UniversalIouMod.id("big_tnt")),
            new BigTntBlock(AbstractBlock.Settings.copy(Blocks.TNT).registryKey(
                    RegistryKey.of(RegistryKeys.BLOCK, UniversalIouMod.id("big_tnt"))))
    );

    private record PendingBlast(ServerWorld world, BlockPos pos, LivingEntity igniter, int ticksLeft) {}
    private static final List<PendingBlast> PENDING = new ArrayList<>();

    public static void initialize() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            List<PendingBlast> snapshot = new ArrayList<>(PENDING);
            PENDING.clear();
            for (PendingBlast blast : snapshot) {
                int left = blast.ticksLeft() - 1;
                if (left <= 0) {
                    ServerWorld world = blast.world();
                    BlockPos pos = blast.pos();
                    world.createExplosion(blast.igniter(), pos.getX() + 0.5, pos.getY() + 0.5,
                            pos.getZ() + 0.5, 400.0F, World.ExplosionSourceType.TNT);
                } else {
                    PENDING.add(new PendingBlast(blast.world(), blast.pos(), blast.igniter(), left));
                }
            }
        });
    }

    private static void prime(World world, BlockPos pos, LivingEntity igniter) {
        if (world.isClient()) return;
        world.setBlockState(pos, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
        if (world instanceof ServerWorld serverWorld) {
            PENDING.add(new PendingBlast(serverWorld, pos.toImmutable(), igniter, 80));
            world.playSound(null, pos, SoundEvents.ENTITY_TNT_PRIMED, SoundCategory.BLOCKS, 1.0F, 1.0F);
        }
    }

    public static class BigTntBlock extends TntBlock {
        public BigTntBlock(AbstractBlock.Settings settings) { super(settings); }

        @Override
        public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player,
                                  Hand hand, BlockHitResult hit) {
            if (!player.getStackInHand(hand).isOf(Items.FLINT_AND_STEEL)) return ActionResult.PASS;
            if (!world.isClient()) {
                var tool = player.getStackInHand(hand);
                prime(world, pos, player);
                tool.damage(1, player, hand == Hand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND);
            }
            return ActionResult.SUCCESS;
        }

        @Override
        public void neighborUpdate(BlockState state, World world, BlockPos pos, Block block, BlockPos fromPos, boolean notify) {
            if (!world.isClient() && world.isReceivingRedstonePower(pos)) prime(world, pos, null);
        }

        @Override
        public void onDestroyedByExplosion(World world, BlockPos pos, Explosion explosion) {
            prime(world, pos, null);
        }
    }
}
