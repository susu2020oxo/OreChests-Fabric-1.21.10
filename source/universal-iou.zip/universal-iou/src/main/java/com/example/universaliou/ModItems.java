package com.example.universaliou;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.BowItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.equipment.EquipmentAsset;
import net.minecraft.item.equipment.EquipmentAssetKeys;
import net.minecraft.registry.Registry;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;

import java.util.function.Function;

public final class ModItems {
    private ModItems() {}

    public static final Item UNIVERSAL_IOU = register("universal_iou", Item::new, new Item.Settings().maxCount(1));

    public static final Item CHICKEN_FEET = register("chicken_feet", Item::new, wearable(EquipmentSlot.FEET, "chicken_feet"));
    public static final Item PIG_STOMACH = register("pig_stomach", Item::new, wearable(EquipmentSlot.CHEST, "pig_stomach"));
    public static final Item COW_HORN = register("cow_horn", Item::new, new Item.Settings().maxCount(1));
    public static final Item BIG_TNT = register("big_tnt", Item::new, new Item.Settings().maxCount(16));
    public static final Item ZOMBIE_LETTER = register("zombie_letter", Item::new, new Item.Settings().maxCount(1));
    public static final Item ENDER_BLINK = register("ender_blink", Item::new, new Item.Settings().maxCount(1));
    public static final Item SKELETON_BOW = register("skeleton_bow", SkeletonBowItem::new, new Item.Settings().maxCount(1).maxDamage(400));
    public static final Item PIGLIN_TREASURE_BOX = register("piglin_treasure_box", Item::new, new Item.Settings().maxCount(1));
    public static final Item WARDEN_HEAD = register("warden_head", Item::new, new Item.Settings().maxCount(1));

    public static final Item WOOL_HELMET = register("wool_helmet", Item::new, wearable(EquipmentSlot.HEAD, "wool"));
    public static final Item WOOL_CHESTPLATE = register("wool_chestplate", Item::new, wearable(EquipmentSlot.CHEST, "wool"));
    public static final Item WOOL_LEGGINGS = register("wool_leggings", Item::new, wearable(EquipmentSlot.LEGS, "wool"));
    public static final Item WOOL_BOOTS = register("wool_boots", Item::new, wearable(EquipmentSlot.FEET, "wool"));

    public static final Item IRON_BLOCK_HELMET = register("iron_block_helmet", Item::new, wearable(EquipmentSlot.HEAD, "iron_block"));
    public static final Item IRON_BLOCK_CHESTPLATE = register("iron_block_chestplate", Item::new, wearable(EquipmentSlot.CHEST, "iron_block"));
    public static final Item IRON_BLOCK_LEGGINGS = register("iron_block_leggings", Item::new, wearable(EquipmentSlot.LEGS, "iron_block"));
    public static final Item IRON_BLOCK_BOOTS = register("iron_block_boots", Item::new, wearable(EquipmentSlot.FEET, "iron_block"));

    private static final RegistryKey<ItemGroup> ITEM_GROUP_KEY = RegistryKey.of(RegistryKeys.ITEM_GROUP, UniversalIouMod.id("items"));
    private static final ItemGroup ITEM_GROUP = FabricItemGroup.builder()
            .icon(() -> new ItemStack(UNIVERSAL_IOU))
            .displayName(Text.translatable("itemGroup.universal_iou"))
            .entries((context, entries) -> {
                entries.add(UNIVERSAL_IOU);
                entries.add(CHICKEN_FEET);
                entries.add(PIG_STOMACH);
                entries.add(COW_HORN);
                entries.add(BIG_TNT);
                entries.add(ZOMBIE_LETTER);
                entries.add(ENDER_BLINK);
                entries.add(SKELETON_BOW);
                entries.add(PIGLIN_TREASURE_BOX);
                entries.add(WARDEN_HEAD);
                entries.add(WOOL_HELMET);
                entries.add(WOOL_CHESTPLATE);
                entries.add(WOOL_LEGGINGS);
                entries.add(WOOL_BOOTS);
                entries.add(IRON_BLOCK_HELMET);
                entries.add(IRON_BLOCK_CHESTPLATE);
                entries.add(IRON_BLOCK_LEGGINGS);
                entries.add(IRON_BLOCK_BOOTS);
            })
            .build();

    private static Item.Settings wearable(EquipmentSlot slot, String assetName) {
        RegistryKey<EquipmentAsset> assetKey = RegistryKey.of(EquipmentAssetKeys.REGISTRY_KEY, UniversalIouMod.id(assetName));
        EquippableComponent equippable = EquippableComponent.builder(slot)
                .model(assetKey)
                .equipOnInteract(true)
                .build();
        return new Item.Settings().maxCount(1).component(DataComponentTypes.EQUIPPABLE, equippable);
    }

    private static Item register(String path, Function<Item.Settings, Item> factory, Item.Settings settings) {
        RegistryKey<Item> itemKey = RegistryKey.of(RegistryKeys.ITEM, UniversalIouMod.id(path));
        return Registry.register(Registries.ITEM, itemKey, factory.apply(settings.registryKey(itemKey)));
    }

    public static void initialize() {
        Registry.register(Registries.ITEM_GROUP, ITEM_GROUP_KEY, ITEM_GROUP);
    }
}
