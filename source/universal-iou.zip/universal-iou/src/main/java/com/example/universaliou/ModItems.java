package com.example.universaliou;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.equipment.EquipmentAsset;
import net.minecraft.item.equipment.EquipmentAssetKeys;
import net.minecraft.registry.Registry;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;
import java.util.function.Function;

public final class ModItems {
    private ModItems() {}

    public static final Item UNIVERSAL_IOU = register("universal_iou", Item::new,
            described(new Item.Settings().maxCount(1), "手持万能借条，对准生物按 F 借取物品；村民可借交易商品或绿宝石。"));
    public static final Item CHICKEN_FEET = register("chicken_feet", Item::new,
            described(wearable(EquipmentSlot.FEET, "chicken_feet"), "穿在脚部：获得速度 II，跳跃时短暂滞空。"));
    public static final Item PIG_STOMACH = register("pig_stomach", Item::new,
            described(wearable(EquipmentSlot.CHEST, "pig_stomach"), "装备后饱食度变粉色；吃东西可永久增加最大生命值。"));
    public static final Item COW_HORN = register("cow_horn", Item::new,
            described(new Item.Settings().maxCount(1), "攻击生物时，将目标击飞很远。"));
    public static final Item BIG_TNT = register("big_tnt", settings -> new BlockItem(ModBlocks.BIG_TNT_BLOCK, settings),
            described(new Item.Settings().maxCount(64), "可放置方块；用打火石点燃，爆炸威力为普通 TNT 的 100 倍。"));
    public static final Item ZOMBIE_LETTER = register("zombie_letter", Item::new,
            described(new Item.Settings().maxCount(1), "右键阅读僵尸留下的信。"));
    public static final Item ENDER_BLINK = register("ender_blink", Item::new,
            described(new Item.Settings().maxCount(1), "右键朝视线方向瞬移一段距离，无冷却时间。"));
    public static final Item SKELETON_BOW = register("skeleton_bow", SkeletonBowItem::new,
            described(new Item.Settings().maxCount(1).maxDamage(400), "一次射出 100 支箭；每支箭基础伤害 5 点；可以附魔。"));
    public static final Item PIGLIN_TREASURE_BOX = register("piglin_treasure_box", Item::new,
            described(new Item.Settings().maxCount(1), "右键打开：随机获得猪灵以金锭交换的物品 10-30 个；附魔书仅有锋利 X 或保护 X。"));
    public static final Item WARDEN_HEAD = register("warden_head", Item::new,
            described(new Item.Settings().maxCount(1), "右键发射五连发监守者音波，造成高额伤害。"));


    // 独立像素风特殊借取物品
    public static final Item PIGLIN_GOLDEN_SWORD = register("piglin_golden_sword", Item::new,
            described(new Item.Settings().maxCount(1), "猪灵祖传金剑：锋利 X。"));
    public static final Item HORSE_LEGS = register("horse_legs", Item::new,
            described(wearable(EquipmentSlot.LEGS, "horse_legs"), "穿在护腿栏：获得速度 XX（速度等级 20）。"));
    public static final Item SPIDER_EYE_RELIC = register("spider_eye_relic", Item::new,
            described(new Item.Settings().maxCount(16), "携带时获得夜视与速度 II。"));
    public static final Item BLAZE_CORE = register("blaze_core", Item::new,
            described(new Item.Settings().maxCount(16), "携带时持续获得防火效果。"));
    public static final Item SLIME_CORE = register("slime_core", Item::new,
            described(new Item.Settings().maxCount(16), "携带时获得强力跳跃提升。"));
    public static final Item MAGMA_CORE = register("magma_core", Item::new,
            described(new Item.Settings().maxCount(16), "携带时获得防火与力量。"));
    public static final Item PHANTOM_MEMBRANE_RELIC = register("phantom_membrane_relic", Item::new,
            described(new Item.Settings().maxCount(16), "携带时获得缓降效果。"));
    public static final Item QUEEN_BEE_HIVE = register("queen_bee_hive", Item::new,
            described(new Item.Settings().maxCount(16), "携带时获得额外吸收生命。"));
    public static final Item SEA_SCALE = register("sea_scale", Item::new,
            described(new Item.Settings().maxCount(16), "携带时获得水下呼吸。"));
    public static final Item STORM_CORE = register("storm_core", Item::new,
            described(new Item.Settings().maxCount(16), "携带时获得速度 III 与跳跃 III。"));
    public static final Item ALLAY_CRYSTAL = register("allay_crystal", Item::new,
            described(new Item.Settings().maxCount(16), "携带时获得轻盈与缓降。"));
    public static final Item RAVAGER_HORN = register("ravager_horn", Item::new,
            described(new Item.Settings().maxCount(1), "手持攻击时大幅击退目标。"));
    public static final Item GHAST_TEAR_RELIC = register("ghast_tear_relic", Item::new,
            described(new Item.Settings().maxCount(16), "携带时获得生命恢复 II。"));
    public static final Item WITHER_CROWN = register("wither_crown", Item::new,
            described(new Item.Settings().maxCount(1), "携带时获得力量 II。"));

    public static final Item WOOL_HELMET = register("wool_helmet", Item::new,
            described(wearable(EquipmentSlot.HEAD, "wool"), "羊毛套装部件；穿齐四件获得抗性 III。"));
    public static final Item WOOL_CHESTPLATE = register("wool_chestplate", Item::new,
            described(wearable(EquipmentSlot.CHEST, "wool"), "羊毛套装部件；穿齐四件获得抗性 III。"));
    public static final Item WOOL_LEGGINGS = register("wool_leggings", Item::new,
            described(wearable(EquipmentSlot.LEGS, "wool"), "羊毛套装部件；穿齐四件获得抗性 III。"));
    public static final Item WOOL_BOOTS = register("wool_boots", Item::new,
            described(wearable(EquipmentSlot.FEET, "wool"), "羊毛套装部件；穿齐四件获得抗性 III。"));

    public static final Item IRON_BLOCK_HELMET = register("iron_block_helmet", Item::new,
            described(wearable(EquipmentSlot.HEAD, "iron_block"), "铁块重甲部件；穿齐四件最大生命值 +100，抗性 V。"));
    public static final Item IRON_BLOCK_CHESTPLATE = register("iron_block_chestplate", Item::new,
            described(wearable(EquipmentSlot.CHEST, "iron_block"), "铁块重甲部件；穿齐四件最大生命值 +100，抗性 V。"));
    public static final Item IRON_BLOCK_LEGGINGS = register("iron_block_leggings", Item::new,
            described(wearable(EquipmentSlot.LEGS, "iron_block"), "铁块重甲部件；穿齐四件最大生命值 +100，抗性 V。"));
    public static final Item IRON_BLOCK_BOOTS = register("iron_block_boots", Item::new,
            described(wearable(EquipmentSlot.FEET, "iron_block"), "铁块重甲部件；穿齐四件最大生命值 +100，抗性 V。"));

    private static final RegistryKey<ItemGroup> ITEM_GROUP_KEY = RegistryKey.of(RegistryKeys.ITEM_GROUP, UniversalIouMod.id("items"));
    private static final ItemGroup ITEM_GROUP = FabricItemGroup.builder()
            .icon(() -> new ItemStack(UNIVERSAL_IOU))
            .displayName(Text.translatable("itemGroup.universal_iou"))
            .entries((context, entries) -> {
                entries.add(UNIVERSAL_IOU); entries.add(CHICKEN_FEET); entries.add(PIG_STOMACH);
                entries.add(COW_HORN); entries.add(BIG_TNT); entries.add(ZOMBIE_LETTER);
                entries.add(ENDER_BLINK); entries.add(SKELETON_BOW); entries.add(PIGLIN_TREASURE_BOX);
                entries.add(WARDEN_HEAD); entries.add(PIGLIN_GOLDEN_SWORD); entries.add(HORSE_LEGS);
                entries.add(SPIDER_EYE_RELIC); entries.add(BLAZE_CORE); entries.add(SLIME_CORE);
                entries.add(MAGMA_CORE); entries.add(PHANTOM_MEMBRANE_RELIC); entries.add(QUEEN_BEE_HIVE);
                entries.add(SEA_SCALE); entries.add(STORM_CORE); entries.add(ALLAY_CRYSTAL);
                entries.add(RAVAGER_HORN); entries.add(GHAST_TEAR_RELIC); entries.add(WITHER_CROWN);
                entries.add(WOOL_HELMET); entries.add(WOOL_CHESTPLATE);
                entries.add(WOOL_LEGGINGS); entries.add(WOOL_BOOTS); entries.add(IRON_BLOCK_HELMET);
                entries.add(IRON_BLOCK_CHESTPLATE); entries.add(IRON_BLOCK_LEGGINGS); entries.add(IRON_BLOCK_BOOTS);
            })
            .build();

    private static Item.Settings described(Item.Settings settings, String description) {
        return settings.component(DataComponentTypes.LORE,
                new LoreComponent(List.of(Text.literal(description).formatted(Formatting.YELLOW, Formatting.BOLD))));
    }

    private static Item.Settings wearable(EquipmentSlot slot, String assetName) {
        RegistryKey<EquipmentAsset> assetKey = RegistryKey.of(EquipmentAssetKeys.REGISTRY_KEY, UniversalIouMod.id(assetName));
        EquippableComponent equippable = EquippableComponent.builder(slot).model(assetKey).equipOnInteract(true).build();
        return new Item.Settings().maxCount(1).component(DataComponentTypes.EQUIPPABLE, equippable);
    }

    private static Item register(String path, Function<Item.Settings, Item> factory, Item.Settings settings) {
        RegistryKey<Item> itemKey = RegistryKey.of(RegistryKeys.ITEM, UniversalIouMod.id(path));
        return Registry.register(Registries.ITEM, itemKey, factory.apply(settings.registryKey(itemKey)));
    }

    public static void initialize() {
        Registry.register(Registries.ITEM_GROUP, ITEM_GROUP_KEY, ITEM_GROUP);
    }
}
