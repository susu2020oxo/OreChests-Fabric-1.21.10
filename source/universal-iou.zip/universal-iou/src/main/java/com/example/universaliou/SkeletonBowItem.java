package com.example.universaliou;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.world.World;

public class SkeletonBowItem extends BowItem {
    public SkeletonBowItem(net.minecraft.item.Item.Settings settings) {
        super(settings);
    }

    @Override
    public boolean onStoppedUsing(ItemStack stack, World world, LivingEntity user, int remainingUseTicks) {
        if (!(user instanceof PlayerEntity player)) return false;

        int usedTicks = this.getMaxUseTime(stack, user) - remainingUseTicks;
        float pull = BowItem.getPullProgress(usedTicks);
        if (pull < 0.1F) return false;

        if (!world.isClient()) {
            // 10 x 10 扇形箭阵，一次拉弓射出 100 支箭。
            for (int i = 0; i < 100; i++) {
                int column = i % 10;
                int row = i / 10;
                float yawOffset = (column - 4.5F) * 1.35F;
                float pitchOffset = (row - 4.5F) * 0.85F;
                ArrowEntity arrow = new ArrowEntity(world, player, new ItemStack(Items.ARROW), stack);
                arrow.setDamage(5.0);
                arrow.setVelocity(player, player.getPitch() + pitchOffset, player.getYaw() + yawOffset,
                        0.0F, 3.0F * pull, 0.0F);
                world.spawnEntity(arrow);
            }
            stack.damage(1, player, EquipmentSlot.MAINHAND);
        }
        return true;
    }
}
