package com.example.universaliou;

import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;

public class UniversalIouMod implements ModInitializer {
    public static final String MOD_ID = "universal_iou";

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModItems.initialize();
        BorrowEvents.initialize();
        AbilityEvents.initialize();
    }
}
